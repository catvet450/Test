package com.example.ui.hub

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.OfficeDocumentEntity
import com.example.data.OfficeRepository
import com.example.engine.FileExportHelper
import com.example.model.DocumentType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HubUiState(
    val documents: List<OfficeDocumentEntity> = emptyList(),
    val searchQuery: String = "",
    val selectedFilter: DocumentType? = null,
    val statusMessage: String? = null,
    val isImporting: Boolean = false,
)

class HubViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = OfficeRepository(application)

    private val _searchQuery = MutableStateFlow("")
    private val _selectedFilter = MutableStateFlow<DocumentType?>(null)
    private val _statusMessage = MutableStateFlow<String?>(null)
    private val _isImporting = MutableStateFlow(false)

    val uiState: StateFlow<HubUiState> = combine(
        repository.allDocuments,
        _searchQuery,
        _selectedFilter,
        _statusMessage,
        _isImporting,
    ) { docs, query, filter, status, importing ->
        val filtered = docs.filter { doc ->
            val matchesType = filter == null || doc.type == filter.name
            val matchesQuery = query.isBlank() ||
                doc.title.contains(query, ignoreCase = true) ||
                doc.previewSnippet.contains(query, ignoreCase = true)
            matchesType && matchesQuery
        }
        HubUiState(
            documents = filtered,
            searchQuery = query,
            selectedFilter = filter,
            statusMessage = status,
            isImporting = importing,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HubUiState(),
    )

    init {
        viewModelScope.launch {
            repository.ensureStarterSamples()
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectFilter(type: DocumentType?) {
        _selectedFilter.value = type
    }

    fun clearStatus() {
        _statusMessage.value = null
    }

    fun createNewDocument(
        type: DocumentType,
        templateId: String,
        title: String,
        onCreated: (String, DocumentType) -> Unit,
    ) {
        viewModelScope.launch {
            val id = repository.createFromTemplate(
                title = title,
                type = type,
                templateId = templateId,
            )
            onCreated(id, type)
        }
    }

    fun togglePin(entity: OfficeDocumentEntity) {
        viewModelScope.launch {
            repository.togglePin(entity)
        }
    }

    fun renameDocument(id: String, newTitle: String) {
        viewModelScope.launch {
            repository.renameDocument(id, newTitle)
        }
    }

    fun duplicateDocument(entity: OfficeDocumentEntity) {
        viewModelScope.launch {
            repository.duplicateDocument(entity)
            _statusMessage.value = "Создана копия «${entity.title}»"
        }
    }

    fun deleteDocument(entity: OfficeDocumentEntity) {
        viewModelScope.launch {
            repository.deleteDocument(entity.id)
            _statusMessage.value = "Удалено: ${entity.title}"
        }
    }

    fun importFile(uri: Uri, onImported: (String, DocumentType) -> Unit) {
        viewModelScope.launch {
            _isImporting.value = true
            val result = FileExportHelper.importFromUri(getApplication(), uri, repository)
            _isImporting.value = false
            result.onSuccess { (id, type) ->
                _statusMessage.value = "Файл успешно импортирован"
                onImported(id, type)
            }.onFailure { err ->
                _statusMessage.value = err.message ?: "Ошибка импорта файла"
            }
        }
    }
}

package com.example.ui.hub

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesomeMosaic
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.data.OfficeDocumentEntity
import com.example.model.DocumentType
import com.example.model.OfficeTemplateItem
import com.example.model.SampleTemplates
import com.example.ui.components.RenameDocumentDialog
import com.example.ui.theme.DocCobalt
import com.example.ui.theme.PermSapphire
import com.example.ui.theme.SheetEmerald
import com.example.ui.theme.SlideAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HubScreen(
    onOpenDocument: (String, DocumentType) -> Unit,
    hubViewModel: HubViewModel = viewModel(),
) {
    val state by hubViewModel.uiState.collectAsStateWithLifecycle()
    var selectedNavTab by remember { mutableIntStateOf(0) } // 0 = Главная, 1 = Шаблоны
    var renameTarget by remember { mutableStateOf<OfficeDocumentEntity?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            hubViewModel.importFile(uri, onOpenDocument)
        }
    }

    LaunchedEffect(state.statusMessage) {
        val msg = state.statusMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        hubViewModel.clearStatus()
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWide = maxWidth >= 700.dp

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = {
                        val defaultType = state.selectedFilter ?: DocumentType.DOCUMENT
                        val tplId = when (defaultType) {
                            DocumentType.DOCUMENT -> "doc_blank"
                            DocumentType.SPREADSHEET -> "sheet_blank"
                            DocumentType.PRESENTATION -> "slide_blank"
                        }
                        hubViewModel.createNewDocument(
                            type = defaultType,
                            templateId = tplId,
                            title = "Новый ${defaultType.labelRu.lowercase()}",
                            onCreated = onOpenDocument,
                        )
                    },
                    containerColor = PermSapphire,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("hub_create_fab"),
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Создать файл")
                }
            },
            bottomBar = {
                if (!isWide) {
                    NavigationBar {
                        NavigationBarItem(
                            selected = selectedNavTab == 0,
                            onClick = { selectedNavTab = 0 },
                            icon = { Icon(Icons.Default.Home, contentDescription = null) },
                            label = { Text("Файлы") },
                            modifier = Modifier.testTag("nav_files_tab"),
                        )
                        NavigationBarItem(
                            selected = selectedNavTab == 1,
                            onClick = { selectedNavTab = 1 },
                            icon = { Icon(Icons.Default.AutoAwesomeMosaic, contentDescription = null) },
                            label = { Text("Шаблоны") },
                            modifier = Modifier.testTag("nav_templates_tab"),
                        )
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (isWide) {
                    NavigationRail(
                        modifier = Modifier
                            .fillMaxHeight()
                            .statusBarsPadding(),
                    ) {
                        Spacer(Modifier.height(12.dp))
                        NavigationRailItem(
                            selected = selectedNavTab == 0,
                            onClick = { selectedNavTab = 0 },
                            icon = { Icon(Icons.Default.Home, contentDescription = null) },
                            label = { Text("Файлы") },
                        )
                        NavigationRailItem(
                            selected = selectedNavTab == 1,
                            onClick = { selectedNavTab = 1 },
                            icon = { Icon(Icons.Default.AutoAwesomeMosaic, contentDescription = null) },
                            label = { Text("Шаблоны") },
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background),
                ) {
                    HubHeader(
                        isImporting = state.isImporting,
                        onImportClick = {
                            importLauncher.launch(
                                arrayOf(
                                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                    "*/*",
                                )
                            )
                        },
                    )

                    if (selectedNavTab == 0) {
                        FilesDashboardContent(
                            state = state,
                            isWide = isWide,
                            onSearchChange = hubViewModel::updateSearchQuery,
                            onFilterSelect = hubViewModel::selectFilter,
                            onCreateQuick = { type ->
                                val tpl = when (type) {
                                    DocumentType.DOCUMENT -> "doc_blank"
                                    DocumentType.SPREADSHEET -> "sheet_blank"
                                    DocumentType.PRESENTATION -> "slide_blank"
                                }
                                hubViewModel.createNewDocument(
                                    type = type,
                                    templateId = tpl,
                                    title = "Новый ${type.labelRu.lowercase()}",
                                    onCreated = onOpenDocument,
                                )
                            },
                            onOpen = { entity ->
                                val t = runCatching { DocumentType.valueOf(entity.type) }
                                    .getOrDefault(DocumentType.DOCUMENT)
                                onOpenDocument(entity.id, t)
                            },
                            onTogglePin = hubViewModel::togglePin,
                            onRename = { renameTarget = it },
                            onDuplicate = hubViewModel::duplicateDocument,
                            onDelete = hubViewModel::deleteDocument,
                        )
                    } else {
                        TemplatesGalleryContent(
                            isWide = isWide,
                            onSelectTemplate = { tpl ->
                                hubViewModel.createNewDocument(
                                    type = tpl.type,
                                    templateId = tpl.id,
                                    title = tpl.title,
                                    onCreated = onOpenDocument,
                                )
                            },
                        )
                    }
                }
            }
        }
    }

    renameTarget?.let { target ->
        RenameDocumentDialog(
            initialTitle = target.title,
            onDismiss = { renameTarget = null },
            onConfirm = { newTitle ->
                hubViewModel.renameDocument(target.id, newTitle)
                renameTarget = null
            },
        )
    }
}

@Composable
private fun HubHeader(
    isImporting: Boolean,
    onImportClick: () -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_perm_office_emblem),
                    contentDescription = "Логотип Perm Office",
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(10.dp)),
                )
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Perm Office",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = "Автономный офисный пакет",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                OutlinedButton(
                    onClick = onImportClick,
                    modifier = Modifier.testTag("hub_import_button"),
                ) {
                    Icon(
                        imageVector = Icons.Default.FileOpen,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("Импорт")
                }
            }
            if (isImporting) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun FilesDashboardContent(
    state: HubUiState,
    isWide: Boolean,
    onSearchChange: (String) -> Unit,
    onFilterSelect: (DocumentType?) -> Unit,
    onCreateQuick: (DocumentType) -> Unit,
    onOpen: (OfficeDocumentEntity) -> Unit,
    onTogglePin: (OfficeDocumentEntity) -> Unit,
    onRename: (OfficeDocumentEntity) -> Unit,
    onDuplicate: (OfficeDocumentEntity) -> Unit,
    onDelete: (OfficeDocumentEntity) -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                QuickModuleCard(
                    title = "Документ",
                    subtitle = "DOCX / PDF",
                    icon = Icons.Default.Description,
                    accent = DocCobalt,
                    testTag = "create_doc_card",
                    modifier = Modifier.weight(1f),
                    onClick = { onCreateQuick(DocumentType.DOCUMENT) },
                )
                QuickModuleCard(
                    title = "Таблица",
                    subtitle = "XLSX / Формулы",
                    icon = Icons.Default.GridOn,
                    accent = SheetEmerald,
                    testTag = "create_sheet_card",
                    modifier = Modifier.weight(1f),
                    onClick = { onCreateQuick(DocumentType.SPREADSHEET) },
                )
                QuickModuleCard(
                    title = "Слайды",
                    subtitle = "PPTX / Показ",
                    icon = Icons.Default.Slideshow,
                    accent = SlideAmber,
                    testTag = "create_slide_card",
                    modifier = Modifier.weight(1f),
                    onClick = { onCreateQuick(DocumentType.PRESENTATION) },
                )
            }
        }

        item {
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Поиск документов, таблиц, слайдов…") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (state.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Очистить")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hub_search_input"),
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(
                    selected = state.selectedFilter == null,
                    onClick = { onFilterSelect(null) },
                    label = { Text("Все") },
                )
                DocumentType.entries.forEach { type ->
                    FilterChip(
                        selected = state.selectedFilter == type,
                        onClick = { onFilterSelect(if (state.selectedFilter == type) null else type) },
                        label = { Text(type.labelRu) },
                    )
                }
            }
        }

        if (state.documents.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Default.Folder,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(48.dp),
                        )
                        Text(
                            text = "Нет подходящих файлов",
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Text(
                            text = "Создайте новый документ выше или импортируйте DOCX, XLSX или PPTX с телефона",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        } else if (isWide) {
            items(state.documents.chunked(2)) { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    pair.forEach { doc ->
                        DocumentListCard(
                            entity = doc,
                            modifier = Modifier.weight(1f),
                            onOpen = { onOpen(doc) },
                            onTogglePin = { onTogglePin(doc) },
                            onRename = { onRename(doc) },
                            onDuplicate = { onDuplicate(doc) },
                            onDelete = { onDelete(doc) },
                        )
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        } else {
            items(state.documents, key = { it.id }) { doc ->
                DocumentListCard(
                    entity = doc,
                    modifier = Modifier.fillMaxWidth(),
                    onOpen = { onOpen(doc) },
                    onTogglePin = { onTogglePin(doc) },
                    onRename = { onRename(doc) },
                    onDuplicate = { onDuplicate(doc) },
                    onDelete = { onDelete(doc) },
                )
            }
        }
    }
}

@Composable
private fun QuickModuleCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, accent.copy(alpha = 0.28f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accent.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.size(20.dp))
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun DocumentListCard(
    entity: OfficeDocumentEntity,
    modifier: Modifier = Modifier,
    onOpen: () -> Unit,
    onTogglePin: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
) {
    val docType = runCatching { DocumentType.valueOf(entity.type) }.getOrDefault(DocumentType.DOCUMENT)
    val (accent, icon) = when (docType) {
        DocumentType.DOCUMENT -> DocCobalt to Icons.Default.Description
        DocumentType.SPREADSHEET -> SheetEmerald to Icons.Default.GridOn
        DocumentType.PRESENTATION -> SlideAmber to Icons.Default.Slideshow
    }
    var menuExpanded by remember { mutableStateOf(false) }
    val dateLabel = remember(entity.updatedAt) {
        SimpleDateFormat("dd MMM, HH:mm", Locale("ru", "RU")).format(Date(entity.updatedAt))
    }

    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
            .clickable(onClick = onOpen)
            .testTag("doc_card_${entity.id}"),
        color = MaterialTheme.colorScheme.surface,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accent.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = docType.labelRu, tint = accent)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = entity.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = entity.previewSnippet,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = "${docType.labelRu} • .$ {docType.extension.uppercase()} • $dateLabel".replace(". ", "."),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = onTogglePin) {
                Icon(
                    imageVector = if (entity.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                    contentDescription = if (entity.isPinned) "Открепить" else "Закрепить",
                    tint = if (entity.isPinned) accent else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Box {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Действия")
                }
                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                ) {
                    DropdownMenuItem(
                        text = { Text("Переименовать") },
                        leadingIcon = { Icon(Icons.Default.DriveFileRenameOutline, null) },
                        onClick = { menuExpanded = false; onRename() },
                    )
                    DropdownMenuItem(
                        text = { Text("Дублировать") },
                        leadingIcon = { Icon(Icons.Default.ContentCopy, null) },
                        onClick = { menuExpanded = false; onDuplicate() },
                    )
                    DropdownMenuItem(
                        text = { Text("Удалить") },
                        leadingIcon = { Icon(Icons.Default.DeleteOutline, null) },
                        onClick = { menuExpanded = false; onDelete() },
                    )
                }
            }
        }
    }
}

@Composable
private fun TemplatesGalleryContent(
    isWide: Boolean,
    onSelectTemplate: (OfficeTemplateItem) -> Unit,
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(if (isWide) 3 else 1),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        items(SampleTemplates.templates, key = { it.id }) { tpl ->
            val (accent, icon) = when (tpl.type) {
                DocumentType.DOCUMENT -> DocCobalt to Icons.Default.Description
                DocumentType.SPREADSHEET -> SheetEmerald to Icons.Default.GridOn
                DocumentType.PRESENTATION -> SlideAmber to Icons.Default.Slideshow
            }
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                    .clickable { onSelectTemplate(tpl) }
                    .testTag("template_${tpl.id}"),
                color = MaterialTheme.colorScheme.surface,
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(accent.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(icon, contentDescription = null, tint = accent)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(tpl.title, style = MaterialTheme.typography.titleMedium)
                        Text(
                            tpl.subtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

package com.example.ui.spreadsheet

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.OfficeRepository
import com.example.engine.FileExportHelper
import com.example.engine.FormulaEngine
import com.example.engine.OoxmlSpreadsheetCodec
import com.example.engine.PdfExportEngine
import com.example.model.CellData
import com.example.model.CellNumberFormat
import com.example.model.ChartKind
import com.example.model.ChartSpec
import com.example.model.SheetModel
import com.example.model.TextAlignMode
import com.example.model.WorkbookModel
import com.example.model.cellKey
import com.example.model.cellRefName
import com.example.model.colIndexToName
import com.example.model.parseCellKey
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SpreadsheetUiState(
    val docId: String = "",
    val title: String = "Таблица",
    val workbook: WorkbookModel = WorkbookModel(),
    val selectedRow: Int = 0,
    val selectedCol: Int = 0,
    val formulaInput: String = "",
    val isSaved: Boolean = true,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val statusMessage: String? = null,
    val isLoading: Boolean = true,
) {
    val activeSheet: SheetModel
        get() = workbook.sheets.getOrElse(workbook.activeSheetIndex) { workbook.sheets.first() }

    val activeCellRef: String
        get() = cellRefName(selectedRow, selectedCol)

    val activeCell: CellData
        get() = activeSheet.cells[cellKey(selectedRow, selectedCol)] ?: CellData()
}

class SpreadsheetViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = OfficeRepository(application)

    private val _uiState = MutableStateFlow(SpreadsheetUiState())
    val uiState: StateFlow<SpreadsheetUiState> = _uiState.asStateFlow()

    private val undoStack = ArrayDeque<WorkbookModel>()
    private val redoStack = ArrayDeque<WorkbookModel>()
    private var saveJob: Job? = null

    fun load(docId: String) {
        if (_uiState.value.docId == docId && !_uiState.value.isLoading) return
        viewModelScope.launch {
            val entity = repository.getEntity(docId)
            val wb = repository.loadWorkbook(docId)
            undoStack.clear()
            redoStack.clear()
            val firstCell = wb.sheets.firstOrNull()?.cells?.get(cellKey(0, 0))?.rawInput.orEmpty()
            _uiState.value = SpreadsheetUiState(
                docId = docId,
                title = entity?.title ?: "Таблица",
                workbook = wb,
                selectedRow = 0,
                selectedCol = 0,
                formulaInput = firstCell,
                isSaved = true,
                isLoading = false,
            )
        }
    }

    fun clearStatus() {
        _uiState.update { it.copy(statusMessage = null) }
    }

    fun selectCell(row: Int, col: Int) {
        commitFormulaIfDirty()
        val sheet = _uiState.value.activeSheet
        val raw = sheet.cells[cellKey(row, col)]?.rawInput.orEmpty()
        _uiState.update {
            it.copy(
                selectedRow = row.coerceIn(0, sheet.rowCount - 1),
                selectedCol = col.coerceIn(0, sheet.colCount - 1),
                formulaInput = raw,
            )
        }
    }

    fun updateFormulaInput(text: String) {
        _uiState.update { it.copy(formulaInput = text) }
    }

    fun commitFormulaInput() {
        val st = _uiState.value
        val key = cellKey(st.selectedRow, st.selectedCol)
        val raw = st.formulaInput
        updateActiveSheet(pushHistory = true) { sheet ->
            val current = sheet.cells[key] ?: CellData()
            val updatedCells = sheet.cells.toMutableMap()
            if (raw.isEmpty() && current.bgColorHex == null && !current.bold && !current.italic) {
                updatedCells.remove(key)
            } else {
                updatedCells[key] = current.copy(rawInput = raw)
            }
            FormulaEngine.recalculateSheet(sheet.copy(cells = updatedCells))
        }
    }

    private fun commitFormulaIfDirty() {
        val st = _uiState.value
        val key = cellKey(st.selectedRow, st.selectedCol)
        val stored = st.activeSheet.cells[key]?.rawInput.orEmpty()
        if (st.formulaInput != stored) {
            commitFormulaInput()
        }
    }

    fun insertFunctionTemplate(fnName: String) {
        val r = _uiState.value.selectedRow
        val c = _uiState.value.selectedCol
        val colName = colIndexToName(c)
        val template = when (fnName) {
            "IF" -> "=IF(${colName}${r.coerceAtLeast(1)}>=0,\"Да\",\"Нет\")"
            "ROUND" -> "=ROUND(${colName}${r.coerceAtLeast(1)},2)"
            "ABS" -> "=ABS(${colName}${r.coerceAtLeast(1)})"
            else -> {
                val endRow = r.coerceAtLeast(1)
                "=$fnName(${colName}2:${colName}$endRow)"
            }
        }
        _uiState.update { it.copy(formulaInput = template) }
    }

    fun applyAutoSum() {
        val st = _uiState.value
        val r = st.selectedRow
        val c = st.selectedCol
        val colName = colIndexToName(c)
        var startRow = r - 1
        while (startRow >= 0 && st.activeSheet.cells[cellKey(startRow, c)]?.rawInput?.isNotBlank() == true) {
            startRow--
        }
        val fromR = (startRow + 2).coerceAtLeast(1)
        val toR = r.coerceAtLeast(fromR)
        val formula = "=SUM(${colName}$fromR:${colName}$toR)"
        _uiState.update { it.copy(formulaInput = formula) }
        commitFormulaInput()
    }

    fun toggleBold() = updateActiveCellStyle { it.copy(bold = !it.bold) }
    fun toggleItalic() = updateActiveCellStyle { it.copy(italic = !it.italic) }
    fun toggleUnderline() = updateActiveCellStyle { it.copy(underline = !it.underline) }
    fun setAlign(align: TextAlignMode) = updateActiveCellStyle { it.copy(align = align) }
    fun setCellFill(hex: String?) = updateActiveCellStyle { it.copy(bgColorHex = hex) }
    fun setCellTextColor(hex: String?) = updateActiveCellStyle { it.copy(textColorHex = hex ?: "#111827") }

    fun setNumberFormat(format: CellNumberFormat) {
        val st = _uiState.value
        val key = cellKey(st.selectedRow, st.selectedCol)
        updateActiveSheet(pushHistory = true) { sheet ->
            val current = sheet.cells[key] ?: CellData()
            val updated = sheet.cells + (key to current.copy(numberFormat = format))
            FormulaEngine.recalculateSheet(sheet.copy(cells = updated))
        }
    }

    fun clearActiveCell() {
        val st = _uiState.value
        val key = cellKey(st.selectedRow, st.selectedCol)
        _uiState.update { it.copy(formulaInput = "") }
        updateActiveSheet(pushHistory = true) { sheet ->
            val updated = sheet.cells.toMutableMap().apply { remove(key) }
            FormulaEngine.recalculateSheet(sheet.copy(cells = updated))
        }
    }

    fun insertRowAtSelection() {
        val targetRow = _uiState.value.selectedRow
        updateActiveSheet(pushHistory = true) { sheet ->
            val shifted = mutableMapOf<String, CellData>()
            sheet.cells.forEach { (k, cell) ->
                val rc = parseCellKey(k) ?: return@forEach
                val newR = if (rc.first >= targetRow) rc.first + 1 else rc.first
                if (newR < sheet.rowCount + 1) shifted[cellKey(newR, rc.second)] = cell
            }
            FormulaEngine.recalculateSheet(sheet.copy(rowCount = sheet.rowCount + 1, cells = shifted))
        }
    }

    fun deleteRowAtSelection() {
        val targetRow = _uiState.value.selectedRow
        updateActiveSheet(pushHistory = true) { sheet ->
            val shifted = mutableMapOf<String, CellData>()
            sheet.cells.forEach { (k, cell) ->
                val rc = parseCellKey(k) ?: return@forEach
                when {
                    rc.first < targetRow -> shifted[k] = cell
                    rc.first > targetRow -> shifted[cellKey(rc.first - 1, rc.second)] = cell
                }
            }
            FormulaEngine.recalculateSheet(sheet.copy(cells = shifted))
        }
    }

    fun insertColAtSelection() {
        val targetCol = _uiState.value.selectedCol
        updateActiveSheet(pushHistory = true) { sheet ->
            val shifted = mutableMapOf<String, CellData>()
            sheet.cells.forEach { (k, cell) ->
                val rc = parseCellKey(k) ?: return@forEach
                val newC = if (rc.second >= targetCol) rc.second + 1 else rc.second
                shifted[cellKey(rc.first, newC)] = cell
            }
            FormulaEngine.recalculateSheet(sheet.copy(colCount = sheet.colCount + 1, cells = shifted))
        }
    }

    fun deleteColAtSelection() {
        val targetCol = _uiState.value.selectedCol
        updateActiveSheet(pushHistory = true) { sheet ->
            val shifted = mutableMapOf<String, CellData>()
            sheet.cells.forEach { (k, cell) ->
                val rc = parseCellKey(k) ?: return@forEach
                when {
                    rc.second < targetCol -> shifted[k] = cell
                    rc.second > targetCol -> shifted[cellKey(rc.first, rc.second - 1)] = cell
                }
            }
            FormulaEngine.recalculateSheet(sheet.copy(cells = shifted))
        }
    }

    fun sortActiveColumn(ascending: Boolean) {
        val col = _uiState.value.selectedCol
        updateActiveSheet(pushHistory = true) { sheet ->
            // Keep row 0 as header, sort data rows (1..maxUsedRow) that have values
            val maxRow = sheet.cells.keys.mapNotNull { parseCellKey(it)?.first }.maxOrNull() ?: 0
            if (maxRow < 2) return@updateActiveSheet sheet

            val dataRowIndices = (1..maxRow).filter { r ->
                (0 until sheet.colCount).any { c ->
                    sheet.cells[cellKey(r, c)]?.rawInput?.isNotBlank() == true
                }
            }
            if (dataRowIndices.size < 2) return@updateActiveSheet sheet

            val rowsData = dataRowIndices.map { r ->
                (0 until sheet.colCount).associateWith { c -> sheet.cells[cellKey(r, c)] }
            }
            val sortedRows = rowsData.sortedWith { a, b ->
                val va = a[col]?.evaluatedValue.orEmpty()
                val vb = b[col]?.evaluatedValue.orEmpty()
                val na = va.replace(" ", "").replace("₽", "").replace(",", ".").toDoubleOrNull()
                val nb = vb.replace(" ", "").replace("₽", "").replace(",", ".").toDoubleOrNull()
                val cmp = if (na != null && nb != null) na.compareTo(nb) else va.compareTo(vb, ignoreCase = true)
                if (ascending) cmp else -cmp
            }

            val newCells = sheet.cells.filterKeys { k ->
                val r = parseCellKey(k)?.first ?: 0
                r !in dataRowIndices
            }.toMutableMap()

            sortedRows.forEachIndexed { idx, rowMap ->
                val targetR = dataRowIndices[idx]
                rowMap.forEach { (c, cell) ->
                    if (cell != null) newCells[cellKey(targetR, c)] = cell
                }
            }
            FormulaEngine.recalculateSheet(sheet.copy(cells = newCells))
        }
        _uiState.update {
            it.copy(statusMessage = if (ascending) "Отсортировано А → Я" else "Отсортировано Я → А")
        }
    }

    fun addChart(title: String, kind: ChartKind, labelRange: String, valueRange: String) {
        val chart = ChartSpec(
            title = title.ifBlank { "Диаграмма" },
            kind = kind,
            labelRange = labelRange.uppercase(),
            valueRange = valueRange.uppercase(),
        )
        updateActiveSheet(pushHistory = true) { sheet ->
            sheet.copy(charts = sheet.charts + chart)
        }
    }

    fun deleteChart(chartId: String) {
        updateActiveSheet(pushHistory = true) { sheet ->
            sheet.copy(charts = sheet.charts.filterNot { it.id == chartId })
        }
    }

    fun selectSheet(index: Int) {
        commitFormulaIfDirty()
        val sheets = _uiState.value.workbook.sheets
        val safeIdx = index.coerceIn(0, sheets.lastIndex)
        val raw = sheets[safeIdx].cells[cellKey(0, 0)]?.rawInput.orEmpty()
        _uiState.update {
            it.copy(
                workbook = it.workbook.copy(activeSheetIndex = safeIdx),
                selectedRow = 0,
                selectedCol = 0,
                formulaInput = raw,
            )
        }
    }

    fun addSheet() {
        commitFormulaIfDirty()
        val count = _uiState.value.workbook.sheets.size + 1
        val newSheet = SheetModel(name = "Лист $count")
        applyWorkbookChange(pushHistory = true) { wb ->
            wb.copy(
                activeSheetIndex = wb.sheets.size,
                sheets = wb.sheets + newSheet,
            )
        }
        _uiState.update { it.copy(selectedRow = 0, selectedCol = 0, formulaInput = "") }
    }

    fun rename(newTitle: String) {
        val clean = newTitle.trim()
        if (clean.isEmpty()) return
        _uiState.update { it.copy(title = clean) }
        viewModelScope.launch {
            repository.saveWorkbook(_uiState.value.docId, clean, _uiState.value.workbook)
        }
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val prev = undoStack.removeLast()
        redoStack.addLast(_uiState.value.workbook)
        val sheet = prev.sheets.getOrElse(prev.activeSheetIndex) { prev.sheets.first() }
        val raw = sheet.cells[cellKey(_uiState.value.selectedRow, _uiState.value.selectedCol)]?.rawInput.orEmpty()
        _uiState.update {
            it.copy(
                workbook = prev,
                formulaInput = raw,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                isSaved = false,
            )
        }
        scheduleSave()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val next = redoStack.removeLast()
        undoStack.addLast(_uiState.value.workbook)
        val sheet = next.sheets.getOrElse(next.activeSheetIndex) { next.sheets.first() }
        val raw = sheet.cells[cellKey(_uiState.value.selectedRow, _uiState.value.selectedCol)]?.rawInput.orEmpty()
        _uiState.update {
            it.copy(
                workbook = next,
                formulaInput = raw,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                isSaved = false,
            )
        }
        scheduleSave()
    }

    fun exportPdfToUri(uri: Uri) {
        commitFormulaIfDirty()
        viewModelScope.launch {
            val st = _uiState.value
            FileExportHelper.writeToUri(getApplication(), uri) { out ->
                PdfExportEngine.exportWorkbook(st.workbook, st.title, out)
            }.onSuccess {
                _uiState.update { it.copy(statusMessage = "PDF сохранён") }
            }.onFailure { err ->
                _uiState.update { it.copy(statusMessage = err.message ?: "Ошибка экспорта PDF") }
            }
        }
    }

    fun exportXlsxToUri(uri: Uri) {
        commitFormulaIfDirty()
        viewModelScope.launch {
            val st = _uiState.value
            FileExportHelper.writeToUri(getApplication(), uri) { out ->
                OoxmlSpreadsheetCodec.exportXlsx(st.workbook, out)
            }.onSuccess {
                _uiState.update { it.copy(statusMessage = "XLSX сохранён") }
            }.onFailure { err ->
                _uiState.update { it.copy(statusMessage = err.message ?: "Ошибка экспорта XLSX") }
            }
        }
    }

    fun shareFile(asPdf: Boolean, onIntentReady: (Intent) -> Unit) {
        commitFormulaIfDirty()
        viewModelScope.launch {
            val st = _uiState.value
            val ext = if (asPdf) "pdf" else "xlsx"
            val mime = if (asPdf) "application/pdf"
            else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            val name = FileExportHelper.safeFileName(st.title, ext)
            FileExportHelper.createShareIntent(getApplication(), name, mime) { out ->
                if (asPdf) PdfExportEngine.exportWorkbook(st.workbook, st.title, out)
                else OoxmlSpreadsheetCodec.exportXlsx(st.workbook, out)
            }.onSuccess(onIntentReady)
                .onFailure { err ->
                    _uiState.update { it.copy(statusMessage = err.message ?: "Ошибка отправки") }
                }
        }
    }

    private fun updateActiveCellStyle(transform: (CellData) -> CellData) {
        val st = _uiState.value
        val key = cellKey(st.selectedRow, st.selectedCol)
        updateActiveSheet(pushHistory = true) { sheet ->
            val current = sheet.cells[key] ?: CellData()
            sheet.copy(cells = sheet.cells + (key to transform(current)))
        }
    }

    private fun updateActiveSheet(pushHistory: Boolean, transform: (SheetModel) -> SheetModel) {
        applyWorkbookChange(pushHistory) { wb ->
            val idx = wb.activeSheetIndex.coerceIn(0, wb.sheets.lastIndex)
            val updatedSheets = wb.sheets.mapIndexed { i, s -> if (i == idx) transform(s) else s }
            wb.copy(sheets = updatedSheets)
        }
    }

    private fun applyWorkbookChange(pushHistory: Boolean, transform: (WorkbookModel) -> WorkbookModel) {
        val current = _uiState.value.workbook
        val updated = transform(current)
        if (updated == current) return
        if (pushHistory) {
            if (undoStack.size >= 30) undoStack.removeFirst()
            undoStack.addLast(current)
            redoStack.clear()
        }
        _uiState.update {
            it.copy(
                workbook = updated,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                isSaved = false,
            )
        }
        scheduleSave()
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(400)
            val st = _uiState.value
            if (st.docId.isNotEmpty()) {
                repository.saveWorkbook(st.docId, st.title, st.workbook)
                _uiState.update { it.copy(isSaved = true) }
            }
        }
    }
}

package com.example.ui.spreadsheet

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.engine.FormulaEngine
import com.example.model.ChartKind
import com.example.model.ChartSpec
import com.example.model.SheetModel
import com.example.ui.theme.ChartPalette
import kotlin.math.max
import kotlin.math.min

@Composable
fun SpreadsheetChartCard(
    sheet: SheetModel,
    chart: ChartSpec,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val values = FormulaEngine.extractNumericSeries(sheet, chart.valueRange)
    val labels = FormulaEngine.extractLabelSeries(sheet, chart.labelRange)

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(chart.title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${chart.kind.labelRu} • ${chart.labelRange} / ${chart.valueRange}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Удалить диаграмму")
                }
            }

            Spacer(Modifier.height(10.dp))

            if (values.isEmpty()) {
                Text(
                    "Нет числовых данных в диапазоне ${chart.valueRange}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp),
                ) {
                    val w = size.width
                    val h = size.height
                    val padH = 16f
                    val chartH = h - padH * 2
                    val maxVal = (values.maxOrNull() ?: 1.0).coerceAtLeast(1.0)

                    // Grid lines
                    for (i in 0..3) {
                        val y = padH + chartH * (i / 3f)
                        drawLine(
                            color = Color(0xFFE5E7EB),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1.5f,
                        )
                    }

                    when (chart.kind) {
                        ChartKind.COLUMN -> {
                            val step = w / values.size.coerceAtLeast(1)
                            val barW = (step * 0.56f).coerceAtMost(72f)
                            values.forEachIndexed { idx, v ->
                                val ratio = (max(0.0, v) / maxVal).toFloat()
                                val bh = ratio * chartH
                                val left = idx * step + (step - barW) / 2f
                                val top = padH + chartH - bh
                                drawRoundRect(
                                    color = ChartPalette[idx % ChartPalette.size],
                                    topLeft = Offset(left, top),
                                    size = Size(barW, bh),
                                    cornerRadius = CornerRadius(8f, 8f),
                                )
                            }
                        }
                        ChartKind.LINE -> {
                            val step = if (values.size <= 1) w else w / (values.size - 1)
                            val path = Path()
                            val points = values.mapIndexed { idx, v ->
                                val x = if (values.size == 1) w / 2f else idx * step
                                val y = padH + chartH - (max(0.0, v) / maxVal).toFloat() * chartH
                                Offset(x, y)
                            }
                            points.forEachIndexed { i, pt ->
                                if (i == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
                            }
                            drawPath(
                                path = path,
                                color = ChartPalette[0],
                                style = Stroke(width = 5f),
                            )
                            points.forEachIndexed { i, pt ->
                                drawCircle(
                                    color = ChartPalette[i % ChartPalette.size],
                                    radius = 8f,
                                    center = pt,
                                )
                            }
                        }
                        ChartKind.PIE -> {
                            val total = values.sumOf { max(0.0, it) }.coerceAtLeast(1.0)
                            val diameter = min(w, h) * 0.86f
                            val topLeft = Offset((w - diameter) / 2f, (h - diameter) / 2f)
                            var startAngle = -90f
                            values.forEachIndexed { idx, v ->
                                val sweep = (max(0.0, v) / total * 360.0).toFloat()
                                drawArc(
                                    color = ChartPalette[idx % ChartPalette.size],
                                    startAngle = startAngle,
                                    sweepAngle = sweep,
                                    useCenter = true,
                                    topLeft = topLeft,
                                    size = Size(diameter, diameter),
                                )
                                startAngle += sweep
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Compact legend
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    values.forEachIndexed { idx, v ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(ChartPalette[idx % ChartPalette.size]),
                            )
                            Text(
                                text = labels.getOrElse(idx) { "Эл. ${idx + 1}" },
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = FormulaEngine.formatNumber(v, com.example.model.CellNumberFormat.GENERAL),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                }
            }
        }
    }
}

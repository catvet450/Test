package com.example.ui.spreadsheet

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.SortByAlpha
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.engine.FileExportHelper
import com.example.model.CellNumberFormat
import com.example.model.ChartKind
import com.example.model.DocumentType
import com.example.model.TextAlignMode
import com.example.model.cellKey
import com.example.model.colIndexToName
import com.example.ui.components.ColorPaletteDialog
import com.example.ui.components.EditorTopHeader
import com.example.ui.components.FileBackstageSheet
import com.example.ui.components.OfficeRibbonBar
import com.example.ui.components.RenameDocumentDialog
import com.example.ui.components.RibbonGroupDivider
import com.example.ui.components.RibbonIconButton
import com.example.ui.components.RibbonTextChip
import com.example.ui.components.parseHexColor
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.SheetEmerald

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpreadsheetEditorScreen(
    docId: String,
    onBack: () -> Unit,
    vm: SpreadsheetViewModel = viewModel(),
) {
    LaunchedEffect(docId) { vm.load(docId) }
    val state by vm.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var ribbonTab by remember { mutableIntStateOf(0) }
    var ribbonExpanded by remember { mutableStateOf(true) }
    var showFileMenu by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showFillColorDialog by remember { mutableStateOf(false) }
    var showTextColorDialog by remember { mutableStateOf(false) }
    var showAddChartDialog by remember { mutableStateOf(false) }
    var showChartsSheet by remember { mutableStateOf(false) }

    val pdfExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf"),
    ) { uri -> uri?.let { vm.exportPdfToUri(it) } }

    val xlsxExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    ) { uri -> uri?.let { vm.exportXlsxToUri(it) } }

    LaunchedEffect(state.statusMessage) {
        val msg = state.statusMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        vm.clearStatus()
    }

    val activeCell = state.activeCell
    val sheet = state.activeSheet

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column {
                EditorTopHeader(
                    title = state.title,
                    moduleAccent = SheetEmerald,
                    isSaved = state.isSaved,
                    canUndo = state.canUndo,
                    canRedo = state.canRedo,
                    onBack = onBack,
                    onRenameClick = { showRenameDialog = true },
                    onUndo = vm::undo,
                    onRedo = vm::redo,
                    onFileMenuClick = { showFileMenu = true },
                    extraAction = {
                        if (sheet.charts.isNotEmpty()) {
                            IconButton(
                                onClick = { showChartsSheet = true },
                                modifier = Modifier.testTag("open_charts_btn"),
                            ) {
                                Icon(
                                    Icons.Default.BarChart,
                                    contentDescription = "Диаграммы",
                                    tint = SheetEmerald,
                                )
                            }
                        }
                    },
                )
                OfficeRibbonBar(
                    tabs = listOf("Главная", "Вставка", "Формулы", "Данные"),
                    selectedTabIndex = ribbonTab,
                    onSelectTab = { ribbonTab = it; ribbonExpanded = true },
                    isExpanded = ribbonExpanded,
                    onToggleExpanded = { ribbonExpanded = !ribbonExpanded },
                    onFileClick = { showFileMenu = true },
                    moduleAccent = SheetEmerald,
                ) {
                    when (ribbonTab) {
                        0 -> { // Главная
                            RibbonIconButton(
                                icon = Icons.Default.FormatBold,
                                selected = activeCell.bold,
                                accentColor = SheetEmerald,
                                testTag = "sheet_bold_btn",
                                onClick = vm::toggleBold,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatItalic,
                                selected = activeCell.italic,
                                accentColor = SheetEmerald,
                                testTag = "sheet_italic_btn",
                                onClick = vm::toggleItalic,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatUnderlined,
                                selected = activeCell.underline,
                                accentColor = SheetEmerald,
                                testTag = "sheet_underline_btn",
                                onClick = vm::toggleUnderline,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatColorFill,
                                accentColor = SheetEmerald,
                                testTag = "sheet_fill_btn",
                                onClick = { showFillColorDialog = true },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatColorText,
                                accentColor = SheetEmerald,
                                testTag = "sheet_text_color_btn",
                                onClick = { showTextColorDialog = true },
                            )
                            RibbonGroupDivider()
                            RibbonIconButton(
                                icon = Icons.AutoMirrored.Filled.FormatAlignLeft,
                                selected = activeCell.align == TextAlignMode.LEFT,
                                accentColor = SheetEmerald,
                                testTag = "sheet_align_left",
                                onClick = { vm.setAlign(TextAlignMode.LEFT) },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatAlignCenter,
                                selected = activeCell.align == TextAlignMode.CENTER,
                                accentColor = SheetEmerald,
                                testTag = "sheet_align_center",
                                onClick = { vm.setAlign(TextAlignMode.CENTER) },
                            )
                            RibbonIconButton(
                                icon = Icons.AutoMirrored.Filled.FormatAlignRight,
                                selected = activeCell.align == TextAlignMode.RIGHT,
                                accentColor = SheetEmerald,
                                testTag = "sheet_align_right",
                                onClick = { vm.setAlign(TextAlignMode.RIGHT) },
                            )
                            RibbonGroupDivider()
                            CellNumberFormat.entries.forEach { fmt ->
                                RibbonTextChip(
                                    text = fmt.labelRu,
                                    selected = activeCell.numberFormat == fmt,
                                    accentColor = SheetEmerald,
                                    testTag = "sheet_fmt_${fmt.name}",
                                    onClick = { vm.setNumberFormat(fmt) },
                                )
                            }
                            RibbonGroupDivider()
                            RibbonIconButton(
                                icon = Icons.Default.Functions,
                                label = "Автосумма",
                                accentColor = SheetEmerald,
                                testTag = "sheet_autosum_btn",
                                onClick = vm::applyAutoSum,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.DeleteSweep,
                                label = "Очистить",
                                accentColor = MaterialTheme.colorScheme.error,
                                testTag = "sheet_clear_cell",
                                onClick = vm::clearActiveCell,
                            )
                        }
                        1 -> { // Вставка
                            RibbonIconButton(
                                icon = Icons.Default.BarChart,
                                label = "Диаграмма",
                                accentColor = SheetEmerald,
                                testTag = "sheet_insert_chart_btn",
                                onClick = { showAddChartDialog = true },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.Add,
                                label = "Строка +",
                                accentColor = SheetEmerald,
                                testTag = "sheet_add_row_btn",
                                onClick = vm::insertRowAtSelection,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.Add,
                                label = "Столбец +",
                                accentColor = SheetEmerald,
                                testTag = "sheet_add_col_btn",
                                onClick = vm::insertColAtSelection,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.Add,
                                label = "Новый лист",
                                accentColor = SheetEmerald,
                                testTag = "sheet_add_sheet_btn",
                                onClick = vm::addSheet,
                            )
                        }
                        2 -> { // Формулы
                            listOf("SUM", "AVERAGE", "MIN", "MAX", "COUNT", "IF", "ROUND", "ABS").forEach { fn ->
                                RibbonTextChip(
                                    text = "=$fn()",
                                    accentColor = SheetEmerald,
                                    testTag = "sheet_fn_$fn",
                                    onClick = { vm.insertFunctionTemplate(fn) },
                                )
                            }
                        }
                        3 -> { // Данные
                            RibbonIconButton(
                                icon = Icons.Default.SortByAlpha,
                                label = "А → Я",
                                accentColor = SheetEmerald,
                                testTag = "sheet_sort_asc",
                                onClick = { vm.sortActiveColumn(ascending = true) },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.SortByAlpha,
                                label = "Я → А",
                                accentColor = SheetEmerald,
                                testTag = "sheet_sort_desc",
                                onClick = { vm.sortActiveColumn(ascending = false) },
                            )
                            RibbonGroupDivider()
                            RibbonTextChip(
                                text = "Удалить строку",
                                accentColor = MaterialTheme.colorScheme.error,
                                testTag = "sheet_del_row",
                                onClick = vm::deleteRowAtSelection,
                            )
                            RibbonTextChip(
                                text = "Удалить столбец",
                                accentColor = MaterialTheme.colorScheme.error,
                                testTag = "sheet_del_col",
                                onClick = vm::deleteColAtSelection,
                            )
                            if (sheet.charts.isNotEmpty()) {
                                RibbonGroupDivider()
                                RibbonIconButton(
                                    icon = Icons.Default.BarChart,
                                    label = "Графики (${sheet.charts.size})",
                                    accentColor = SheetEmerald,
                                    testTag = "sheet_view_charts",
                                    onClick = { showChartsSheet = true },
                                )
                            }
                        }
                    }
                }
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
                .navigationBarsPadding(),
        ) {
            // Formula Bar (fx)
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(SheetEmerald.copy(alpha = 0.14f))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                    ) {
                        Text(
                            text = state.activeCellRef,
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold,
                            color = SheetEmerald,
                            fontSize = 13.sp,
                        )
                    }
                    Text(
                        text = "fx",
                        fontFamily = JetBrainsMonoFamily,
                        fontStyle = FontStyle.Italic,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                    ) {
                        if (state.formulaInput.isEmpty()) {
                            Text(
                                text = "Значение или =SUM(B2:B5)…",
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        BasicTextField(
                            value = state.formulaInput,
                            onValueChange = vm::updateFormulaInput,
                            singleLine = true,
                            textStyle = TextStyle(
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                            ),
                            cursorBrush = SolidColor(SheetEmerald),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { vm.commitFormulaInput() }),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("formula_input_field"),
                        )
                    }
                    IconButton(
                        onClick = vm::commitFormulaInput,
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("formula_commit_btn"),
                    ) {
                        Icon(Icons.Default.Check, contentDescription = "Применить", tint = SheetEmerald)
                    }
                    IconButton(
                        onClick = { vm.updateFormulaInput("") },
                        modifier = Modifier.size(36.dp),
                    ) {
                        Icon(Icons.Default.Clear, contentDescription = "Стереть ввод")
                    }
                }
            }
            HorizontalDivider()

            // Synchronized 2D Scrollable Spreadsheet Grid
            val hScroll = rememberScrollState()
            val vScroll = rememberScrollState()
            val rowHeaderWidth = 42.dp
            val cellWidth = 96.dp
            val cellHeight = 36.dp
            val visibleRows = minOf(sheet.rowCount, 40)
            val visibleCols = minOf(sheet.colCount, 16)

            Column(modifier = Modifier.weight(1f)) {
                // Sticky Column Header Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Box(
                        modifier = Modifier
                            .width(rowHeaderWidth)
                            .height(30.dp)
                            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                    )
                    Row(modifier = Modifier.horizontalScroll(hScroll)) {
                        for (c in 0 until visibleCols) {
                            val isSelectedCol = c == state.selectedCol
                            Box(
                                modifier = Modifier
                                    .width(cellWidth)
                                    .height(30.dp)
                                    .background(
                                        if (isSelectedCol) SheetEmerald.copy(alpha = 0.16f)
                                        else MaterialTheme.colorScheme.surfaceVariant,
                                    )
                                    .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    text = colIndexToName(c),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelectedCol) SheetEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }

                // Scrollable Body Rows
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(vScroll),
                ) {
                    // Sticky Row Headers
                    Column {
                        for (r in 0 until visibleRows) {
                            val isSelectedRow = r == state.selectedRow
                            Box(
                                modifier = Modifier
                                    .width(rowHeaderWidth)
                                    .height(cellHeight)
                                    .background(
                                        if (isSelectedRow) SheetEmerald.copy(alpha = 0.16f)
                                        else MaterialTheme.colorScheme.surfaceVariant,
                                    )
                                    .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    text = "${r + 1}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSelectedRow) SheetEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }

                    // Cells Grid
                    Column(modifier = Modifier.horizontalScroll(hScroll)) {
                        for (r in 0 until visibleRows) {
                            Row {
                                for (c in 0 until visibleCols) {
                                    val cell = sheet.cells[cellKey(r, c)]
                                    val isSelected = r == state.selectedRow && c == state.selectedCol
                                    val bg = cell?.bgColorHex?.let { parseHexColor(it, Color.White) } ?: Color.White
                                    val fg = parseHexColor(cell?.textColorHex, Color(0xFF111827))

                                    Box(
                                        modifier = Modifier
                                            .width(cellWidth)
                                            .height(cellHeight)
                                            .background(bg)
                                            .border(
                                                width = if (isSelected) 2.dp else 0.5.dp,
                                                color = if (isSelected) SheetEmerald else Color(0xFFD1D5DB),
                                            )
                                            .clickable { vm.selectCell(r, c) }
                                            .padding(horizontal = 6.dp)
                                            .testTag("cell_${r}_$c"),
                                        contentAlignment = when (cell?.align) {
                                            TextAlignMode.RIGHT -> Alignment.CenterEnd
                                            TextAlignMode.CENTER -> Alignment.Center
                                            else -> Alignment.CenterStart
                                        },
                                    ) {
                                        Text(
                                            text = cell?.evaluatedValue.orEmpty(),
                                            fontSize = 12.sp,
                                            fontFamily = if (cell?.evaluatedValue?.any { it.isDigit() } == true) JetBrainsMonoFamily else MaterialTheme.typography.bodyMedium.fontFamily,
                                            fontWeight = if (cell?.bold == true) FontWeight.Bold else FontWeight.Normal,
                                            fontStyle = if (cell?.italic == true) FontStyle.Italic else FontStyle.Normal,
                                            textDecoration = if (cell?.underline == true) TextDecoration.Underline else TextDecoration.None,
                                            color = fg,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            textAlign = when (cell?.align) {
                                                TextAlignMode.RIGHT -> TextAlign.End
                                                TextAlignMode.CENTER -> TextAlign.Center
                                                else -> TextAlign.Start
                                            },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Sheet Tabs Bar
            HorizontalDivider()
            Surface(color = MaterialTheme.colorScheme.surface) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    state.workbook.sheets.forEachIndexed { idx, s ->
                        val active = idx == state.workbook.activeSheetIndex
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (active) SheetEmerald.copy(alpha = 0.16f)
                                    else MaterialTheme.colorScheme.surfaceVariant,
                                )
                                .border(
                                    1.dp,
                                    if (active) SheetEmerald else MaterialTheme.colorScheme.outlineVariant,
                                    RoundedCornerShape(8.dp),
                                )
                                .clickable { vm.selectSheet(idx) }
                                .padding(horizontal = 12.dp, vertical = 7.dp),
                        ) {
                            Text(
                                text = s.name,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                                color = if (active) SheetEmerald else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                    IconButton(
                        onClick = vm::addSheet,
                        modifier = Modifier.size(34.dp),
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Добавить лист", tint = SheetEmerald)
                    }
                }
            }
        }
    }

    if (showChartsSheet) {
        ModalBottomSheet(onDismissRequest = { showChartsSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Диаграммы листа", style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = { showChartsSheet = false; showAddChartDialog = true }) {
                        Text("+ Добавить")
                    }
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    items(sheet.charts, key = { it.id }) { chart ->
                        SpreadsheetChartCard(
                            sheet = sheet,
                            chart = chart,
                            onDelete = { vm.deleteChart(chart.id) },
                        )
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }

    if (showAddChartDialog) {
        AddChartDialog(
            onDismiss = { showAddChartDialog = false },
            onConfirm = { title, kind, labels, values ->
                vm.addChart(title, kind, labels, values)
                showAddChartDialog = false
                showChartsSheet = true
            },
        )
    }

    if (showFileMenu) {
        FileBackstageSheet(
            title = state.title,
            type = DocumentType.SPREADSHEET,
            onDismiss = { showFileMenu = false },
            onRename = { showRenameDialog = true },
            onExportPdf = {
                pdfExportLauncher.launch(FileExportHelper.safeFileName(state.title, "pdf"))
            },
            onExportOoxml = {
                xlsxExportLauncher.launch(FileExportHelper.safeFileName(state.title, "xlsx"))
            },
            onSharePdf = {
                vm.shareFile(asPdf = true) { intent ->
                    context.startActivity(android.content.Intent.createChooser(intent, "Поделиться PDF"))
                }
            },
            onShareOoxml = {
                vm.shareFile(asPdf = false) { intent ->
                    context.startActivity(android.content.Intent.createChooser(intent, "Поделиться XLSX"))
                }
            },
        )
    }

    if (showRenameDialog) {
        RenameDocumentDialog(
            initialTitle = state.title,
            onDismiss = { showRenameDialog = false },
            onConfirm = { newTitle ->
                vm.rename(newTitle)
                showRenameDialog = false
            },
        )
    }

    if (showFillColorDialog) {
        ColorPaletteDialog(
            title = "Цвет заливки ячейки",
            allowClear = true,
            onDismiss = { showFillColorDialog = false },
            onSelectColor = vm::setCellFill,
        )
    }

    if (showTextColorDialog) {
        ColorPaletteDialog(
            title = "Цвет текста ячейки",
            allowClear = true,
            onDismiss = { showTextColorDialog = false },
            onSelectColor = vm::setCellTextColor,
        )
    }
}

@Composable
private fun AddChartDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, ChartKind, String, String) -> Unit,
) {
    var title by remember { mutableStateOf("Новая диаграмма") }
    var kind by remember { mutableStateOf(ChartKind.COLUMN) }
    var labelsRange by remember { mutableStateOf("A2:A5") }
    var valuesRange by remember { mutableStateOf("B2:B5") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Создать диаграмму") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Заголовок") },
                    singleLine = true,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ChartKind.entries.forEach { k ->
                        RibbonTextChip(
                            text = k.labelRu,
                            selected = kind == k,
                            accentColor = SheetEmerald,
                            testTag = "chart_kind_${k.name}",
                            onClick = { kind = k },
                        )
                    }
                }
                OutlinedTextField(
                    value = labelsRange,
                    onValueChange = { labelsRange = it },
                    label = { Text("Диапазон подписей (напр. A2:A5)") },
                    singleLine = true,
                )
                OutlinedTextField(
                    value = valuesRange,
                    onValueChange = { valuesRange = it },
                    label = { Text("Диапазон значений (напр. C2:C5)") },
                    singleLine = true,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(title, kind, labelsRange, valuesRange) }) {
                Text("Построить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        },
    )
}

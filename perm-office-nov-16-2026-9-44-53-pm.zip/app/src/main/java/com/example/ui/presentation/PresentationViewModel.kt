package com.example.ui.presentation

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.OfficeRepository
import com.example.engine.FileExportHelper
import com.example.engine.OoxmlPresentationCodec
import com.example.engine.PdfExportEngine
import com.example.model.PresentationModel
import com.example.model.SampleTemplates
import com.example.model.SlideElement
import com.example.model.SlideElementKind
import com.example.model.SlideLayoutKind
import com.example.model.SlideModel
import com.example.model.SlideThemePreset
import com.example.model.SlideTransitionKind
import com.example.model.TextAlignMode
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PresentationUiState(
    val docId: String = "",
    val title: String = "Презентация",
    val model: PresentationModel = PresentationModel(slides = listOf(SlideModel())),
    val activeSlideIndex: Int = 0,
    val selectedElementId: String? = null,
    val isSlideshowActive: Boolean = false,
    val isSaved: Boolean = true,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val statusMessage: String? = null,
    val isLoading: Boolean = true,
) {
    val activeSlide: SlideModel
        get() = model.slides.getOrElse(activeSlideIndex) {
            model.slides.firstOrNull() ?: SlideModel()
        }

    val selectedElement: SlideElement?
        get() = activeSlide.elements.firstOrNull { it.id == selectedElementId }
}

class PresentationViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = OfficeRepository(application)

    private val _uiState = MutableStateFlow(PresentationUiState())
    val uiState: StateFlow<PresentationUiState> = _uiState.asStateFlow()

    private val undoStack = ArrayDeque<PresentationModel>()
    private val redoStack = ArrayDeque<PresentationModel>()
    private var saveJob: Job? = null

    fun load(docId: String) {
        if (_uiState.value.docId == docId && !_uiState.value.isLoading) return
        viewModelScope.launch {
            val entity = repository.getEntity(docId)
            val model = repository.loadPresentation(docId)
            undoStack.clear()
            redoStack.clear()
            _uiState.value = PresentationUiState(
                docId = docId,
                title = entity?.title ?: "Презентация",
                model = if (model.slides.isEmpty()) model.copy(slides = listOf(SlideModel())) else model,
                activeSlideIndex = 0,
                isSaved = true,
                isLoading = false,
            )
        }
    }

    fun clearStatus() {
        _uiState.update { it.copy(statusMessage = null) }
    }

    fun selectSlide(index: Int) {
        val maxIdx = _uiState.value.model.slides.lastIndex.coerceAtLeast(0)
        _uiState.update {
            it.copy(
                activeSlideIndex = index.coerceIn(0, maxIdx),
                selectedElementId = null,
            )
        }
    }

    fun selectElement(elementId: String?) {
        _uiState.update { it.copy(selectedElementId = elementId) }
    }

    fun addSlide(layout: SlideLayoutKind) {
        val theme = _uiState.value.model.theme
        val newSlide = SampleTemplates.createSlideFromLayout(layout, theme)
        val insertIdx = (_uiState.value.activeSlideIndex + 1).coerceIn(0, _uiState.value.model.slides.size)
        applyModelChange(pushHistory = true) { model ->
            val list = model.slides.toMutableList()
            list.add(insertIdx, newSlide)
            model.copy(slides = list)
        }
        _uiState.update { it.copy(activeSlideIndex = insertIdx, selectedElementId = null) }
    }

    fun duplicateCurrentSlide() {
        val idx = _uiState.value.activeSlideIndex
        val current = _uiState.value.activeSlide
        val copySlide = current.copy(
            id = java.util.UUID.randomUUID().toString(),
            elements = current.elements.map { it.copy(id = java.util.UUID.randomUUID().toString()) },
        )
        applyModelChange(pushHistory = true) { model ->
            val list = model.slides.toMutableList()
            list.add(idx + 1, copySlide)
            model.copy(slides = list)
        }
        _uiState.update { it.copy(activeSlideIndex = idx + 1, selectedElementId = null) }
    }

    fun deleteCurrentSlide() {
        val slides = _uiState.value.model.slides
        if (slides.size <= 1) {
            _uiState.update { it.copy(statusMessage = "Должен остаться хотя бы один слайд") }
            return
        }
        val idx = _uiState.value.activeSlideIndex
        applyModelChange(pushHistory = true) { model ->
            model.copy(slides = model.slides.filterIndexed { i, _ -> i != idx })
        }
        _uiState.update {
            it.copy(
                activeSlideIndex = (idx - 1).coerceAtLeast(0),
                selectedElementId = null,
            )
        }
    }

    fun insertElement(kind: SlideElementKind) {
        val theme = _uiState.value.model.theme
        val newEl = when (kind) {
            SlideElementKind.TEXT -> SlideElement(
                kind = SlideElementKind.TEXT,
                xFraction = 0.14f,
                yFraction = 0.34f,
                widthFraction = 0.72f,
                heightFraction = 0.22f,
                text = "Текстовый блок",
                fontSizeSp = 18f,
                textColorHex = theme.titleHex,
            )
            SlideElementKind.RECTANGLE -> SlideElement(
                kind = SlideElementKind.RECTANGLE,
                xFraction = 0.28f,
                yFraction = 0.28f,
                widthFraction = 0.36f,
                heightFraction = 0.34f,
                fillColorHex = theme.accentHex,
                textColorHex = "#FFFFFF",
                text = "Блок",
                fontSizeSp = 14f,
                align = TextAlignMode.CENTER,
            )
            SlideElementKind.CIRCLE -> SlideElement(
                kind = SlideElementKind.CIRCLE,
                xFraction = 0.36f,
                yFraction = 0.26f,
                widthFraction = 0.24f,
                heightFraction = 0.40f,
                fillColorHex = theme.accentHex,
                textColorHex = "#FFFFFF",
                text = "",
                align = TextAlignMode.CENTER,
            )
            SlideElementKind.ARROW -> SlideElement(
                kind = SlideElementKind.ARROW,
                xFraction = 0.30f,
                yFraction = 0.40f,
                widthFraction = 0.34f,
                heightFraction = 0.18f,
                fillColorHex = theme.accentHex,
            )
            SlideElementKind.TABLE -> SlideElement(
                kind = SlideElementKind.TABLE,
                xFraction = 0.10f,
                yFraction = 0.26f,
                widthFraction = 0.80f,
                heightFraction = 0.48f,
                fillColorHex = "#FFFFFF",
                textColorHex = "#111827",
                tableRows = listOf(
                    listOf("Пункт", "Значение", "Статус"),
                    listOf("Этап 1", "100%", "Готово"),
                    listOf("Этап 2", "75%", "В работе"),
                ),
            )
        }
        updateActiveSlide(pushHistory = true) { slide ->
            slide.copy(elements = slide.elements + newEl)
        }
        _uiState.update { it.copy(selectedElementId = newEl.id) }
    }

    fun deleteSelectedElement() {
        val elId = _uiState.value.selectedElementId ?: return
        updateActiveSlide(pushHistory = true) { slide ->
            slide.copy(elements = slide.elements.filterNot { it.id == elId })
        }
        _uiState.update { it.copy(selectedElementId = null) }
    }

    fun moveElement(elementId: String, dxFraction: Float, dyFraction: Float) {
        updateActiveSlide(pushHistory = false) { slide ->
            slide.copy(
                elements = slide.elements.map { el ->
                    if (el.id != elementId) el
                    else el.copy(
                        xFraction = (el.xFraction + dxFraction).coerceIn(0f, 1f - el.widthFraction.coerceAtMost(0.95f)),
                        yFraction = (el.yFraction + dyFraction).coerceIn(0f, 1f - el.heightFraction.coerceAtMost(0.95f)),
                    )
                }
            )
        }
    }

    fun resizeElement(elementId: String, dwFraction: Float, dhFraction: Float) {
        updateActiveSlide(pushHistory = false) { slide ->
            slide.copy(
                elements = slide.elements.map { el ->
                    if (el.id != elementId) el
                    else el.copy(
                        widthFraction = (el.widthFraction + dwFraction).coerceIn(0.08f, 1f - el.xFraction),
                        heightFraction = (el.heightFraction + dhFraction).coerceIn(0.08f, 1f - el.yFraction),
                    )
                }
            )
        }
    }

    fun updateSelectedText(newText: String) {
        updateSelectedElement(pushHistory = true) { it.copy(text = newText) }
    }

    fun updateSelectedTableCell(row: Int, col: Int, value: String) {
        updateSelectedElement(pushHistory = false) { el ->
            val updated = el.tableRows.mapIndexed { r, rowList ->
                if (r != row) rowList
                else rowList.mapIndexed { c, cellVal -> if (c == col) value else cellVal }
            }
            el.copy(tableRows = updated)
        }
    }

    fun toggleSelectedBold() = updateSelectedElement(true) { it.copy(bold = !it.bold) }
    fun toggleSelectedItalic() = updateSelectedElement(true) { it.copy(italic = !it.italic) }
    fun setSelectedAlign(align: TextAlignMode) = updateSelectedElement(true) { it.copy(align = align) }
    fun adjustSelectedFontSize(delta: Float) = updateSelectedElement(true) {
        it.copy(fontSizeSp = (it.fontSizeSp + delta).coerceIn(10f, 44f))
    }

    fun setSelectedFillColor(hex: String?) = updateSelectedElement(true) {
        it.copy(fillColorHex = hex)
    }

    fun setSelectedTextColor(hex: String?) = updateSelectedElement(true) {
        it.copy(textColorHex = hex ?: "#111827")
    }

    fun setSlideBackgroundColor(hex: String?) {
        updateActiveSlide(pushHistory = true) { it.copy(bgColorHex = hex ?: "#FFFFFF") }
    }

    fun setSlideTransition(transition: SlideTransitionKind) {
        updateActiveSlide(pushHistory = true) { it.copy(transition = transition) }
    }

    fun applyTheme(theme: SlideThemePreset) {
        applyModelChange(pushHistory = true) { model ->
            model.copy(
                theme = theme,
                slides = model.slides.map { slide ->
                    slide.copy(
                        bgColorHex = theme.bgHex,
                        elements = slide.elements.map { el ->
                            when (el.kind) {
                                SlideElementKind.TEXT -> el.copy(
                                    textColorHex = if (el.bold) theme.titleHex else theme.bodyHex,
                                )
                                SlideElementKind.RECTANGLE, SlideElementKind.CIRCLE, SlideElementKind.ARROW ->
                                    el.copy(fillColorHex = theme.accentHex)
                                SlideElementKind.TABLE -> el
                            }
                        },
                    )
                },
            )
        }
    }

    fun startSlideshow(fromStart: Boolean) {
        _uiState.update {
            it.copy(
                activeSlideIndex = if (fromStart) 0 else it.activeSlideIndex,
                selectedElementId = null,
                isSlideshowActive = true,
            )
        }
    }

    fun stopSlideshow() {
        _uiState.update { it.copy(isSlideshowActive = false) }
    }

    fun rename(newTitle: String) {
        val clean = newTitle.trim()
        if (clean.isEmpty()) return
        _uiState.update { it.copy(title = clean) }
        viewModelScope.launch {
            repository.savePresentation(_uiState.value.docId, clean, _uiState.value.model)
        }
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val prev = undoStack.removeLast()
        redoStack.addLast(_uiState.value.model)
        _uiState.update {
            it.copy(
                model = prev,
                activeSlideIndex = it.activeSlideIndex.coerceIn(0, prev.slides.lastIndex.coerceAtLeast(0)),
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                isSaved = false,
            )
        }
        scheduleSave()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val next = redoStack.removeLast()
        undoStack.addLast(_uiState.value.model)
        _uiState.update {
            it.copy(
                model = next,
                activeSlideIndex = it.activeSlideIndex.coerceIn(0, next.slides.lastIndex.coerceAtLeast(0)),
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                isSaved = false,
            )
        }
        scheduleSave()
    }

    fun exportPdfToUri(uri: Uri) {
        viewModelScope.launch {
            val st = _uiState.value
            FileExportHelper.writeToUri(getApplication(), uri) { out ->
                PdfExportEngine.exportPresentation(st.model, out)
            }.onSuccess {
                _uiState.update { it.copy(statusMessage = "PDF сохранён") }
            }.onFailure { err ->
                _uiState.update { it.copy(statusMessage = err.message ?: "Ошибка экспорта PDF") }
            }
        }
    }

    fun exportPptxToUri(uri: Uri) {
        viewModelScope.launch {
            val st = _uiState.value
            FileExportHelper.writeToUri(getApplication(), uri) { out ->
                OoxmlPresentationCodec.exportPptx(st.model, out)
            }.onSuccess {
                _uiState.update { it.copy(statusMessage = "PPTX сохранён") }
            }.onFailure { err ->
                _uiState.update { it.copy(statusMessage = err.message ?: "Ошибка экспорта PPTX") }
            }
        }
    }

    fun shareFile(asPdf: Boolean, onIntentReady: (Intent) -> Unit) {
        viewModelScope.launch {
            val st = _uiState.value
            val ext = if (asPdf) "pdf" else "pptx"
            val mime = if (asPdf) "application/pdf"
            else "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            val name = FileExportHelper.safeFileName(st.title, ext)
            FileExportHelper.createShareIntent(getApplication(), name, mime) { out ->
                if (asPdf) PdfExportEngine.exportPresentation(st.model, out)
                else OoxmlPresentationCodec.exportPptx(st.model, out)
            }.onSuccess(onIntentReady)
                .onFailure { err ->
                    _uiState.update { it.copy(statusMessage = err.message ?: "Ошибка отправки") }
                }
        }
    }

    private fun updateSelectedElement(pushHistory: Boolean, transform: (SlideElement) -> SlideElement) {
        val elId = _uiState.value.selectedElementId ?: return
        updateActiveSlide(pushHistory) { slide ->
            slide.copy(elements = slide.elements.map { if (it.id == elId) transform(it) else it })
        }
    }

    private fun updateActiveSlide(pushHistory: Boolean, transform: (SlideModel) -> SlideModel) {
        val idx = _uiState.value.activeSlideIndex
        applyModelChange(pushHistory) { model ->
            model.copy(slides = model.slides.mapIndexed { i, s -> if (i == idx) transform(s) else s })
        }
    }

    private fun applyModelChange(pushHistory: Boolean, transform: (PresentationModel) -> PresentationModel) {
        val current = _uiState.value.model
        val updated = transform(current)
        if (updated == current) return
        if (pushHistory) {
            if (undoStack.size >= 30) undoStack.removeFirst()
            undoStack.addLast(current)
            redoStack.clear()
        }
        _uiState.update {
            it.copy(
                model = updated,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                isSaved = false,
            )
        }
        scheduleSave()
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(400)
            val st = _uiState.value
            if (st.docId.isNotEmpty()) {
                repository.savePresentation(st.docId, st.title, st.model)
                _uiState.update { it.copy(isSaved = true) }
            }
        }
    }
}

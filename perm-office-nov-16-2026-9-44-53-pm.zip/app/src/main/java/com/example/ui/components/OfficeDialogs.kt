package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.DocumentType
import com.example.ui.theme.OfficeColorSwatches

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileBackstageSheet(
    title: String,
    type: DocumentType,
    onDismiss: () -> Unit,
    onRename: () -> Unit,
    onExportPdf: () -> Unit,
    onExportOoxml: () -> Unit,
    onSharePdf: () -> Unit,
    onShareOoxml: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 16.dp),
        ) {
            Text(
                text = "Файл • $title",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("Переименовать") },
                supportingContent = { Text("Изменить название документа") },
                leadingContent = { Icon(Icons.Default.DriveFileRenameOutline, contentDescription = null) },
                modifier = Modifier
                    .clickable { onDismiss(); onRename() }
                    .testTag("file_menu_rename"),
            )
            ListItem(
                headlineContent = { Text("Сохранить как PDF") },
                supportingContent = { Text("Многостраничный векторный PDF на устройство") },
                leadingContent = { Icon(Icons.Default.PictureAsPdf, contentDescription = null) },
                modifier = Modifier
                    .clickable { onDismiss(); onExportPdf() }
                    .testTag("file_menu_export_pdf"),
            )
            ListItem(
                headlineContent = { Text("Сохранить как .${type.extension.uppercase()}") },
                supportingContent = { Text("Стандартный файл для настольного офиса") },
                leadingContent = { Icon(Icons.Default.Description, contentDescription = null) },
                modifier = Modifier
                    .clickable { onDismiss(); onExportOoxml() }
                    .testTag("file_menu_export_ooxml"),
            )
            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
            ListItem(
                headlineContent = { Text("Поделиться PDF") },
                leadingContent = { Icon(Icons.Default.Share, contentDescription = null) },
                modifier = Modifier
                    .clickable { onDismiss(); onSharePdf() }
                    .testTag("file_menu_share_pdf"),
            )
            ListItem(
                headlineContent = { Text("Поделиться .${type.extension.uppercase()}") },
                leadingContent = { Icon(Icons.Default.Share, contentDescription = null) },
                modifier = Modifier
                    .clickable { onDismiss(); onShareOoxml() }
                    .testTag("file_menu_share_ooxml"),
            )
        }
    }
}

@Composable
fun RenameDocumentDialog(
    initialTitle: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initialTitle) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Название файла") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                label = { Text("Введите имя") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("rename_text_field"),
            )
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (text.isNotBlank()) onConfirm(text.trim())
                },
                modifier = Modifier.testTag("rename_confirm_button"),
            ) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        },
    )
}

@Composable
fun ColorPaletteDialog(
    title: String,
    allowClear: Boolean = false,
    onDismiss: () -> Unit,
    onSelectColor: (String?) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OfficeColorSwatches.chunked(4).forEach { rowColors ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                    ) {
                        rowColors.forEach { hex ->
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(parseHexColor(hex))
                                    .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                                    .clickable {
                                        onSelectColor(hex)
                                        onDismiss()
                                    },
                            )
                        }
                    }
                }
                if (allowClear) {
                    Spacer(modifier = Modifier.height(4.dp))
                    TextButton(
                        onClick = {
                            onSelectColor(null)
                            onDismiss()
                        },
                        modifier = Modifier.align(Alignment.End),
                    ) {
                        Text("Сбросить цвет")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Закрыть") }
        },
    )
}

package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = PermSapphire,
    onPrimary = Color.White,
    primaryContainer = PermSapphireLight,
    onPrimaryContainer = PermSapphireDark,
    secondary = DocCobalt,
    onSecondary = Color.White,
    secondaryContainer = DocCobaltContainer,
    onSecondaryContainer = DocCobaltOnContainer,
    tertiary = SheetEmerald,
    onTertiary = Color.White,
    tertiaryContainer = SheetEmeraldContainer,
    onTertiaryContainer = SheetEmeraldOnContainer,
    background = WorkspaceCanvasLight,
    onBackground = WorkspaceTextPrimaryLight,
    surface = WorkspaceSurfaceLight,
    onSurface = WorkspaceTextPrimaryLight,
    surfaceVariant = WorkspaceSurfaceAltLight,
    onSurfaceVariant = WorkspaceTextSecondaryLight,
    outline = WorkspaceBorderLight,
    outlineVariant = WorkspaceBorderLight,
    error = ErrorCrimson,
    onError = Color.White,
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF60A5FA),
    onPrimary = Color(0xFF0A192F),
    primaryContainer = PermSapphire,
    onPrimaryContainer = Color(0xFFEAF0F7),
    secondary = Color(0xFF93C5FD),
    onSecondary = Color(0xFF0A192F),
    secondaryContainer = Color(0xFF1E3A8A),
    onSecondaryContainer = Color(0xFFDBEAFE),
    tertiary = Color(0xFF34D399),
    onTertiary = Color(0xFF064E3B),
    tertiaryContainer = Color(0xFF065F46),
    onTertiaryContainer = Color(0xFFD1FAE5),
    background = WorkspaceCanvasDark,
    onBackground = WorkspaceTextPrimaryDark,
    surface = WorkspaceSurfaceDark,
    onSurface = WorkspaceTextPrimaryDark,
    surfaceVariant = WorkspaceSurfaceAltDark,
    onSurfaceVariant = WorkspaceTextSecondaryDark,
    outline = WorkspaceBorderDark,
    outlineVariant = WorkspaceBorderDark,
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A),
)

val PermOfficeShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(24.dp),
)

@Composable
fun PermOfficeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = PermOfficeTypography,
        shapes = PermOfficeShapes,
        content = content,
    )
}

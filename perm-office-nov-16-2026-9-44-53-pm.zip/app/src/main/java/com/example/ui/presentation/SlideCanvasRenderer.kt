package com.example.ui.presentation

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SlideElement
import com.example.model.SlideElementKind
import com.example.model.SlideModel
import com.example.ui.components.parseHexColor
import com.example.ui.components.toComposeAlign
import com.example.ui.theme.SlideAmber
import kotlin.math.roundToInt

@Composable
fun SlideCanvasView(
    slide: SlideModel,
    selectedElementId: String?,
    isInteractive: Boolean,
    scaleFontFactor: Float = 1f,
    onSelectElement: (String?) -> Unit = {},
    onMoveElement: (String, Float, Float) -> Unit = { _, _, _ -> },
    onResizeElement: (String, Float, Float) -> Unit = { _, _, _ -> },
    onEditElementRequest: (SlideElement) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val bgColor = parseHexColor(slide.bgColorHex, Color.White)
    val density = LocalDensity.current

    BoxWithConstraints(
        modifier = modifier
            .aspectRatio(16f / 9f)
            .shadow(if (isInteractive) 6.dp else 1.dp, RoundedCornerShape(6.dp))
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .let { mod ->
                if (isInteractive) {
                    mod.clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { onSelectElement(null) }
                } else mod
            },
    ) {
        val canvasWidthPx = with(density) { maxWidth.toPx() }.coerceAtLeast(1f)
        val canvasHeightPx = with(density) { maxHeight.toPx() }.coerceAtLeast(1f)

        slide.elements.forEach { element ->
            val isSelected = isInteractive && element.id == selectedElementId
            val leftPx = (element.xFraction * canvasWidthPx).roundToInt()
            val topPx = (element.yFraction * canvasHeightPx).roundToInt()
            val wDp = maxWidth * element.widthFraction
            val hDp = maxHeight * element.heightFraction

            Box(
                modifier = Modifier
                    .offset { IntOffset(leftPx, topPx) }
                    .size(width = wDp, height = hDp)
                    .let { mod ->
                        if (isInteractive) {
                            mod
                                .pointerInput(element.id, canvasWidthPx, canvasHeightPx) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        onSelectElement(element.id)
                                        onMoveElement(
                                            element.id,
                                            dragAmount.x / canvasWidthPx,
                                            dragAmount.y / canvasHeightPx,
                                        )
                                    }
                                }
                                .clickable {
                                    if (isSelected) onEditElementRequest(element)
                                    else onSelectElement(element.id)
                                }
                        } else mod
                    }
                    .border(
                        width = if (isSelected) 2.dp else 0.dp,
                        color = if (isSelected) SlideAmber else Color.Transparent,
                        shape = RoundedCornerShape(4.dp),
                    ),
            ) {
                SlideElementContent(
                    element = element,
                    scaleFontFactor = scaleFontFactor,
                )

                if (isSelected) {
                    // Bottom-right resize handle
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(SlideAmber)
                            .border(2.dp, Color.White, CircleShape)
                            .pointerInput(element.id, canvasWidthPx, canvasHeightPx) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    onResizeElement(
                                        element.id,
                                        dragAmount.x / canvasWidthPx,
                                        dragAmount.y / canvasHeightPx,
                                    )
                                }
                            },
                    )
                }
            }
        }
    }
}

@Composable
private fun SlideElementContent(
    element: SlideElement,
    scaleFontFactor: Float,
) {
    val fill = element.fillColorHex?.let { parseHexColor(it, Color.Transparent) }
    val textColor = parseHexColor(element.textColorHex, Color(0xFF111827))

    when (element.kind) {
        SlideElementKind.RECTANGLE -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape((8 * scaleFontFactor).coerceAtLeast(2f).dp))
                    .background(fill ?: Color.Transparent)
                    .padding((6 * scaleFontFactor).dp),
                contentAlignment = Alignment.Center,
            ) {
                if (element.text.isNotEmpty()) {
                    Text(
                        text = element.text,
                        color = textColor,
                        fontSize = (element.fontSizeSp * scaleFontFactor).sp,
                        fontWeight = if (element.bold) FontWeight.Bold else FontWeight.Normal,
                        fontStyle = if (element.italic) FontStyle.Italic else FontStyle.Normal,
                        textAlign = element.align.toComposeAlign(),
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        SlideElementKind.CIRCLE -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(fill ?: Color(0xFF2563EB))
                    .padding((4 * scaleFontFactor).dp),
                contentAlignment = Alignment.Center,
            ) {
                if (element.text.isNotEmpty()) {
                    Text(
                        text = element.text,
                        color = textColor,
                        fontSize = (element.fontSizeSp * scaleFontFactor).sp,
                        fontWeight = if (element.bold) FontWeight.Bold else FontWeight.Normal,
                        textAlign = element.align.toComposeAlign(),
                    )
                }
            }
        }
        SlideElementKind.ARROW -> {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val path = Path().apply {
                    moveTo(0f, h * 0.30f)
                    lineTo(w * 0.68f, h * 0.30f)
                    lineTo(w * 0.68f, 0f)
                    lineTo(w, h * 0.50f)
                    lineTo(w * 0.68f, h)
                    lineTo(w * 0.68f, h * 0.70f)
                    lineTo(0f, h * 0.70f)
                    close()
                }
                drawPath(path, color = fill ?: Color(0xFF2563EB))
            }
        }
        SlideElementKind.TABLE -> {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(fill ?: Color.White)
                    .border(0.8.dp, Color(0xFFCBD5E1)),
            ) {
                val rows = element.tableRows
                rows.forEachIndexed { rIdx, row ->
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(if (rIdx == 0) Color(0xFF1E3A5F) else (fill ?: Color.White)),
                    ) {
                        row.forEach { cell ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .border(0.5.dp, Color(0xFFCBD5E1))
                                    .padding(horizontal = (4 * scaleFontFactor).dp),
                                contentAlignment = Alignment.CenterStart,
                            ) {
                                Text(
                                    text = cell,
                                    fontSize = (11f * scaleFontFactor).sp,
                                    fontWeight = if (rIdx == 0) FontWeight.Bold else FontWeight.Normal,
                                    color = if (rIdx == 0) Color.White else textColor,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
            }
        }
        SlideElementKind.TEXT -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(fill ?: Color.Transparent)
                    .padding((4 * scaleFontFactor).dp),
            ) {
                Text(
                    text = element.text,
                    color = textColor,
                    fontSize = (element.fontSizeSp * scaleFontFactor).sp,
                    lineHeight = (element.fontSizeSp * 1.28f * scaleFontFactor).sp,
                    fontWeight = if (element.bold) FontWeight.Bold else FontWeight.Normal,
                    fontStyle = if (element.italic) FontStyle.Italic else FontStyle.Normal,
                    textAlign = element.align.toComposeAlign(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

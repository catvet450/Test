package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand & Workspace Palette (Precision Utilitarian)
val PermSapphire = Color(0xFF1E3A5F)
val PermSapphireDark = Color(0xFF142842)
val PermSapphireLight = Color(0xFFEAF0F7)

val WorkspaceCanvasLight = Color(0xFFF3F5F8)
val WorkspaceSurfaceLight = Color(0xFFFFFFFF)
val WorkspaceSurfaceAltLight = Color(0xFFF8FAFC)
val WorkspaceBorderLight = Color(0xFFDCE2EA)
val WorkspaceTextPrimaryLight = Color(0xFF111827)
val WorkspaceTextSecondaryLight = Color(0xFF4B5563)

val WorkspaceCanvasDark = Color(0xFF12161C)
val WorkspaceSurfaceDark = Color(0xFF1B212B)
val WorkspaceSurfaceAltDark = Color(0xFF232B38)
val WorkspaceBorderDark = Color(0xFF313B4B)
val WorkspaceTextPrimaryDark = Color(0xFFF3F4F6)
val WorkspaceTextSecondaryDark = Color(0xFF9CA3AF)

// Module Accent Identities (Original Perm Office Colors)
val DocCobalt = Color(0xFF2563EB)
val DocCobaltContainer = Color(0xFFDBEAFE)
val DocCobaltOnContainer = Color(0xFF1E3A8A)

val SheetEmerald = Color(0xFF059669)
val SheetEmeraldContainer = Color(0xFFD1FAE5)
val SheetEmeraldOnContainer = Color(0xFF064E3B)

val SlideAmber = Color(0xFFD97706)
val SlideAmberContainer = Color(0xFFFEF3C7)
val SlideAmberOnContainer = Color(0xFF78350F)

val ErrorCrimson = Color(0xFFDC2626)
val SuccessGreen = Color(0xFF16A34A)

// Curated Chart & Office Swatches
val ChartPalette = listOf(
    Color(0xFF2563EB),
    Color(0xFF059669),
    Color(0xFFD97706),
    Color(0xFF7C3AED),
    Color(0xFFDB2777),
    Color(0xFF0891B2),
)

val OfficeColorSwatches = listOf(
    "#111827", "#374151", "#6B7280", "#FFFFFF",
    "#1E3A5F", "#2563EB", "#0EA5E9", "#059669",
    "#16A34A", "#D97706", "#DC2626", "#7C3AED",
    "#DBEAFE", "#D1FAE5", "#FEF3C7", "#FEE2E2",
)

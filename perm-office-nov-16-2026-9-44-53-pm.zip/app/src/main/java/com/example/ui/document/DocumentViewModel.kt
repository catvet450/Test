package com.example.ui.document

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.OfficeRepository
import com.example.engine.FileExportHelper
import com.example.engine.OoxmlDocumentCodec
import com.example.engine.PdfExportEngine
import com.example.model.DocBlock
import com.example.model.DocFontKind
import com.example.model.DocPageSettings
import com.example.model.ListKind
import com.example.model.PageMarginPreset
import com.example.model.PageOrientation
import com.example.model.ParagraphStyleKind
import com.example.model.TextAlignMode
import com.example.model.WordDocumentModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DocumentStats(
    val words: Int,
    val charsWithSpaces: Int,
    val charsWithoutSpaces: Int,
    val paragraphs: Int,
    val tables: Int,
)

data class DocumentEditorUiState(
    val docId: String = "",
    val title: String = "Документ",
    val model: WordDocumentModel = WordDocumentModel(),
    val activeBlockId: String? = null,
    val isSaved: Boolean = true,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val showFindBar: Boolean = false,
    val findQuery: String = "",
    val replaceQuery: String = "",
    val zoomScale: Float = 1f,
    val statusMessage: String? = null,
    val isLoading: Boolean = true,
) {
    val activeBlock: DocBlock?
        get() = model.blocks.firstOrNull { it.id == activeBlockId } ?: model.blocks.firstOrNull()
}

class DocumentViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = OfficeRepository(application)

    private val _uiState = MutableStateFlow(DocumentEditorUiState())
    val uiState: StateFlow<DocumentEditorUiState> = _uiState.asStateFlow()

    private val undoStack = ArrayDeque<WordDocumentModel>()
    private val redoStack = ArrayDeque<WordDocumentModel>()
    private var saveJob: Job? = null

    fun load(docId: String) {
        if (_uiState.value.docId == docId && !_uiState.value.isLoading) return
        viewModelScope.launch {
            val entity = repository.getEntity(docId)
            val model = repository.loadWordDocument(docId)
            undoStack.clear()
            redoStack.clear()
            _uiState.value = DocumentEditorUiState(
                docId = docId,
                title = entity?.title ?: "Документ",
                model = model,
                activeBlockId = model.blocks.firstOrNull()?.id,
                isSaved = true,
                isLoading = false,
            )
        }
    }

    fun clearStatus() {
        _uiState.update { it.copy(statusMessage = null) }
    }

    fun selectBlock(blockId: String) {
        _uiState.update { it.copy(activeBlockId = blockId) }
    }

    fun updateBlockText(blockId: String, newText: String, pushHistory: Boolean = false) {
        applyModelChange(pushHistory = pushHistory) { model ->
            model.copy(
                blocks = model.blocks.map { block ->
                    if (block.id == blockId) block.copy(text = newText) else block
                }
            )
        }
    }

    fun addParagraphAfterActive(initialText: String = "") {
        val currentId = _uiState.value.activeBlock?.id
        val newBlock = DocBlock(text = initialText)
        applyModelChange(pushHistory = true) { model ->
            val idx = model.blocks.indexOfFirst { it.id == currentId }
            val updated = model.blocks.toMutableList()
            if (idx >= 0) updated.add(idx + 1, newBlock) else updated.add(newBlock)
            model.copy(blocks = updated)
        }
        _uiState.update { it.copy(activeBlockId = newBlock.id) }
    }

    fun deleteActiveBlock() {
        val blocks = _uiState.value.model.blocks
        if (blocks.size <= 1) {
            applyModelChange(pushHistory = true) { it.copy(blocks = listOf(DocBlock())) }
            _uiState.update { it.copy(activeBlockId = it.model.blocks.first().id) }
            return
        }
        val activeId = _uiState.value.activeBlock?.id ?: return
        val idx = blocks.indexOfFirst { it.id == activeId }.coerceAtLeast(0)
        val remaining = blocks.filterNot { it.id == activeId }
        val nextActive = remaining.getOrElse((idx - 1).coerceAtLeast(0)) { remaining.first() }
        applyModelChange(pushHistory = true) { it.copy(blocks = remaining) }
        _uiState.update { it.copy(activeBlockId = nextActive.id) }
    }

    fun toggleBold() = updateActiveParagraph { it.copy(bold = !it.bold) }
    fun toggleItalic() = updateActiveParagraph { it.copy(italic = !it.italic) }
    fun toggleUnderline() = updateActiveParagraph { it.copy(underline = !it.underline) }
    fun toggleStrikethrough() = updateActiveParagraph { it.copy(strikethrough = !it.strikethrough) }

    fun setAlign(align: TextAlignMode) = updateActiveParagraph { it.copy(align = align) }

    fun setParagraphStyle(style: ParagraphStyleKind) = updateActiveParagraph {
        it.copy(
            style = style,
            fontSizeSp = style.defaultSizeSp,
            bold = style == ParagraphStyleKind.HEADING_1 || style == ParagraphStyleKind.HEADING_2 || style == ParagraphStyleKind.HEADING_3,
            italic = style == ParagraphStyleKind.QUOTE,
        )
    }

    fun toggleList(kind: ListKind) = updateActiveParagraph {
        it.copy(listKind = if (it.listKind == kind) ListKind.NONE else kind)
    }

    fun adjustIndent(delta: Int) = updateActiveParagraph {
        it.copy(indentLevel = (it.indentLevel + delta).coerceIn(0, 4))
    }

    fun adjustFontSize(delta: Float) = updateActiveParagraph {
        it.copy(fontSizeSp = (it.fontSizeSp + delta).coerceIn(10f, 36f))
    }

    fun setFontKind(kind: DocFontKind) = updateActiveParagraph {
        it.copy(fontKind = kind)
    }

    fun setTextColor(hex: String?) = updateActiveParagraph {
        it.copy(textColorHex = hex ?: "#111827")
    }

    fun setHighlightColor(hex: String?) = updateActiveParagraph {
        it.copy(highlightColorHex = hex)
    }

    fun insertTable(rows: Int, cols: Int) {
        val rCount = rows.coerceIn(1, 10)
        val cCount = cols.coerceIn(1, 6)
        val tableRows = List(rCount) { r ->
            List(cCount) { c -> if (r == 0) "Столбец ${c + 1}" else "" }
        }
        val tableBlock = DocBlock(isTable = true, tableRows = tableRows)
        val currentId = _uiState.value.activeBlock?.id
        applyModelChange(pushHistory = true) { model ->
            val idx = model.blocks.indexOfFirst { it.id == currentId }
            val list = model.blocks.toMutableList()
            if (idx >= 0) list.add(idx + 1, tableBlock) else list.add(tableBlock)
            model.copy(blocks = list)
        }
        _uiState.update { it.copy(activeBlockId = tableBlock.id) }
    }

    fun updateTableCell(blockId: String, row: Int, col: Int, value: String) {
        applyModelChange(pushHistory = false) { model ->
            model.copy(
                blocks = model.blocks.map { block ->
                    if (block.id != blockId) block
                    else {
                        val updatedRows = block.tableRows.mapIndexed { rIdx, rList ->
                            if (rIdx != row) rList
                            else rList.mapIndexed { cIdx, cVal -> if (cIdx == col) value else cVal }
                        }
                        block.copy(tableRows = updatedRows)
                    }
                }
            )
        }
    }

    fun addTableRow(blockId: String) {
        applyModelChange(pushHistory = true) { model ->
            model.copy(
                blocks = model.blocks.map { b ->
                    if (b.id != blockId) b
                    else {
                        val cols = b.tableRows.firstOrNull()?.size ?: 2
                        b.copy(tableRows = b.tableRows + listOf(List(cols) { "" }))
                    }
                }
            )
        }
    }

    fun addTableColumn(blockId: String) {
        applyModelChange(pushHistory = true) { model ->
            model.copy(
                blocks = model.blocks.map { b ->
                    if (b.id != blockId) b
                    else b.copy(tableRows = b.tableRows.mapIndexed { r, row ->
                        row + if (r == 0) "Столбец ${row.size + 1}" else ""
                    })
                }
            )
        }
    }

    fun insertDivider() {
        addParagraphAfterActive("────────────────────────")
    }

    fun insertCurrentDate() {
        val formatted = SimpleDateFormat("dd.MM.yyyy", Locale("ru", "RU")).format(Date())
        val active = _uiState.value.activeBlock
        if (active != null && !active.isTable) {
            val sep = if (active.text.isBlank() || active.text.endsWith(" ")) "" else " "
            updateBlockText(active.id, active.text + sep + formatted, pushHistory = true)
        } else {
            addParagraphAfterActive(formatted)
        }
    }

    fun updatePageSettings(transform: (DocPageSettings) -> DocPageSettings) {
        applyModelChange(pushHistory = true) { model ->
            model.copy(pageSettings = transform(model.pageSettings))
        }
    }

    fun toggleOrientation() = updatePageSettings {
        val next = if (it.orientation == PageOrientation.PORTRAIT) PageOrientation.LANDSCAPE else PageOrientation.PORTRAIT
        it.copy(orientation = next)
    }

    fun cycleMargins() = updatePageSettings {
        val all = PageMarginPreset.entries
        val next = all[(all.indexOf(it.margins) + 1) % all.size]
        it.copy(margins = next)
    }

    fun toggleShowPageNumbers() = updatePageSettings {
        it.copy(showPageNumbers = !it.showPageNumbers)
    }

    fun toggleFindBar() {
        _uiState.update { it.copy(showFindBar = !it.showFindBar) }
    }

    fun updateFindQuery(q: String) {
        _uiState.update { it.copy(findQuery = q) }
    }

    fun updateReplaceQuery(q: String) {
        _uiState.update { it.copy(replaceQuery = q) }
    }

    fun replaceAllMatches() {
        val find = _uiState.value.findQuery
        if (find.isEmpty()) return
        val replace = _uiState.value.replaceQuery
        var count = 0
        applyModelChange(pushHistory = true) { model ->
            model.copy(
                blocks = model.blocks.map { block ->
                    if (!block.isTable && block.text.contains(find, ignoreCase = true)) {
                        count++
                        block.copy(text = block.text.replace(find, replace, ignoreCase = true))
                    } else block
                }
            )
        }
        _uiState.update {
            it.copy(statusMessage = if (count > 0) "Заменено в блоках: $count" else "Совпадений не найдено")
        }
    }

    fun setZoom(scale: Float) {
        _uiState.update { it.copy(zoomScale = scale.coerceIn(0.8f, 1.35f)) }
    }

    fun computeStats(): DocumentStats {
        val blocks = _uiState.value.model.blocks
        val textBlocks = blocks.filter { !it.isTable }
        val allText = textBlocks.joinToString(" ") { it.text }
        val words = allText.trim().split(Regex("\\s+")).count { it.isNotBlank() }
        val charsWith = textBlocks.sumOf { it.text.length }
        val charsWithout = textBlocks.sumOf { it.text.count { ch -> !ch.isWhitespace() } }
        return DocumentStats(
            words = words,
            charsWithSpaces = charsWith,
            charsWithoutSpaces = charsWithout,
            paragraphs = textBlocks.size,
            tables = blocks.count { it.isTable },
        )
    }

    fun rename(newTitle: String) {
        val clean = newTitle.trim()
        if (clean.isEmpty()) return
        _uiState.update { it.copy(title = clean) }
        viewModelScope.launch {
            repository.saveWordDocument(_uiState.value.docId, clean, _uiState.value.model)
        }
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val prev = undoStack.removeLast()
        redoStack.addLast(_uiState.value.model)
        _uiState.update {
            it.copy(
                model = prev,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                isSaved = false,
            )
        }
        scheduleSave()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val next = redoStack.removeLast()
        undoStack.addLast(_uiState.value.model)
        _uiState.update {
            it.copy(
                model = next,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                isSaved = false,
            )
        }
        scheduleSave()
    }

    fun exportPdfToUri(uri: Uri) {
        viewModelScope.launch {
            val state = _uiState.value
            FileExportHelper.writeToUri(getApplication(), uri) { out ->
                PdfExportEngine.exportWordDocument(state.model, state.title, out)
            }.onSuccess {
                _uiState.update { it.copy(statusMessage = "PDF сохранён") }
            }.onFailure { err ->
                _uiState.update { it.copy(statusMessage = err.message ?: "Ошибка экспорта PDF") }
            }
        }
    }

    fun exportDocxToUri(uri: Uri) {
        viewModelScope.launch {
            val state = _uiState.value
            FileExportHelper.writeToUri(getApplication(), uri) { out ->
                OoxmlDocumentCodec.exportDocx(state.model, out)
            }.onSuccess {
                _uiState.update { it.copy(statusMessage = "DOCX сохранён") }
            }.onFailure { err ->
                _uiState.update { it.copy(statusMessage = err.message ?: "Ошибка экспорта DOCX") }
            }
        }
    }

    fun shareFile(asPdf: Boolean, onIntentReady: (Intent) -> Unit) {
        viewModelScope.launch {
            val state = _uiState.value
            val ext = if (asPdf) "pdf" else "docx"
            val mime = if (asPdf) "application/pdf"
            else "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            val name = FileExportHelper.safeFileName(state.title, ext)
            FileExportHelper.createShareIntent(getApplication(), name, mime) { out ->
                if (asPdf) PdfExportEngine.exportWordDocument(state.model, state.title, out)
                else OoxmlDocumentCodec.exportDocx(state.model, out)
            }.onSuccess(onIntentReady)
                .onFailure { err ->
                    _uiState.update { it.copy(statusMessage = err.message ?: "Ошибка отправки") }
                }
        }
    }

    private fun updateActiveParagraph(transform: (DocBlock) -> DocBlock) {
        val active = _uiState.value.activeBlock ?: return
        if (active.isTable) return
        applyModelChange(pushHistory = true) { model ->
            model.copy(
                blocks = model.blocks.map { if (it.id == active.id) transform(it) else it }
            )
        }
    }

    private fun applyModelChange(
        pushHistory: Boolean,
        transform: (WordDocumentModel) -> WordDocumentModel,
    ) {
        val current = _uiState.value.model
        val updated = transform(current)
        if (updated == current) return
        if (pushHistory) {
            if (undoStack.size >= 30) undoStack.removeFirst()
            undoStack.addLast(current)
            redoStack.clear()
        }
        _uiState.update {
            it.copy(
                model = updated,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                isSaved = false,
            )
        }
        scheduleSave()
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(400)
            val state = _uiState.value
            if (state.docId.isNotEmpty()) {
                repository.saveWordDocument(state.docId, state.title, state.model)
                _uiState.update { it.copy(isSaved = true) }
            }
        }
    }
}

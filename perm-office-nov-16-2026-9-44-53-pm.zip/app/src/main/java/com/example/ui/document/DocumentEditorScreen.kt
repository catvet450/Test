package com.example.ui.document

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.automirrored.filled.FormatIndentDecrease
import androidx.compose.material.icons.automirrored.filled.FormatIndentIncrease
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FindReplace
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignJustify
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.FormatStrikethrough
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.HorizontalRule
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.engine.FileExportHelper
import com.example.model.DocBlock
import com.example.model.DocFontKind
import com.example.model.DocumentType
import com.example.model.ListKind
import com.example.model.PageOrientation
import com.example.model.ParagraphStyleKind
import com.example.model.TextAlignMode
import com.example.ui.components.ColorPaletteDialog
import com.example.ui.components.EditorTopHeader
import com.example.ui.components.FileBackstageSheet
import com.example.ui.components.OfficeRibbonBar
import com.example.ui.components.RenameDocumentDialog
import com.example.ui.components.RibbonGroupDivider
import com.example.ui.components.RibbonIconButton
import com.example.ui.components.RibbonTextChip
import com.example.ui.components.parseHexColor
import com.example.ui.components.toComposeAlign
import com.example.ui.theme.DocCobalt
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.PlusJakartaSansFamily
import com.example.ui.theme.PtSerifFamily

@Composable
fun DocumentEditorScreen(
    docId: String,
    onBack: () -> Unit,
    vm: DocumentViewModel = viewModel(),
) {
    LaunchedEffect(docId) { vm.load(docId) }
    val state by vm.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var ribbonTab by remember { mutableIntStateOf(0) }
    var ribbonExpanded by remember { mutableStateOf(true) }
    var showFileMenu by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showTextColorDialog by remember { mutableStateOf(false) }
    var showHighlightDialog by remember { mutableStateOf(false) }
    var showInsertTableDialog by remember { mutableStateOf(false) }
    var showStatsDialog by remember { mutableStateOf(false) }

    val pdfExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf"),
    ) { uri -> uri?.let { vm.exportPdfToUri(it) } }

    val docxExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    ) { uri -> uri?.let { vm.exportDocxToUri(it) } }

    LaunchedEffect(state.statusMessage) {
        val msg = state.statusMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        vm.clearStatus()
    }

    val active = state.activeBlock

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column {
                EditorTopHeader(
                    title = state.title,
                    moduleAccent = DocCobalt,
                    isSaved = state.isSaved,
                    canUndo = state.canUndo,
                    canRedo = state.canRedo,
                    onBack = onBack,
                    onRenameClick = { showRenameDialog = true },
                    onUndo = vm::undo,
                    onRedo = vm::redo,
                    onFileMenuClick = { showFileMenu = true },
                )
                OfficeRibbonBar(
                    tabs = listOf("Главная", "Вставка", "Макет", "Обзор"),
                    selectedTabIndex = ribbonTab,
                    onSelectTab = { ribbonTab = it; ribbonExpanded = true },
                    isExpanded = ribbonExpanded,
                    onToggleExpanded = { ribbonExpanded = !ribbonExpanded },
                    onFileClick = { showFileMenu = true },
                    moduleAccent = DocCobalt,
                ) {
                    when (ribbonTab) {
                        0 -> { // Главная
                            RibbonIconButton(
                                icon = Icons.Default.FormatBold,
                                selected = active?.bold == true,
                                accentColor = DocCobalt,
                                testTag = "doc_bold_btn",
                                onClick = vm::toggleBold,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatItalic,
                                selected = active?.italic == true,
                                accentColor = DocCobalt,
                                testTag = "doc_italic_btn",
                                onClick = vm::toggleItalic,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatUnderlined,
                                selected = active?.underline == true,
                                accentColor = DocCobalt,
                                testTag = "doc_underline_btn",
                                onClick = vm::toggleUnderline,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatStrikethrough,
                                selected = active?.strikethrough == true,
                                accentColor = DocCobalt,
                                testTag = "doc_strike_btn",
                                onClick = vm::toggleStrikethrough,
                            )
                            RibbonTextChip(
                                text = "A−",
                                accentColor = DocCobalt,
                                testTag = "doc_size_down",
                                onClick = { vm.adjustFontSize(-2f) },
                            )
                            RibbonTextChip(
                                text = "${active?.fontSizeSp?.toInt() ?: 14}",
                                accentColor = DocCobalt,
                                testTag = "doc_size_label",
                                onClick = { vm.adjustFontSize(2f) },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatColorText,
                                accentColor = DocCobalt,
                                testTag = "doc_text_color_btn",
                                onClick = { showTextColorDialog = true },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatColorFill,
                                accentColor = DocCobalt,
                                testTag = "doc_highlight_btn",
                                onClick = { showHighlightDialog = true },
                            )
                            RibbonGroupDivider()
                            DocFontKind.entries.forEach { fk ->
                                RibbonTextChip(
                                    text = fk.labelRu,
                                    selected = active?.fontKind == fk,
                                    accentColor = DocCobalt,
                                    testTag = "doc_font_${fk.name}",
                                    onClick = { vm.setFontKind(fk) },
                                )
                            }
                            RibbonGroupDivider()
                            RibbonIconButton(
                                icon = Icons.AutoMirrored.Filled.FormatAlignLeft,
                                selected = active?.align == TextAlignMode.LEFT,
                                accentColor = DocCobalt,
                                testTag = "doc_align_left",
                                onClick = { vm.setAlign(TextAlignMode.LEFT) },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatAlignCenter,
                                selected = active?.align == TextAlignMode.CENTER,
                                accentColor = DocCobalt,
                                testTag = "doc_align_center",
                                onClick = { vm.setAlign(TextAlignMode.CENTER) },
                            )
                            RibbonIconButton(
                                icon = Icons.AutoMirrored.Filled.FormatAlignRight,
                                selected = active?.align == TextAlignMode.RIGHT,
                                accentColor = DocCobalt,
                                testTag = "doc_align_right",
                                onClick = { vm.setAlign(TextAlignMode.RIGHT) },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatAlignJustify,
                                selected = active?.align == TextAlignMode.JUSTIFY,
                                accentColor = DocCobalt,
                                testTag = "doc_align_justify",
                                onClick = { vm.setAlign(TextAlignMode.JUSTIFY) },
                            )
                            RibbonIconButton(
                                icon = Icons.AutoMirrored.Filled.FormatListBulleted,
                                selected = active?.listKind == ListKind.BULLET,
                                accentColor = DocCobalt,
                                testTag = "doc_bullet_list",
                                onClick = { vm.toggleList(ListKind.BULLET) },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatListNumbered,
                                selected = active?.listKind == ListKind.NUMBERED,
                                accentColor = DocCobalt,
                                testTag = "doc_num_list",
                                onClick = { vm.toggleList(ListKind.NUMBERED) },
                            )
                            RibbonIconButton(
                                icon = Icons.AutoMirrored.Filled.FormatIndentDecrease,
                                accentColor = DocCobalt,
                                testTag = "doc_indent_dec",
                                onClick = { vm.adjustIndent(-1) },
                            )
                            RibbonIconButton(
                                icon = Icons.AutoMirrored.Filled.FormatIndentIncrease,
                                accentColor = DocCobalt,
                                testTag = "doc_indent_inc",
                                onClick = { vm.adjustIndent(1) },
                            )
                            RibbonGroupDivider()
                            ParagraphStyleKind.entries.forEach { st ->
                                RibbonTextChip(
                                    text = st.labelRu,
                                    selected = active?.style == st,
                                    accentColor = DocCobalt,
                                    testTag = "doc_style_${st.name}",
                                    onClick = { vm.setParagraphStyle(st) },
                                )
                            }
                        }
                        1 -> { // Вставка
                            RibbonIconButton(
                                icon = Icons.Default.Add,
                                label = "Абзац",
                                accentColor = DocCobalt,
                                testTag = "doc_insert_paragraph",
                                onClick = { vm.addParagraphAfterActive() },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.TableChart,
                                label = "Таблица",
                                accentColor = DocCobalt,
                                testTag = "doc_insert_table",
                                onClick = { showInsertTableDialog = true },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.HorizontalRule,
                                label = "Разделитель",
                                accentColor = DocCobalt,
                                testTag = "doc_insert_divider",
                                onClick = vm::insertDivider,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.CalendarToday,
                                label = "Дата",
                                accentColor = DocCobalt,
                                testTag = "doc_insert_date",
                                onClick = vm::insertCurrentDate,
                            )
                            RibbonGroupDivider()
                            RibbonIconButton(
                                icon = Icons.Default.DeleteOutline,
                                label = "Удалить блок",
                                accentColor = MaterialTheme.colorScheme.error,
                                testTag = "doc_delete_block",
                                onClick = vm::deleteActiveBlock,
                            )
                        }
                        2 -> { // Макет
                            val settings = state.model.pageSettings
                            RibbonIconButton(
                                icon = Icons.Default.ScreenRotation,
                                label = settings.orientation.labelRu,
                                accentColor = DocCobalt,
                                testTag = "doc_orientation_btn",
                                onClick = vm::toggleOrientation,
                            )
                            RibbonTextChip(
                                text = "Поля: ${settings.margins.labelRu}",
                                accentColor = DocCobalt,
                                testTag = "doc_margins_btn",
                                onClick = vm::cycleMargins,
                            )
                            RibbonTextChip(
                                text = "Номера стр.",
                                selected = settings.showPageNumbers,
                                accentColor = DocCobalt,
                                testTag = "doc_page_numbers_btn",
                                onClick = vm::toggleShowPageNumbers,
                            )
                            RibbonGroupDivider()
                            RibbonIconButton(
                                icon = Icons.Default.ZoomOut,
                                accentColor = DocCobalt,
                                testTag = "doc_zoom_out",
                                onClick = { vm.setZoom(state.zoomScale - 0.1f) },
                            )
                            Text(
                                text = "${(state.zoomScale * 100).toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(horizontal = 4.dp),
                            )
                            RibbonIconButton(
                                icon = Icons.Default.ZoomIn,
                                accentColor = DocCobalt,
                                testTag = "doc_zoom_in",
                                onClick = { vm.setZoom(state.zoomScale + 0.1f) },
                            )
                        }
                        3 -> { // Обзор
                            RibbonIconButton(
                                icon = Icons.Default.FindReplace,
                                label = "Поиск и замена",
                                selected = state.showFindBar,
                                accentColor = DocCobalt,
                                testTag = "doc_find_replace_btn",
                                onClick = vm::toggleFindBar,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.Analytics,
                                label = "Статистика",
                                accentColor = DocCobalt,
                                testTag = "doc_stats_btn",
                                onClick = { showStatsDialog = true },
                            )
                        }
                    }
                }
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
                .navigationBarsPadding()
                .background(MaterialTheme.colorScheme.background),
        ) {
            AnimatedVisibility(visible = state.showFindBar) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedTextField(
                            value = state.findQuery,
                            onValueChange = vm::updateFindQuery,
                            placeholder = { Text("Найти") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = state.replaceQuery,
                            onValueChange = vm::updateReplaceQuery,
                            placeholder = { Text("Заменить") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        Button(onClick = vm::replaceAllMatches) {
                            Text("Заменить")
                        }
                        IconButton(onClick = vm::toggleFindBar) {
                            Icon(Icons.Default.Close, contentDescription = "Закрыть поиск")
                        }
                    }
                }
            }

            // Document Desk + Paper Sheet
            val scrollState = rememberScrollState()
            val settings = state.model.pageSettings
            val maxPaperWidth = if (settings.orientation == PageOrientation.LANDSCAPE) 860.dp else 640.dp
            val paperPadding = (settings.margins.dpPadding * state.zoomScale).dp

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 12.dp, vertical = 16.dp),
                contentAlignment = Alignment.TopCenter,
            ) {
                Surface(
                    modifier = Modifier
                        .widthIn(max = maxPaperWidth)
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(4.dp)),
                    color = Color.White,
                    shadowElevation = 4.dp,
                    shape = RoundedCornerShape(4.dp),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(paperPadding),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        var numberedIdx = 0
                        state.model.blocks.forEach { block ->
                            if (block.listKind == ListKind.NUMBERED) numberedIdx++ else numberedIdx = 0
                            val isSelected = block.id == state.activeBlock?.id

                            if (block.isTable) {
                                EditableDocTable(
                                    block = block,
                                    isSelected = isSelected,
                                    onSelect = { vm.selectBlock(block.id) },
                                    onCellChange = { r, c, v -> vm.updateTableCell(block.id, r, c, v) },
                                    onAddRow = { vm.addTableRow(block.id) },
                                    onAddCol = { vm.addTableColumn(block.id) },
                                )
                            } else {
                                EditableDocParagraph(
                                    block = block,
                                    numberedIndex = numberedIdx,
                                    zoomScale = state.zoomScale,
                                    lineSpacingMultiplier = settings.lineSpacingMultiplier,
                                    isSelected = isSelected,
                                    onFocus = { vm.selectBlock(block.id) },
                                    onTextChange = { vm.updateBlockText(block.id, it) },
                                )
                            }
                        }

                        Spacer(Modifier.height(24.dp))
                        if (settings.showPageNumbers) {
                            HorizontalDivider(color = Color(0xFFE5E7EB))
                            Text(
                                text = "Стр. 1 • Perm Office",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF9CA3AF),
                                modifier = Modifier
                                    .align(Alignment.End)
                                    .padding(top = 6.dp),
                            )
                        }
                    }
                }
            }
        }
    }

    if (showFileMenu) {
        FileBackstageSheet(
            title = state.title,
            type = DocumentType.DOCUMENT,
            onDismiss = { showFileMenu = false },
            onRename = { showRenameDialog = true },
            onExportPdf = {
                pdfExportLauncher.launch(FileExportHelper.safeFileName(state.title, "pdf"))
            },
            onExportOoxml = {
                docxExportLauncher.launch(FileExportHelper.safeFileName(state.title, "docx"))
            },
            onSharePdf = {
                vm.shareFile(asPdf = true) { intent ->
                    context.startActivity(android.content.Intent.createChooser(intent, "Поделиться PDF"))
                }
            },
            onShareOoxml = {
                vm.shareFile(asPdf = false) { intent ->
                    context.startActivity(android.content.Intent.createChooser(intent, "Поделиться DOCX"))
                }
            },
        )
    }

    if (showRenameDialog) {
        RenameDocumentDialog(
            initialTitle = state.title,
            onDismiss = { showRenameDialog = false },
            onConfirm = { newTitle ->
                vm.rename(newTitle)
                showRenameDialog = false
            },
        )
    }

    if (showTextColorDialog) {
        ColorPaletteDialog(
            title = "Цвет текста",
            allowClear = true,
            onDismiss = { showTextColorDialog = false },
            onSelectColor = vm::setTextColor,
        )
    }

    if (showHighlightDialog) {
        ColorPaletteDialog(
            title = "Цвет выделения",
            allowClear = true,
            onDismiss = { showHighlightDialog = false },
            onSelectColor = vm::setHighlightColor,
        )
    }

    if (showInsertTableDialog) {
        InsertTableSizeDialog(
            onDismiss = { showInsertTableDialog = false },
            onInsert = { rows, cols ->
                vm.insertTable(rows, cols)
                showInsertTableDialog = false
            },
        )
    }

    if (showStatsDialog) {
        val stats = vm.computeStats()
        AlertDialog(
            onDismissRequest = { showStatsDialog = false },
            title = { Text("Статистика документа") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Слов: ${stats.words}")
                    Text("Знаков (с пробелами): ${stats.charsWithSpaces}")
                    Text("Знаков (без пробелов): ${stats.charsWithoutSpaces}")
                    Text("Абзацев: ${stats.paragraphs}")
                    Text("Таблиц: ${stats.tables}")
                }
            },
            confirmButton = {
                TextButton(onClick = { showStatsDialog = false }) { Text("Закрыть") }
            },
        )
    }
}

@Composable
private fun EditableDocParagraph(
    block: DocBlock,
    numberedIndex: Int,
    zoomScale: Float,
    lineSpacingMultiplier: Float,
    isSelected: Boolean,
    onFocus: () -> Unit,
    onTextChange: (String) -> Unit,
) {
    val fontFamily = when (block.fontKind) {
        DocFontKind.SERIF -> PtSerifFamily
        DocFontKind.MONO -> JetBrainsMonoFamily
        DocFontKind.SANS -> PlusJakartaSansFamily
    }
    val decoration = when {
        block.underline && block.strikethrough -> TextDecoration.combine(
            listOf(TextDecoration.Underline, TextDecoration.LineThrough)
        )
        block.underline -> TextDecoration.Underline
        block.strikethrough -> TextDecoration.LineThrough
        else -> TextDecoration.None
    }
    val textColor = parseHexColor(block.textColorHex, Color(0xFF111827))
    val highlightBg = block.highlightColorHex?.let { parseHexColor(it, Color.Transparent) } ?: Color.Transparent
    val fontSize = (block.fontSizeSp * zoomScale).sp

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = (block.indentLevel * 18).dp)
            .background(
                if (isSelected) Color(0xFFF8FAFC) else Color.Transparent,
                RoundedCornerShape(4.dp),
            )
            .let { mod ->
                if (block.style == ParagraphStyleKind.QUOTE) {
                    mod
                        .border(0.dp, Color.Transparent)
                        .padding(start = 10.dp)
                } else mod
            },
        verticalAlignment = Alignment.Top,
    ) {
        if (block.style == ParagraphStyleKind.QUOTE) {
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(26.dp)
                    .background(DocCobalt),
            )
            Spacer(Modifier.width(8.dp))
        }
        when (block.listKind) {
            ListKind.BULLET -> {
                Text(
                    text = "•",
                    fontSize = fontSize,
                    color = textColor,
                    modifier = Modifier.padding(end = 8.dp),
                )
            }
            ListKind.NUMBERED -> {
                Text(
                    text = "$numberedIndex.",
                    fontSize = fontSize,
                    color = textColor,
                    modifier = Modifier.padding(end = 8.dp),
                )
            }
            ListKind.NONE -> Unit
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .background(highlightBg, RoundedCornerShape(3.dp))
                .padding(vertical = 2.dp),
        ) {
            if (block.text.isEmpty()) {
                Text(
                    text = if (block.style == ParagraphStyleKind.HEADING_1) "Заголовок…" else "Введите текст…",
                    fontSize = fontSize,
                    fontFamily = fontFamily,
                    color = Color(0xFF9CA3AF),
                )
            }
            BasicTextField(
                value = block.text,
                onValueChange = onTextChange,
                textStyle = TextStyle(
                    fontFamily = fontFamily,
                    fontSize = fontSize,
                    lineHeight = (block.fontSizeSp * zoomScale * lineSpacingMultiplier).sp,
                    fontWeight = if (block.bold) FontWeight.Bold else FontWeight.Normal,
                    fontStyle = if (block.italic) FontStyle.Italic else FontStyle.Normal,
                    textDecoration = decoration,
                    color = textColor,
                    textAlign = block.align.toComposeAlign(),
                ),
                cursorBrush = SolidColor(DocCobalt),
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { if (it.isFocused) onFocus() },
            )
        }
    }
}

@Composable
private fun EditableDocTable(
    block: DocBlock,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onCellChange: (Int, Int, String) -> Unit,
    onAddRow: () -> Unit,
    onAddCol: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) DocCobalt else Color(0xFFCBD5E1),
                shape = RoundedCornerShape(4.dp),
            )
            .clickable(onClick = onSelect)
            .padding(2.dp),
    ) {
        block.tableRows.forEachIndexed { rIdx, row ->
            Row(modifier = Modifier.fillMaxWidth()) {
                row.forEachIndexed { cIdx, cellValue ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (rIdx == 0) Color(0xFFEEF3F9) else Color.White)
                            .border(0.5.dp, Color(0xFFCBD5E1))
                            .padding(6.dp),
                    ) {
                        BasicTextField(
                            value = cellValue,
                            onValueChange = { onCellChange(rIdx, cIdx, it) },
                            textStyle = TextStyle(
                                fontSize = 12.sp,
                                fontWeight = if (rIdx == 0) FontWeight.Bold else FontWeight.Normal,
                                color = Color(0xFF111827),
                            ),
                            cursorBrush = SolidColor(DocCobalt),
                            modifier = Modifier
                                .fillMaxWidth()
                                .onFocusChanged { if (it.isFocused) onSelect() },
                        )
                    }
                }
            }
        }
        if (isSelected) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF8FAFC))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                TextButton(onClick = onAddRow) { Text("+ Строка") }
                TextButton(onClick = onAddCol) { Text("+ Столбец") }
            }
        }
    }
}

@Composable
private fun InsertTableSizeDialog(
    onDismiss: () -> Unit,
    onInsert: (Int, Int) -> Unit,
) {
    var rows by remember { mutableIntStateOf(3) }
    var cols by remember { mutableIntStateOf(3) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Вставить таблицу") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Строк: $rows")
                    Row {
                        TextButton(onClick = { if (rows > 1) rows-- }) { Text("−") }
                        TextButton(onClick = { if (rows < 10) rows++ }) { Text("+") }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Столбцов: $cols")
                    Row {
                        TextButton(onClick = { if (cols > 1) cols-- }) { Text("−") }
                        TextButton(onClick = { if (cols < 6) cols++ }) { Text("+") }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onInsert(rows, cols) }) { Text("Вставить") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        },
    )
}

package com.example.ui.presentation

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.engine.FileExportHelper
import com.example.model.DocumentType
import com.example.model.SlideElement
import com.example.model.SlideElementKind
import com.example.model.SlideLayoutKind
import com.example.model.SlideModel
import com.example.model.SlideThemePreset
import com.example.model.SlideTransitionKind
import com.example.model.TextAlignMode
import com.example.ui.components.ColorPaletteDialog
import com.example.ui.components.EditorTopHeader
import com.example.ui.components.FileBackstageSheet
import com.example.ui.components.OfficeRibbonBar
import com.example.ui.components.RenameDocumentDialog
import com.example.ui.components.RibbonGroupDivider
import com.example.ui.components.RibbonIconButton
import com.example.ui.components.RibbonTextChip
import com.example.ui.theme.SlideAmber

@Composable
fun PresentationEditorScreen(
    docId: String,
    onBack: () -> Unit,
    vm: PresentationViewModel = viewModel(),
) {
    LaunchedEffect(docId) { vm.load(docId) }
    val state by vm.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var ribbonTab by remember { mutableIntStateOf(0) }
    var ribbonExpanded by remember { mutableStateOf(true) }
    var showFileMenu by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showNewSlideDialog by remember { mutableStateOf(false) }
    var showElementFillDialog by remember { mutableStateOf(false) }
    var showElementTextColorDialog by remember { mutableStateOf(false) }
    var showSlideBgDialog by remember { mutableStateOf(false) }
    var editingElement by remember { mutableStateOf<SlideElement?>(null) }

    val pdfExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf"),
    ) { uri -> uri?.let { vm.exportPdfToUri(it) } }

    val pptxExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.presentationml.presentation"),
    ) { uri -> uri?.let { vm.exportPptxToUri(it) } }

    LaunchedEffect(state.statusMessage) {
        val msg = state.statusMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        vm.clearStatus()
    }

    if (state.isSlideshowActive) {
        SlideshowFullscreenView(
            slides = state.model.slides,
            currentIndex = state.activeSlideIndex,
            onChangeSlide = vm::selectSlide,
            onExit = vm::stopSlideshow,
        )
        return
    }

    val selectedEl = state.selectedElement
    val activeSlide = state.activeSlide

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column {
                EditorTopHeader(
                    title = state.title,
                    moduleAccent = SlideAmber,
                    isSaved = state.isSaved,
                    canUndo = state.canUndo,
                    canRedo = state.canRedo,
                    onBack = onBack,
                    onRenameClick = { showRenameDialog = true },
                    onUndo = vm::undo,
                    onRedo = vm::redo,
                    onFileMenuClick = { showFileMenu = true },
                    extraAction = {
                        IconButton(
                            onClick = { vm.startSlideshow(fromStart = false) },
                            modifier = Modifier.testTag("slide_play_header_btn"),
                        ) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = "Начать показ",
                                tint = SlideAmber,
                            )
                        }
                    },
                )
                OfficeRibbonBar(
                    tabs = listOf("Главная", "Вставка", "Дизайн", "Показ"),
                    selectedTabIndex = ribbonTab,
                    onSelectTab = { ribbonTab = it; ribbonExpanded = true },
                    isExpanded = ribbonExpanded,
                    onToggleExpanded = { ribbonExpanded = !ribbonExpanded },
                    onFileClick = { showFileMenu = true },
                    moduleAccent = SlideAmber,
                ) {
                    when (ribbonTab) {
                        0 -> { // Главная
                            RibbonIconButton(
                                icon = Icons.Default.Add,
                                label = "Слайд +",
                                accentColor = SlideAmber,
                                testTag = "slide_add_btn",
                                onClick = { showNewSlideDialog = true },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.ContentCopy,
                                label = "Дублировать",
                                accentColor = SlideAmber,
                                testTag = "slide_dup_btn",
                                onClick = vm::duplicateCurrentSlide,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.DeleteOutline,
                                label = "Удалить слайд",
                                accentColor = MaterialTheme.colorScheme.error,
                                testTag = "slide_del_btn",
                                onClick = vm::deleteCurrentSlide,
                            )
                            RibbonGroupDivider()
                            RibbonIconButton(
                                icon = Icons.Default.FormatBold,
                                selected = selectedEl?.bold == true,
                                accentColor = SlideAmber,
                                testTag = "slide_el_bold",
                                onClick = vm::toggleSelectedBold,
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatItalic,
                                selected = selectedEl?.italic == true,
                                accentColor = SlideAmber,
                                testTag = "slide_el_italic",
                                onClick = vm::toggleSelectedItalic,
                            )
                            RibbonTextChip(
                                text = "A−",
                                accentColor = SlideAmber,
                                testTag = "slide_el_sz_down",
                                onClick = { vm.adjustSelectedFontSize(-2f) },
                            )
                            RibbonTextChip(
                                text = "A+",
                                accentColor = SlideAmber,
                                testTag = "slide_el_sz_up",
                                onClick = { vm.adjustSelectedFontSize(2f) },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatColorText,
                                accentColor = SlideAmber,
                                testTag = "slide_el_txt_color",
                                onClick = { showElementTextColorDialog = true },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatColorFill,
                                accentColor = SlideAmber,
                                testTag = "slide_el_fill_color",
                                onClick = { showElementFillDialog = true },
                            )
                            RibbonIconButton(
                                icon = Icons.AutoMirrored.Filled.FormatAlignLeft,
                                selected = selectedEl?.align == TextAlignMode.LEFT,
                                accentColor = SlideAmber,
                                testTag = "slide_el_align_left",
                                onClick = { vm.setSelectedAlign(TextAlignMode.LEFT) },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.FormatAlignCenter,
                                selected = selectedEl?.align == TextAlignMode.CENTER,
                                accentColor = SlideAmber,
                                testTag = "slide_el_align_center",
                                onClick = { vm.setSelectedAlign(TextAlignMode.CENTER) },
                            )
                            RibbonIconButton(
                                icon = Icons.AutoMirrored.Filled.FormatAlignRight,
                                selected = selectedEl?.align == TextAlignMode.RIGHT,
                                accentColor = SlideAmber,
                                testTag = "slide_el_align_right",
                                onClick = { vm.setSelectedAlign(TextAlignMode.RIGHT) },
                            )
                        }
                        1 -> { // Вставка
                            RibbonIconButton(
                                icon = Icons.Default.TextFields,
                                label = "Текст",
                                accentColor = SlideAmber,
                                testTag = "slide_insert_text",
                                onClick = { vm.insertElement(SlideElementKind.TEXT) },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.CropSquare,
                                label = "Прямоуг.",
                                accentColor = SlideAmber,
                                testTag = "slide_insert_rect",
                                onClick = { vm.insertElement(SlideElementKind.RECTANGLE) },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.Circle,
                                label = "Круг",
                                accentColor = SlideAmber,
                                testTag = "slide_insert_circle",
                                onClick = { vm.insertElement(SlideElementKind.CIRCLE) },
                            )
                            RibbonIconButton(
                                icon = Icons.AutoMirrored.Filled.ArrowForward,
                                label = "Стрелка",
                                accentColor = SlideAmber,
                                testTag = "slide_insert_arrow",
                                onClick = { vm.insertElement(SlideElementKind.ARROW) },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.TableChart,
                                label = "Таблица",
                                accentColor = SlideAmber,
                                testTag = "slide_insert_table",
                                onClick = { vm.insertElement(SlideElementKind.TABLE) },
                            )
                            if (selectedEl != null) {
                                RibbonGroupDivider()
                                RibbonIconButton(
                                    icon = Icons.Default.DeleteOutline,
                                    label = "Удалить объект",
                                    accentColor = MaterialTheme.colorScheme.error,
                                    testTag = "slide_del_el",
                                    onClick = vm::deleteSelectedElement,
                                )
                            }
                        }
                        2 -> { // Дизайн
                            SlideThemePreset.entries.forEach { preset ->
                                RibbonTextChip(
                                    text = preset.labelRu,
                                    selected = state.model.theme == preset,
                                    accentColor = SlideAmber,
                                    testTag = "slide_theme_${preset.name}",
                                    onClick = { vm.applyTheme(preset) },
                                )
                            }
                            RibbonGroupDivider()
                            RibbonIconButton(
                                icon = Icons.Default.Palette,
                                label = "Фон слайда",
                                accentColor = SlideAmber,
                                testTag = "slide_bg_btn",
                                onClick = { showSlideBgDialog = true },
                            )
                        }
                        3 -> { // Показ
                            RibbonIconButton(
                                icon = Icons.Default.Slideshow,
                                label = "С начала",
                                accentColor = SlideAmber,
                                testTag = "slide_show_start",
                                onClick = { vm.startSlideshow(fromStart = true) },
                            )
                            RibbonIconButton(
                                icon = Icons.Default.PlayArrow,
                                label = "С текущего",
                                accentColor = SlideAmber,
                                testTag = "slide_show_current",
                                onClick = { vm.startSlideshow(fromStart = false) },
                            )
                            RibbonGroupDivider()
                            SlideTransitionKind.entries.forEach { tr ->
                                RibbonTextChip(
                                    text = tr.labelRu,
                                    selected = activeSlide.transition == tr,
                                    accentColor = SlideAmber,
                                    testTag = "slide_trans_${tr.name}",
                                    onClick = { vm.setSlideTransition(tr) },
                                )
                            }
                        }
                    }
                }
            }
        },
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .background(MaterialTheme.colorScheme.background),
        ) {
            val isWide = maxWidth >= 700.dp

            if (isWide) {
                Row(modifier = Modifier.fillMaxSize()) {
                    // Left Thumbnails Pane
                    LazyColumn(
                        modifier = Modifier
                            .width(180.dp)
                            .fillMaxHeight()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        contentPadding = PaddingValues(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        itemsIndexed(state.model.slides, key = { _, s -> s.id }) { idx, slide ->
                            SlideThumbnailItem(
                                index = idx,
                                slide = slide,
                                selected = idx == state.activeSlideIndex,
                                onClick = { vm.selectSlide(idx) },
                            )
                        }
                    }

                    // Center Editor Area
                    SlideEditorWorkspace(
                        slide = activeSlide,
                        selectedElement = selectedEl,
                        slideNumberText = "Слайд ${state.activeSlideIndex + 1} из ${state.model.slides.size}",
                        onSelectElement = vm::selectElement,
                        onMoveElement = vm::moveElement,
                        onResizeElement = vm::resizeElement,
                        onEditElement = { editingElement = it },
                        onDeleteElement = vm::deleteSelectedElement,
                        modifier = Modifier.weight(1f),
                    )
                }
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    SlideEditorWorkspace(
                        slide = activeSlide,
                        selectedElement = selectedEl,
                        slideNumberText = "Слайд ${state.activeSlideIndex + 1} из ${state.model.slides.size}",
                        onSelectElement = vm::selectElement,
                        onMoveElement = vm::moveElement,
                        onResizeElement = vm::resizeElement,
                        onEditElement = { editingElement = it },
                        onDeleteElement = vm::deleteSelectedElement,
                        modifier = Modifier.weight(1f),
                    )

                    // Bottom Thumbnail Strip
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 2.dp,
                    ) {
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            itemsIndexed(state.model.slides, key = { _, s -> s.id }) { idx, slide ->
                                SlideThumbnailItem(
                                    index = idx,
                                    slide = slide,
                                    selected = idx == state.activeSlideIndex,
                                    onClick = { vm.selectSlide(idx) },
                                    modifier = Modifier.width(120.dp),
                                )
                            }
                            item {
                                Box(
                                    modifier = Modifier
                                        .width(84.dp)
                                        .height(68.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.5.dp, SlideAmber.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                        .clickable { showNewSlideDialog = true },
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Добавить слайд", tint = SlideAmber)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    editingElement?.let { el ->
        if (el.kind == SlideElementKind.TABLE) {
            EditSlideTableDialog(
                element = el,
                onDismiss = { editingElement = null },
                onCellChange = { r, c, v -> vm.updateSelectedTableCell(r, c, v) },
            )
        } else {
            EditSlideTextDialog(
                initialText = el.text,
                onDismiss = { editingElement = null },
                onSave = { newText ->
                    vm.updateSelectedText(newText)
                    editingElement = null
                },
            )
        }
    }

    if (showNewSlideDialog) {
        AlertDialog(
            onDismissRequest = { showNewSlideDialog = false },
            title = { Text("Выберите макет слайда") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SlideLayoutKind.entries.forEach { layout ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                                .clickable {
                                    vm.addSlide(layout)
                                    showNewSlideDialog = false
                                },
                            color = MaterialTheme.colorScheme.surfaceVariant,
                        ) {
                            Text(
                                text = layout.labelRu,
                                modifier = Modifier.padding(14.dp),
                                style = MaterialTheme.typography.titleMedium,
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNewSlideDialog = false }) { Text("Отмена") }
            },
        )
    }

    if (showFileMenu) {
        FileBackstageSheet(
            title = state.title,
            type = DocumentType.PRESENTATION,
            onDismiss = { showFileMenu = false },
            onRename = { showRenameDialog = true },
            onExportPdf = {
                pdfExportLauncher.launch(FileExportHelper.safeFileName(state.title, "pdf"))
            },
            onExportOoxml = {
                pptxExportLauncher.launch(FileExportHelper.safeFileName(state.title, "pptx"))
            },
            onSharePdf = {
                vm.shareFile(asPdf = true) { intent ->
                    context.startActivity(android.content.Intent.createChooser(intent, "Поделиться PDF"))
                }
            },
            onShareOoxml = {
                vm.shareFile(asPdf = false) { intent ->
                    context.startActivity(android.content.Intent.createChooser(intent, "Поделиться PPTX"))
                }
            },
        )
    }

    if (showRenameDialog) {
        RenameDocumentDialog(
            initialTitle = state.title,
            onDismiss = { showRenameDialog = false },
            onConfirm = { newTitle ->
                vm.rename(newTitle)
                showRenameDialog = false
            },
        )
    }

    if (showElementFillDialog) {
        ColorPaletteDialog(
            title = "Цвет заливки фигуры",
            allowClear = true,
            onDismiss = { showElementFillDialog = false },
            onSelectColor = vm::setSelectedFillColor,
        )
    }

    if (showElementTextColorDialog) {
        ColorPaletteDialog(
            title = "Цвет текста на слайде",
            allowClear = true,
            onDismiss = { showElementTextColorDialog = false },
            onSelectColor = vm::setSelectedTextColor,
        )
    }

    if (showSlideBgDialog) {
        ColorPaletteDialog(
            title = "Цвет фона слайда",
            allowClear = true,
            onDismiss = { showSlideBgDialog = false },
            onSelectColor = vm::setSlideBackgroundColor,
        )
    }
}

@Composable
private fun SlideEditorWorkspace(
    slide: SlideModel,
    selectedElement: SlideElement?,
    slideNumberText: String,
    onSelectElement: (String?) -> Unit,
    onMoveElement: (String, Float, Float) -> Unit,
    onResizeElement: (String, Float, Float) -> Unit,
    onEditElement: (SlideElement) -> Unit,
    onDeleteElement: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = slideNumberText,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp),
        )

        SlideCanvasView(
            slide = slide,
            selectedElementId = selectedElement?.id,
            isInteractive = true,
            scaleFontFactor = 0.78f,
            onSelectElement = onSelectElement,
            onMoveElement = onMoveElement,
            onResizeElement = onResizeElement,
            onEditElementRequest = onEditElement,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(12.dp))

        if (selectedElement != null) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(
                    onClick = { onEditElement(selectedElement) },
                    colors = ButtonDefaults.buttonColors(containerColor = SlideAmber),
                    modifier = Modifier.testTag("edit_selected_slide_el_btn"),
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (selectedElement.kind == SlideElementKind.TABLE) "Править таблицу" else "Править текст")
                }
                TextButton(onClick = onDeleteElement) {
                    Text("Удалить", color = MaterialTheme.colorScheme.error)
                }
            }
        } else {
            Text(
                text = "Нажмите на элемент для перемещения, дважды — для редактирования",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SlideThumbnailItem(
    index: Int,
    slide: SlideModel,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) SlideAmber else MaterialTheme.colorScheme.outlineVariant,
                shape = RoundedCornerShape(8.dp),
            )
            .clickable(onClick = onClick)
            .padding(4.dp)
            .testTag("slide_thumb_$index"),
    ) {
        SlideCanvasView(
            slide = slide,
            selectedElementId = null,
            isInteractive = false,
            scaleFontFactor = 0.28f,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            text = "${index + 1}. ${slide.title}",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) SlideAmber else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            modifier = Modifier.padding(top = 3.dp, start = 2.dp),
        )
    }
}

@Composable
private fun SlideshowFullscreenView(
    slides: List<SlideModel>,
    currentIndex: Int,
    onChangeSlide: (Int) -> Unit,
    onExit: () -> Unit,
) {
    BackHandler(onBack = onExit)
    var laserMode by remember { mutableStateOf(false) }
    val laserPoints = remember { mutableStateListOf<Offset>() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 56.dp),
            contentAlignment = Alignment.Center,
        ) {
            AnimatedContent(
                targetState = currentIndex,
                transitionSpec = {
                    val tr = slides.getOrNull(targetState)?.transition ?: SlideTransitionKind.FADE
                    when (tr) {
                        SlideTransitionKind.SLIDE -> slideInHorizontally { it / 2 } + fadeIn() togetherWith
                            slideOutHorizontally { -it / 2 } + fadeOut()
                        SlideTransitionKind.FADE -> fadeIn() togetherWith fadeOut()
                        SlideTransitionKind.NONE -> fadeIn() togetherWith fadeOut()
                    }
                },
                label = "slideshow_transition",
            ) { idx ->
                val slide = slides.getOrElse(idx) { slides.first() }
                SlideCanvasView(
                    slide = slide,
                    selectedElementId = null,
                    isInteractive = false,
                    scaleFontFactor = 0.92f,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        if (laserMode) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                laserPoints.clear()
                                laserPoints.add(offset)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                laserPoints.add(change.position)
                                if (laserPoints.size > 40) laserPoints.removeAt(0)
                            },
                            onDragEnd = { laserPoints.clear() },
                        )
                    },
            ) {
                for (i in 1 until laserPoints.size) {
                    drawLine(
                        color = Color(0xCCEF4444),
                        start = laserPoints[i - 1],
                        end = laserPoints[i],
                        strokeWidth = 6f,
                        cap = StrokeCap.Round,
                    )
                }
                laserPoints.lastOrNull()?.let { pt ->
                    drawCircle(color = Color(0x55EF4444), radius = 28f, center = pt)
                    drawCircle(color = Color(0xFFEF4444), radius = 10f, center = pt)
                }
            }
        }

        // Top Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Слайд ${currentIndex + 1} / ${slides.size}",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = { laserMode = !laserMode },
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (laserMode) Color(0xFFEF4444) else Color(0x33FFFFFF)),
                ) {
                    Icon(Icons.Default.Highlight, contentDescription = "Указка", tint = Color.White)
                }
                IconButton(
                    onClick = onExit,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x33FFFFFF))
                        .testTag("slideshow_exit_btn"),
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Выйти из показа", tint = Color.White)
                }
            }
        }

        // Bottom Prev / Next Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Button(
                onClick = { if (currentIndex > 0) onChangeSlide(currentIndex - 1) },
                enabled = currentIndex > 0,
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Назад")
            }
            Button(
                onClick = {
                    if (currentIndex < slides.lastIndex) onChangeSlide(currentIndex + 1)
                    else onExit()
                },
                colors = ButtonDefaults.buttonColors(containerColor = SlideAmber),
            ) {
                Text(if (currentIndex < slides.lastIndex) "Далее" else "Завершить")
                Spacer(Modifier.width(6.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
            }
        }
    }
}

@Composable
private fun EditSlideTextDialog(
    initialText: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initialText) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Редактировать текст") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                minLines = 3,
                maxLines = 8,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(text) }) { Text("Готово") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        },
    )
}

@Composable
private fun EditSlideTableDialog(
    element: SlideElement,
    onDismiss: () -> Unit,
    onCellChange: (Int, Int, String) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Редактировать таблицу") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                element.tableRows.forEachIndexed { r, row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        row.forEachIndexed { c, value ->
                            var cellTxt by remember(r, c, value) { mutableStateOf(value) }
                            OutlinedTextField(
                                value = cellTxt,
                                onValueChange = {
                                    cellTxt = it
                                    onCellChange(r, c, it)
                                },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Готово") }
        },
    )
}

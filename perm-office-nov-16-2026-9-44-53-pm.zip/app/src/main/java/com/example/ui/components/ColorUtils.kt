package com.example.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import com.example.model.TextAlignMode

fun parseHexColor(hex: String?, fallback: Color = Color(0xFF111827)): Color {
    if (hex.isNullOrBlank()) return fallback
    return try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (_: Exception) {
        fallback
    }
}

fun TextAlignMode.toComposeAlign(): TextAlign = when (this) {
    TextAlignMode.LEFT -> TextAlign.Start
    TextAlignMode.CENTER -> TextAlign.Center
    TextAlignMode.RIGHT -> TextAlign.End
    TextAlignMode.JUSTIFY -> TextAlign.Justify
}

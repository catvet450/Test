package com.example.engine

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.model.ChartKind
import com.example.model.DocFontKind
import com.example.model.ListKind
import com.example.model.PageOrientation
import com.example.model.ParagraphStyleKind
import com.example.model.PresentationModel
import com.example.model.SlideElementKind
import com.example.model.TextAlignMode
import com.example.model.WordDocumentModel
import com.example.model.WorkbookModel
import com.example.model.cellKey
import com.example.model.colIndexToName
import java.io.OutputStream
import kotlin.math.max
import kotlin.math.min

object PdfExportEngine {

    fun exportWordDocument(
        doc: WordDocumentModel,
        title: String,
        output: OutputStream,
    ) {
        val pdf = PdfDocument()
        val isLandscape = doc.pageSettings.orientation == PageOrientation.LANDSCAPE
        val pageWidth = if (isLandscape) 842 else 595
        val pageHeight = if (isLandscape) 595 else 842
        val margin = doc.pageSettings.margins.ptMargin.toFloat()
        val contentWidth = (pageWidth - margin * 2).toInt().coerceAtLeast(100)

        var pageNumber = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        var canvas = page.canvas
        var cursorY = margin

        fun nextPage() {
            drawPageFooter(canvas, pageWidth, pageHeight, margin, title, pageNumber, doc.pageSettings.showPageNumbers)
            pdf.finishPage(page)
            pageNumber++
            page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            canvas = page.canvas
            cursorY = margin
        }

        var numberedCounter = 0

        for (block in doc.blocks) {
            if (block.listKind == ListKind.NUMBERED) numberedCounter++ else numberedCounter = 0

            if (block.isTable && block.tableRows.isNotEmpty()) {
                val cols = block.tableRows.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
                val colWidth = contentWidth.toFloat() / cols
                val borderPaint = Paint().apply {
                    color = Color.parseColor("#CBD5E1")
                    style = Paint.Style.STROKE
                    strokeWidth = 1f
                }
                val headerFillPaint = Paint().apply {
                    color = Color.parseColor("#EEF3F9")
                    style = Paint.Style.FILL
                }
                val cellPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    textSize = 10.5f
                    color = Color.parseColor("#111827")
                }

                block.tableRows.forEachIndexed { rowIndex, row ->
                    val rowHeight = 28f
                    if (cursorY + rowHeight > pageHeight - margin - 24f) nextPage()

                    cellPaint.typeface = if (rowIndex == 0) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    for (c in 0 until cols) {
                        val left = margin + c * colWidth
                        val rect = RectF(left, cursorY, left + colWidth, cursorY + rowHeight)
                        if (rowIndex == 0) canvas.drawRect(rect, headerFillPaint)
                        canvas.drawRect(rect, borderPaint)
                        val text = row.getOrElse(c) { "" }
                        canvas.save()
                        canvas.clipRect(left + 4f, cursorY + 2f, left + colWidth - 4f, cursorY + rowHeight - 2f)
                        canvas.drawText(text, left + 6f, cursorY + 18f, cellPaint)
                        canvas.restore()
                    }
                    cursorY += rowHeight
                }
                cursorY += 12f
                continue
            }

            val prefix = when (block.listKind) {
                ListKind.BULLET -> "•  "
                ListKind.NUMBERED -> "$numberedCounter.  "
                ListKind.NONE -> ""
            }
            val displayText = if (block.text.isEmpty() && prefix.isEmpty()) " " else "$prefix${block.text}"

            val baseFamily = when (block.fontKind) {
                DocFontKind.SERIF -> Typeface.SERIF
                DocFontKind.MONO -> Typeface.MONOSPACE
                DocFontKind.SANS -> Typeface.SANS_SERIF
            }
            val styleFlag = when {
                block.bold && block.italic -> Typeface.BOLD_ITALIC
                block.bold -> Typeface.BOLD
                block.italic -> Typeface.ITALIC
                else -> Typeface.NORMAL
            }
            val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = Typeface.create(baseFamily, styleFlag)
                textSize = (block.fontSizeSp * 0.85f).coerceIn(8f, 36f)
                color = safeParseColor(block.textColorHex, Color.parseColor("#111827"))
                isUnderlineText = block.underline
                isStrikeThruText = block.strikethrough
            }
            val alignment = when (block.align) {
                TextAlignMode.CENTER -> Layout.Alignment.ALIGN_CENTER
                TextAlignMode.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
                else -> Layout.Alignment.ALIGN_NORMAL
            }
            val indentPx = (block.indentLevel * 18) + if (block.style == ParagraphStyleKind.QUOTE) 14 else 0
            val availWidth = (contentWidth - indentPx).coerceAtLeast(80)
            val layout = StaticLayout.Builder.obtain(displayText, 0, displayText.length, textPaint, availWidth)
                .setAlignment(alignment)
                .setLineSpacing(0f, doc.pageSettings.lineSpacingMultiplier)
                .build()

            if (cursorY + layout.height > pageHeight - margin - 24f) {
                nextPage()
            }

            if (block.highlightColorHex != null) {
                val hlPaint = Paint().apply {
                    color = safeParseColor(block.highlightColorHex, Color.YELLOW)
                    style = Paint.Style.FILL
                }
                canvas.drawRect(
                    margin + indentPx,
                    cursorY,
                    margin + indentPx + availWidth,
                    cursorY + layout.height,
                    hlPaint,
                )
            }

            if (block.style == ParagraphStyleKind.QUOTE) {
                val barPaint = Paint().apply {
                    color = Color.parseColor("#2563EB")
                    style = Paint.Style.FILL
                }
                canvas.drawRect(margin, cursorY, margin + 3.5f, cursorY + layout.height, barPaint)
            }

            canvas.save()
            canvas.translate(margin + indentPx, cursorY)
            layout.draw(canvas)
            canvas.restore()

            cursorY += layout.height + when (block.style) {
                ParagraphStyleKind.HEADING_1 -> 12f
                ParagraphStyleKind.HEADING_2, ParagraphStyleKind.HEADING_3 -> 9f
                else -> 6f
            }
        }

        drawPageFooter(canvas, pageWidth, pageHeight, margin, title, pageNumber, doc.pageSettings.showPageNumbers)
        pdf.finishPage(page)
        pdf.writeTo(output)
        pdf.close()
    }

    fun exportWorkbook(
        workbook: WorkbookModel,
        title: String,
        output: OutputStream,
    ) {
        val pdf = PdfDocument()
        val pageWidth = 842
        val pageHeight = 595
        val margin = 32f
        var pageNum = 1

        for (sheet in workbook.sheets) {
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum++).create())
            val canvas = page.canvas

            val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                color = Color.parseColor("#1E3A5F")
            }
            canvas.drawText("$title — ${sheet.name}", margin, margin + 12f, titlePaint)

            val maxRow = (sheet.cells.keys.mapNotNull { it.substringBefore(",").toIntOrNull() }.maxOrNull() ?: 8)
                .coerceIn(5, 24)
            val maxCol = (sheet.cells.keys.mapNotNull { it.substringAfter(",").toIntOrNull() }.maxOrNull() ?: 5)
                .coerceIn(3, 9)

            val rowHeaderW = 32f
            val colW = ((pageWidth - margin * 2 - rowHeaderW) / (maxCol + 1)).coerceAtMost(110f)
            val rowH = 22f
            var y = margin + 28f

            val gridStroke = Paint().apply {
                color = Color.parseColor("#CBD5E1")
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
            }
            val headerBg = Paint().apply {
                color = Color.parseColor("#F1F5F9")
                style = Paint.Style.FILL
            }
            val headerTxt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 9.5f
                typeface = Typeface.DEFAULT_BOLD
                color = Color.parseColor("#334155")
                textAlign = Paint.Align.CENTER
            }

            // Column headers
            canvas.drawRect(margin, y, margin + rowHeaderW, y + rowH, headerBg)
            canvas.drawRect(margin, y, margin + rowHeaderW, y + rowH, gridStroke)
            for (c in 0..maxCol) {
                val x = margin + rowHeaderW + c * colW
                canvas.drawRect(x, y, x + colW, y + rowH, headerBg)
                canvas.drawRect(x, y, x + colW, y + rowH, gridStroke)
                canvas.drawText(colIndexToName(c), x + colW / 2f, y + 14.5f, headerTxt)
            }
            y += rowH

            for (r in 0..maxRow) {
                if (y + rowH > pageHeight - margin - 20f) break
                canvas.drawRect(margin, y, margin + rowHeaderW, y + rowH, headerBg)
                canvas.drawRect(margin, y, margin + rowHeaderW, y + rowH, gridStroke)
                canvas.drawText("${r + 1}", margin + rowHeaderW / 2f, y + 14.5f, headerTxt)

                for (c in 0..maxCol) {
                    val x = margin + rowHeaderW + c * colW
                    val cell = sheet.cells[cellKey(r, c)]
                    if (cell?.bgColorHex != null) {
                        val bgPaint = Paint().apply {
                            color = safeParseColor(cell.bgColorHex, Color.WHITE)
                            style = Paint.Style.FILL
                        }
                        canvas.drawRect(x, y, x + colW, y + rowH, bgPaint)
                    }
                    canvas.drawRect(x, y, x + colW, y + rowH, gridStroke)
                    val value = cell?.evaluatedValue.orEmpty()
                    if (value.isNotEmpty()) {
                        val cellPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                            textSize = 9.5f
                            typeface = when {
                                cell?.bold == true && cell.italic -> Typeface.DEFAULT_BOLD
                                cell?.bold == true -> Typeface.DEFAULT_BOLD
                                cell?.italic == true -> Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
                                else -> Typeface.DEFAULT
                            }
                            color = safeParseColor(cell?.textColorHex, Color.parseColor("#111827"))
                        }
                        canvas.save()
                        canvas.clipRect(x + 3f, y + 2f, x + colW - 3f, y + rowH - 2f)
                        val textX = when (cell?.align) {
                            TextAlignMode.RIGHT -> {
                                cellPaint.textAlign = Paint.Align.RIGHT
                                x + colW - 5f
                            }
                            TextAlignMode.CENTER -> {
                                cellPaint.textAlign = Paint.Align.CENTER
                                x + colW / 2f
                            }
                            else -> {
                                cellPaint.textAlign = Paint.Align.LEFT
                                x + 5f
                            }
                        }
                        canvas.drawText(value, textX, y + 14.5f, cellPaint)
                        canvas.restore()
                    }
                }
                y += rowH
            }

            // Render first chart below grid if space permits
            val chart = sheet.charts.firstOrNull()
            if (chart != null && y + 130f < pageHeight - margin) {
                val values = FormulaEngine.extractNumericSeries(sheet, chart.valueRange)
                val labels = FormulaEngine.extractLabelSeries(sheet, chart.labelRange)
                if (values.isNotEmpty()) {
                    drawPdfChart(canvas, chart.title, chart.kind, labels, values, margin, y + 16f, 360f, 120f)
                }
            }

            pdf.finishPage(page)
        }

        pdf.writeTo(output)
        pdf.close()
    }

    fun exportPresentation(
        presentation: PresentationModel,
        output: OutputStream,
    ) {
        val pdf = PdfDocument()
        val pageWidth = 960
        val pageHeight = 540

        presentation.slides.forEachIndexed { index, slide ->
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create())
            val canvas = page.canvas

            val bgPaint = Paint().apply {
                color = safeParseColor(slide.bgColorHex, Color.WHITE)
                style = Paint.Style.FILL
            }
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

            for (el in slide.elements) {
                val left = el.xFraction * pageWidth
                val top = el.yFraction * pageHeight
                val w = el.widthFraction * pageWidth
                val h = el.heightFraction * pageHeight

                val fillPaint = el.fillColorHex?.let { hex ->
                    Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = safeParseColor(hex, Color.LTGRAY)
                        style = Paint.Style.FILL
                    }
                }

                when (el.kind) {
                    SlideElementKind.RECTANGLE -> {
                        if (fillPaint != null) {
                            canvas.drawRoundRect(RectF(left, top, left + w, top + h), 12f, 12f, fillPaint)
                        }
                    }
                    SlideElementKind.CIRCLE -> {
                        if (fillPaint != null) {
                            canvas.drawOval(RectF(left, top, left + w, top + h), fillPaint)
                        }
                    }
                    SlideElementKind.ARROW -> {
                        val paint = fillPaint ?: Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = Color.parseColor("#2563EB")
                            style = Paint.Style.FILL
                        }
                        val path = Path().apply {
                            moveTo(left, top + h * 0.3f)
                            lineTo(left + w * 0.68f, top + h * 0.3f)
                            lineTo(left + w * 0.68f, top)
                            lineTo(left + w, top + h * 0.5f)
                            lineTo(left + w * 0.68f, top + h)
                            lineTo(left + w * 0.68f, top + h * 0.7f)
                            lineTo(left, top + h * 0.7f)
                            close()
                        }
                        canvas.drawPath(path, paint)
                    }
                    SlideElementKind.TABLE -> {
                        val rows = el.tableRows
                        if (rows.isNotEmpty()) {
                            val cols = rows.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
                            val cw = w / cols
                            val rh = h / rows.size
                            val stroke = Paint().apply {
                                color = Color.parseColor("#CBD5E1")
                                style = Paint.Style.STROKE
                                strokeWidth = 1.5f
                            }
                            val headerBg = Paint().apply {
                                color = Color.parseColor("#1E3A5F")
                                style = Paint.Style.FILL
                            }
                            val bodyBg = Paint().apply {
                                color = safeParseColor(el.fillColorHex, Color.WHITE)
                                style = Paint.Style.FILL
                            }
                            rows.forEachIndexed { r, row ->
                                for (c in 0 until cols) {
                                    val rRect = RectF(left + c * cw, top + r * rh, left + (c + 1) * cw, top + (r + 1) * rh)
                                    canvas.drawRect(rRect, if (r == 0) headerBg else bodyBg)
                                    canvas.drawRect(rRect, stroke)
                                    val cellTxt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                                        textSize = 14f
                                        typeface = if (r == 0) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                                        color = if (r == 0) Color.WHITE else safeParseColor(el.textColorHex, Color.BLACK)
                                    }
                                    canvas.drawText(row.getOrElse(c) { "" }, rRect.left + 8f, rRect.centerY() + 5f, cellTxt)
                                }
                            }
                        }
                    }
                    SlideElementKind.TEXT -> Unit
                }

                if (el.kind != SlideElementKind.TABLE && el.text.isNotBlank()) {
                    val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                        textSize = (el.fontSizeSp * 1.45f).coerceIn(12f, 52f)
                        color = safeParseColor(el.textColorHex, Color.BLACK)
                        typeface = when {
                            el.bold && el.italic -> Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
                            el.bold -> Typeface.DEFAULT_BOLD
                            el.italic -> Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
                            else -> Typeface.DEFAULT
                        }
                    }
                    val align = when (el.align) {
                        TextAlignMode.CENTER -> Layout.Alignment.ALIGN_CENTER
                        TextAlignMode.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
                        else -> Layout.Alignment.ALIGN_NORMAL
                    }
                    val layout = StaticLayout.Builder.obtain(el.text, 0, el.text.length, tp, w.toInt().coerceAtLeast(40))
                        .setAlignment(align)
                        .build()
                    canvas.save()
                    val yOffset = if (el.kind == SlideElementKind.CIRCLE || el.kind == SlideElementKind.RECTANGLE) {
                        top + max(8f, (h - layout.height) / 2f)
                    } else top + 6f
                    canvas.translate(left + 8f, yOffset)
                    layout.draw(canvas)
                    canvas.restore()
                }
            }

            pdf.finishPage(page)
        }

        pdf.writeTo(output)
        pdf.close()
    }

    private fun drawPdfChart(
        canvas: Canvas,
        title: String,
        kind: ChartKind,
        labels: List<String>,
        values: List<Double>,
        left: Float,
        top: Float,
        width: Float,
        height: Float,
    ) {
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            color = Color.parseColor("#1E3A5F")
        }
        canvas.drawText(title, left, top, titlePaint)
        val maxVal = (values.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
        val chartTop = top + 12f
        val chartH = height - 24f
        val colors = listOf("#2563EB", "#059669", "#D97706", "#7C3AED", "#DB2777", "#0891B2")

        if (kind == ChartKind.PIE) {
            val total = values.sumOf { max(0.0, it) }.coerceAtLeast(1.0)
            val diameter = min(chartH, width * 0.45f)
            val oval = RectF(left + 12f, chartTop, left + 12f + diameter, chartTop + diameter)
            var startAngle = -90f
            values.forEachIndexed { idx, v ->
                val sweep = (max(0.0, v) / total * 360.0).toFloat()
                val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor(colors[idx % colors.size])
                    style = Paint.Style.FILL
                }
                canvas.drawArc(oval, startAngle, sweep, true, p)
                startAngle += sweep
            }
        } else {
            val step = width / values.size.coerceAtLeast(1)
            val barW = step * 0.55f
            val labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 8.5f
                color = Color.parseColor("#4B5563")
                textAlign = Paint.Align.CENTER
            }
            var prevX = 0f
            var prevY = 0f
            val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#2563EB")
                strokeWidth = 2.5f
                style = Paint.Style.STROKE
            }
            values.forEachIndexed { idx, v ->
                val ratio = (max(0.0, v) / maxVal).toFloat()
                val barH = ratio * chartH
                val cx = left + idx * step + step / 2f
                val cy = chartTop + chartH - barH
                if (kind == ChartKind.COLUMN) {
                    val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.parseColor(colors[idx % colors.size])
                    }
                    canvas.drawRect(cx - barW / 2f, cy, cx + barW / 2f, chartTop + chartH, barPaint)
                } else {
                    if (idx > 0) canvas.drawLine(prevX, prevY, cx, cy, linePaint)
                    val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1E3A5F") }
                    canvas.drawCircle(cx, cy, 4f, dotPaint)
                    prevX = cx
                    prevY = cy
                }
                canvas.drawText(labels.getOrElse(idx) { "" }.take(8), cx, chartTop + chartH + 11f, labelPaint)
            }
        }
    }

    private fun drawPageFooter(
        canvas: Canvas,
        pageWidth: Int,
        pageHeight: Int,
        margin: Float,
        title: String,
        pageNumber: Int,
        showNumber: Boolean,
    ) {
        if (!showNumber) return
        val footerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 9f
            color = Color.parseColor("#94A3B8")
        }
        canvas.drawText(title, margin, pageHeight - margin / 2f, footerPaint)
        footerPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText("Стр. $pageNumber • Perm Office", pageWidth - margin, pageHeight - margin / 2f, footerPaint)
    }

    private fun safeParseColor(hex: String?, fallback: Int): Int {
        if (hex.isNullOrBlank()) return fallback
        return try {
            Color.parseColor(hex)
        } catch (_: Exception) {
            fallback
        }
    }
}

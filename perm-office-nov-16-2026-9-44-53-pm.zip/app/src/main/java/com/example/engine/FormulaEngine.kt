package com.example.engine

import com.example.model.CellData
import com.example.model.CellNumberFormat
import com.example.model.SheetModel
import com.example.model.WorkbookModel
import com.example.model.cellKey
import com.example.model.parseCellKey
import com.example.model.parseCellRef
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sqrt

object FormulaEngine {

    private sealed class EvalResult {
        data class Num(val value: Double) : EvalResult()
        data class Str(val value: String) : EvalResult()
        data class Err(val code: String) : EvalResult()
    }

    fun recalculateWorkbook(workbook: WorkbookModel): WorkbookModel {
        return workbook.copy(
            sheets = workbook.sheets.map { recalculateSheet(it) }
        )
    }

    fun recalculateSheet(sheet: SheetModel): SheetModel {
        val cache = mutableMapOf<String, EvalResult>()
        val visiting = mutableSetOf<String>()

        fun evaluateCell(row: Int, col: Int): EvalResult {
            val key = cellKey(row, col)
            cache[key]?.let { return it }
            if (key in visiting) return EvalResult.Err("#CYCLE!")
            val cell = sheet.cells[key] ?: return EvalResult.Str("")
            val raw = cell.rawInput.trim()
            if (raw.isEmpty()) return EvalResult.Str("")

            visiting.add(key)
            val result = if (raw.startsWith("=")) {
                evaluateFormula(raw.substring(1).trim(), ::evaluateCell)
            } else {
                val numeric = raw.replace(" ", "").replace(",", ".").toDoubleOrNull()
                if (numeric != null) EvalResult.Num(numeric) else EvalResult.Str(raw)
            }
            visiting.remove(key)
            cache[key] = result
            return result
        }

        val updatedCells = sheet.cells.mapValues { (key, cell) ->
            val rc = parseCellKey(key) ?: return@mapValues cell
            val res = evaluateCell(rc.first, rc.second)
            val display = when (res) {
                is EvalResult.Err -> res.code
                is EvalResult.Str -> res.value
                is EvalResult.Num -> formatNumber(res.value, cell.numberFormat)
            }
            cell.copy(evaluatedValue = display)
        }

        return sheet.copy(cells = updatedCells)
    }

    fun formatNumber(value: Double, format: CellNumberFormat): String {
        if (value.isNaN() || value.isInfinite()) return "#NUM!"
        val symbols = DecimalFormatSymbols(Locale("ru", "RU")).apply {
            groupingSeparator = ' '
            decimalSeparator = ','
        }
        return when (format) {
            CellNumberFormat.GENERAL -> {
                if (abs(value - round(value)) < 1e-9 && abs(value) < 1e12) {
                    DecimalFormat("#,##0", symbols).format(round(value).toLong())
                } else {
                    DecimalFormat("#,##0.##", symbols).format(value)
                }
            }
            CellNumberFormat.CURRENCY_RUB -> DecimalFormat("#,##0.00 ₽", symbols).format(value)
            CellNumberFormat.CURRENCY_USD -> DecimalFormat("$#,##0.00", symbols).format(value)
            CellNumberFormat.PERCENT -> DecimalFormat("0.0%", symbols).format(value)
            CellNumberFormat.INTEGER -> DecimalFormat("#,##0", symbols).format(round(value).toLong())
            CellNumberFormat.DECIMAL_2 -> DecimalFormat("#,##0.00", symbols).format(value)
        }
    }

    fun extractNumericSeries(sheet: SheetModel, range: String): List<Double> {
        return expandRange(range).map { (r, c) ->
            val cell = sheet.cells[cellKey(r, c)] ?: return@map 0.0
            val raw = cell.rawInput.trim()
            if (raw.startsWith("=")) {
                val cleaned = cell.evaluatedValue
                    .replace("₽", "")
                    .replace("$", "")
                    .replace("%", "")
                    .replace(" ", "")
                    .replace(",", ".")
                cleaned.toDoubleOrNull() ?: 0.0
            } else {
                raw.replace(" ", "").replace(",", ".").toDoubleOrNull() ?: 0.0
            }
        }
    }

    fun extractLabelSeries(sheet: SheetModel, range: String): List<String> {
        return expandRange(range).mapIndexed { index, (r, c) ->
            val text = sheet.cells[cellKey(r, c)]?.evaluatedValue?.trim().orEmpty()
            text.ifEmpty { "Эл. ${index + 1}" }
        }
    }

    fun expandRange(range: String): List<Pair<Int, Int>> {
        val parts = range.split(":")
        if (parts.size == 1) {
            val single = parseCellRef(parts[0]) ?: return emptyList()
            return listOf(single)
        }
        if (parts.size != 2) return emptyList()
        val start = parseCellRef(parts[0]) ?: return emptyList()
        val end = parseCellRef(parts[1]) ?: return emptyList()
        val r1 = minOf(start.first, end.first)
        val r2 = maxOf(start.first, end.first)
        val c1 = minOf(start.second, end.second)
        val c2 = maxOf(start.second, end.second)
        val list = mutableListOf<Pair<Int, Int>>()
        for (r in r1..r2) {
            for (c in c1..c2) {
                list.add(r to c)
            }
        }
        return list
    }

    private fun evaluateFormula(
        expr: String,
        lookup: (Int, Int) -> EvalResult,
    ): EvalResult {
        return try {
            Parser(expr, lookup).parseExpression()
        } catch (_: Exception) {
            EvalResult.Err("#ERR!")
        }
    }

    private class Parser(
        private val input: String,
        private val lookup: (Int, Int) -> EvalResult,
    ) {
        private var pos = 0

        private fun skipWhitespace() {
            while (pos < input.length && input[pos].isWhitespace()) pos++
        }

        private fun peek(): Char? {
            skipWhitespace()
            return if (pos < input.length) input[pos] else null
        }

        fun parseExpression(): EvalResult {
            val left = parseAdditive()
            skipWhitespace()
            if (left is EvalResult.Err) return left
            // Check comparison operators for IF conditions
            val ops = listOf(">=", "<=", "<>", "!=", "=", ">", "<")
            for (op in ops) {
                if (input.startsWith(op, pos)) {
                    pos += op.length
                    val right = parseAdditive()
                    if (right is EvalResult.Err) return right
                    val boolRes = compareResults(left, right, op)
                    return EvalResult.Num(if (boolRes) 1.0 else 0.0)
                }
            }
            return left
        }

        private fun compareResults(a: EvalResult, b: EvalResult, op: String): Boolean {
            val numA = (a as? EvalResult.Num)?.value ?: (a as? EvalResult.Str)?.value?.toDoubleOrNull()
            val numB = (b as? EvalResult.Num)?.value ?: (b as? EvalResult.Str)?.value?.toDoubleOrNull()
            if (numA != null && numB != null) {
                return when (op) {
                    ">=" -> numA >= numB
                    "<=" -> numA <= numB
                    "<>", "!=" -> abs(numA - numB) > 1e-9
                    "=" -> abs(numA - numB) <= 1e-9
                    ">" -> numA > numB
                    "<" -> numA < numB
                    else -> false
                }
            }
            val strA = resultToString(a)
            val strB = resultToString(b)
            return when (op) {
                "=" -> strA == strB
                "<>", "!=" -> strA != strB
                ">" -> strA > strB
                "<" -> strA < strB
                ">=" -> strA >= strB
                "<=" -> strA <= strB
                else -> false
            }
        }

        private fun parseAdditive(): EvalResult {
            var left = parseMultiplicative()
            if (left is EvalResult.Err) return left
            while (true) {
                val ch = peek()
                if (ch == '+' || ch == '-') {
                    pos++
                    val right = parseMultiplicative()
                    if (right is EvalResult.Err) return right
                    val a = asNumber(left) ?: return EvalResult.Err("#VALUE!")
                    val b = asNumber(right) ?: return EvalResult.Err("#VALUE!")
                    left = EvalResult.Num(if (ch == '+') a + b else a - b)
                } else {
                    break
                }
            }
            return left
        }

        private fun parseMultiplicative(): EvalResult {
            var left = parsePower()
            if (left is EvalResult.Err) return left
            while (true) {
                val ch = peek()
                if (ch == '*' || ch == '/') {
                    pos++
                    val right = parsePower()
                    if (right is EvalResult.Err) return right
                    val a = asNumber(left) ?: return EvalResult.Err("#VALUE!")
                    val b = asNumber(right) ?: return EvalResult.Err("#VALUE!")
                    if (ch == '/' && abs(b) < 1e-12) return EvalResult.Err("#DIV/0!")
                    left = EvalResult.Num(if (ch == '*') a * b else a / b)
                } else {
                    break
                }
            }
            return left
        }

        private fun parsePower(): EvalResult {
            val base = parseUnary()
            if (base is EvalResult.Err) return base
            if (peek() == '^') {
                pos++
                val exp = parsePower()
                if (exp is EvalResult.Err) return exp
                val a = asNumber(base) ?: return EvalResult.Err("#VALUE!")
                val b = asNumber(exp) ?: return EvalResult.Err("#VALUE!")
                return EvalResult.Num(a.pow(b))
            }
            return base
        }

        private fun parseUnary(): EvalResult {
            val ch = peek()
            if (ch == '-') {
                pos++
                val v = parseUnary()
                if (v is EvalResult.Err) return v
                val n = asNumber(v) ?: return EvalResult.Err("#VALUE!")
                return EvalResult.Num(-n)
            }
            if (ch == '+') {
                pos++
                return parseUnary()
            }
            return parsePrimary()
        }

        private fun parsePrimary(): EvalResult {
            val ch = peek() ?: return EvalResult.Err("#ERR!")
            if (ch == '(') {
                pos++
                val inner = parseExpression()
                if (peek() == ')') pos++
                return inner
            }
            if (ch == '"') {
                pos++
                val sb = StringBuilder()
                while (pos < input.length && input[pos] != '"') {
                    sb.append(input[pos])
                    pos++
                }
                if (pos < input.length && input[pos] == '"') pos++
                return EvalResult.Str(sb.toString())
            }
            if (ch.isDigit() || ch == '.') {
                val start = pos
                while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) pos++
                val num = input.substring(start, pos).toDoubleOrNull() ?: return EvalResult.Err("#ERR!")
                return EvalResult.Num(num)
            }
            if (ch.isLetter() || ch == '$') {
                val start = pos
                while (pos < input.length && (input[pos].isLetterOrDigit() || input[pos] == '$' || input[pos] == '_')) {
                    pos++
                }
                val ident = input.substring(start, pos)
                if (peek() == '(') {
                    pos++ // consume '('
                    return parseFunctionCall(ident.uppercase())
                }
                val ref = parseCellRef(ident) ?: return when (ident.uppercase()) {
                    "TRUE" -> EvalResult.Num(1.0)
                    "FALSE" -> EvalResult.Num(0.0)
                    else -> EvalResult.Err("#NAME?")
                }
                return lookup(ref.first, ref.second)
            }
            return EvalResult.Err("#ERR!")
        }

        private fun parseFunctionCall(name: String): EvalResult {
            val argStrings = mutableListOf<String>()
            var depth = 0
            var inQuotes = false
            val current = StringBuilder()
            while (pos < input.length) {
                val c = input[pos]
                if (c == '"') inQuotes = !inQuotes
                if (!inQuotes) {
                    if (c == '(') depth++
                    else if (c == ')') {
                        if (depth == 0) {
                            pos++
                            if (current.isNotBlank() || argStrings.isNotEmpty()) {
                                argStrings.add(current.toString().trim())
                            }
                            break
                        }
                        depth--
                    } else if ((c == ',' || c == ';') && depth == 0) {
                        argStrings.add(current.toString().trim())
                        current.clear()
                        pos++
                        continue
                    }
                }
                current.append(c)
                pos++
            }

            if (name == "IF") {
                if (argStrings.size < 2) return EvalResult.Err("#ARGS!")
                val cond = Parser(argStrings[0], lookup).parseExpression()
                if (cond is EvalResult.Err) return cond
                val isTrue = (asNumber(cond) ?: 0.0) != 0.0
                return if (isTrue) {
                    Parser(argStrings[1], lookup).parseExpression()
                } else {
                    if (argStrings.size >= 3) Parser(argStrings[2], lookup).parseExpression()
                    else EvalResult.Num(0.0)
                }
            }

            if (name == "CONCAT" || name == "CONCATENATE") {
                val sb = StringBuilder()
                for (arg in argStrings) {
                    val res = Parser(arg, lookup).parseExpression()
                    if (res is EvalResult.Err) return res
                    sb.append(resultToString(res))
                }
                return EvalResult.Str(sb.toString())
            }

            if (name == "ABS" || name == "SQRT") {
                if (argStrings.isEmpty()) return EvalResult.Err("#ARGS!")
                val res = Parser(argStrings[0], lookup).parseExpression()
                if (res is EvalResult.Err) return res
                val n = asNumber(res) ?: return EvalResult.Err("#VALUE!")
                return if (name == "ABS") EvalResult.Num(abs(n))
                else if (n < 0) EvalResult.Err("#NUM!") else EvalResult.Num(sqrt(n))
            }

            if (name == "ROUND" || name == "POWER") {
                if (argStrings.size < 2) return EvalResult.Err("#ARGS!")
                val aRes = Parser(argStrings[0], lookup).parseExpression()
                val bRes = Parser(argStrings[1], lookup).parseExpression()
                if (aRes is EvalResult.Err) return aRes
                if (bRes is EvalResult.Err) return bRes
                val a = asNumber(aRes) ?: return EvalResult.Err("#VALUE!")
                val b = asNumber(bRes) ?: return EvalResult.Err("#VALUE!")
                return if (name == "POWER") {
                    EvalResult.Num(a.pow(b))
                } else {
                    val factor = 10.0.pow(b.toInt())
                    EvalResult.Num(round(a * factor) / factor)
                }
            }

            // Aggregate functions: SUM, AVERAGE, AVG, MIN, MAX, COUNT
            val nums = mutableListOf<Double>()
            for (arg in argStrings) {
                if (arg.contains(":")) {
                    val coords = expandRange(arg)
                    for ((r, c) in coords) {
                        val v = lookup(r, c)
                        if (v is EvalResult.Err) return v
                        if (v is EvalResult.Num) nums.add(v.value)
                    }
                } else if (arg.isNotBlank()) {
                    val v = Parser(arg, lookup).parseExpression()
                    if (v is EvalResult.Err) return v
                    asNumber(v)?.let { nums.add(it) }
                }
            }

            return when (name) {
                "SUM", "СУММ" -> EvalResult.Num(nums.sum())
                "AVERAGE", "AVG", "СРЗНАЧ" -> if (nums.isEmpty()) EvalResult.Err("#DIV/0!") else EvalResult.Num(nums.average())
                "MIN", "МИН" -> EvalResult.Num(nums.minOrNull() ?: 0.0)
                "MAX", "МАКС" -> EvalResult.Num(nums.maxOrNull() ?: 0.0)
                "COUNT", "СЧЁТ" -> EvalResult.Num(nums.size.toDouble())
                else -> EvalResult.Err("#NAME?")
            }
        }

        private fun asNumber(res: EvalResult): Double? = when (res) {
            is EvalResult.Num -> res.value
            is EvalResult.Str -> {
                if (res.value.isEmpty()) 0.0
                else res.value.replace(" ", "").replace(",", ".").toDoubleOrNull()
            }
            is EvalResult.Err -> null
        }

        private fun resultToString(res: EvalResult): String = when (res) {
            is EvalResult.Num -> {
                if (abs(res.value - round(res.value)) < 1e-9) round(res.value).toLong().toString()
                else res.value.toString()
            }
            is EvalResult.Str -> res.value
            is EvalResult.Err -> res.code
        }
    }
}

package com.example.engine

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import com.example.data.OfficeRepository
import com.example.model.DocumentType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.OutputStream
import java.util.zip.ZipInputStream

object FileExportHelper {

    fun safeFileName(title: String, ext: String): String {
        val clean = title.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").ifEmpty { "PermOffice_File" }
        return "$clean.$ext"
    }

    suspend fun writeToUri(
        context: Context,
        uri: Uri,
        writer: (OutputStream) -> Unit,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.openOutputStream(uri)?.use(writer)
                ?: error("Не удалось открыть поток для записи")
        }
    }

    suspend fun createShareIntent(
        context: Context,
        fileName: String,
        mimeType: String,
        writer: (OutputStream) -> Unit,
    ): Result<Intent> = withContext(Dispatchers.IO) {
        runCatching {
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val outFile = File(exportDir, fileName)
            outFile.outputStream().use(writer)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                outFile,
            )
            Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
    }

    suspend fun importFromUri(
        context: Context,
        uri: Uri,
        repository: OfficeRepository,
    ): Result<Pair<String, DocumentType>> = withContext(Dispatchers.IO) {
        runCatching {
            val fileName = queryDisplayName(context, uri) ?: "Импортированный файл"
            val title = fileName.substringBeforeLast(".")
            val ext = fileName.substringAfterLast(".", "").lowercase()

            val detectedType = when (ext) {
                "docx" -> DocumentType.DOCUMENT
                "xlsx" -> DocumentType.SPREADSHEET
                "pptx" -> DocumentType.PRESENTATION
                else -> detectOoxmlType(context, uri)
            } ?: error("Поддерживаются файлы формата DOCX, XLSX и PPTX")

            context.contentResolver.openInputStream(uri)?.use { stream ->
                when (detectedType) {
                    DocumentType.DOCUMENT -> {
                        val doc = OoxmlDocumentCodec.importDocx(stream)
                        val id = repository.saveImportedDocument(title, doc)
                        id to DocumentType.DOCUMENT
                    }
                    DocumentType.SPREADSHEET -> {
                        val wb = OoxmlSpreadsheetCodec.importXlsx(stream)
                        val id = repository.saveImportedWorkbook(title, wb)
                        id to DocumentType.SPREADSHEET
                    }
                    DocumentType.PRESENTATION -> {
                        val pres = OoxmlPresentationCodec.importPptx(stream)
                        val id = repository.saveImportedPresentation(title, pres)
                        id to DocumentType.PRESENTATION
                    }
                }
            } ?: error("Не удалось прочитать выбранный файл")
        }
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) return c.getString(idx)
            }
        }
        return uri.lastPathSegment
    }

    private fun detectOoxmlType(context: Context, uri: Uri): DocumentType? {
        return context.contentResolver.openInputStream(uri)?.use { stream ->
            ZipInputStream(stream).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    when {
                        entry.name.startsWith("word/") -> return@use DocumentType.DOCUMENT
                        entry.name.startsWith("xl/") -> return@use DocumentType.SPREADSHEET
                        entry.name.startsWith("ppt/") -> return@use DocumentType.PRESENTATION
                    }
                    entry = zip.nextEntry
                }
                null
            }
        }
    }
}

package com.example.engine

import android.util.Xml
import com.example.model.DocBlock
import com.example.model.ListKind
import com.example.model.ParagraphStyleKind
import com.example.model.TextAlignMode
import com.example.model.WordDocumentModel
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object OoxmlDocumentCodec {

    fun exportDocx(doc: WordDocumentModel, output: OutputStream) {
        ZipOutputStream(output).use { zip ->
            writeZipEntry(zip, "[Content_Types].xml", CONTENT_TYPES_XML)
            writeZipEntry(zip, "_rels/.rels", ROOT_RELS_XML)
            writeZipEntry(zip, "word/styles.xml", STYLES_XML)
            writeZipEntry(zip, "word/document.xml", buildDocumentXml(doc))
        }
    }

    fun importDocx(input: InputStream): WordDocumentModel {
        var documentXml: ByteArray? = null
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (entry.name == "word/document.xml") {
                    documentXml = zip.readBytes()
                    break
                }
                entry = zip.nextEntry
            }
        }
        val bytes = documentXml ?: return WordDocumentModel()
        val blocks = parseDocumentXml(bytes)
        return WordDocumentModel(blocks = blocks.ifEmpty { listOf(DocBlock()) })
    }

    private fun buildDocumentXml(doc: WordDocumentModel): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">""")
        sb.append("<w:body>")

        for (block in doc.blocks) {
            if (block.isTable && block.tableRows.isNotEmpty()) {
                sb.append("<w:tbl><w:tblPr><w:tblBorders>")
                listOf("top", "left", "bottom", "right", "insideH", "insideV").forEach { side ->
                    sb.append("""<w:$side w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>""")
                }
                sb.append("</w:tblBorders></w:tblPr>")
                for (row in block.tableRows) {
                    sb.append("<w:tr>")
                    for (cell in row) {
                        sb.append("<w:tc><w:p><w:r><w:t xml:space=\"preserve\">${escapeXml(cell)}</w:t></w:r></w:p></w:tc>")
                    }
                    sb.append("</w:tr>")
                }
                sb.append("</w:tbl>")
            } else {
                sb.append("<w:p>")
                sb.append("<w:pPr>")
                when (block.style) {
                    ParagraphStyleKind.HEADING_1 -> sb.append("""<w:pStyle w:val="Heading1"/>""")
                    ParagraphStyleKind.HEADING_2 -> sb.append("""<w:pStyle w:val="Heading2"/>""")
                    ParagraphStyleKind.HEADING_3 -> sb.append("""<w:pStyle w:val="Heading3"/>""")
                    ParagraphStyleKind.QUOTE -> sb.append("""<w:pStyle w:val="Quote"/>""")
                    ParagraphStyleKind.NORMAL -> Unit
                }
                val jc = when (block.align) {
                    TextAlignMode.CENTER -> "center"
                    TextAlignMode.RIGHT -> "right"
                    TextAlignMode.JUSTIFY -> "both"
                    TextAlignMode.LEFT -> "left"
                }
                sb.append("""<w:jc w:val="$jc"/>""")
                if (block.indentLevel > 0) {
                    sb.append("""<w:ind w:left="${block.indentLevel * 360}"/>""")
                }
                sb.append("</w:pPr>")

                val prefix = when (block.listKind) {
                    ListKind.BULLET -> "• "
                    ListKind.NUMBERED -> "- "
                    ListKind.NONE -> ""
                }
                val text = prefix + block.text
                sb.append("<w:r>")
                sb.append("<w:rPr>")
                if (block.bold) sb.append("<w:b/>")
                if (block.italic) sb.append("<w:i/>")
                if (block.underline) sb.append("""<w:u w:val="single"/>""")
                if (block.strikethrough) sb.append("<w:strike/>")
                val halfPts = (block.fontSizeSp * 2).toInt().coerceIn(16, 72)
                sb.append("""<w:sz w:val="$halfPts"/>""")
                val cleanHex = block.textColorHex.removePrefix("#").take(6)
                if (cleanHex.length == 6) {
                    sb.append("""<w:color w:val="$cleanHex"/>""")
                }
                sb.append("</w:rPr>")
                sb.append("""<w:t xml:space="preserve">${escapeXml(text)}</w:t>""")
                sb.append("</w:r>")
                sb.append("</w:p>")
            }
        }

        sb.append("<w:sectPr/></w:body></w:document>")
        return sb.toString()
    }

    private fun parseDocumentXml(bytes: ByteArray): List<DocBlock> {
        val result = mutableListOf<DocBlock>()
        val parser = Xml.newPullParser()
        parser.setInput(bytes.inputStream(), "UTF-8")

        var inTable = false
        var currentRows = mutableListOf<MutableList<String>>()
        var currentRow = mutableListOf<String>()
        var inParagraph = false
        var pText = StringBuilder()
        var pStyle = ParagraphStyleKind.NORMAL
        var pAlign = TextAlignMode.LEFT
        var pBold = false
        var pItalic = false
        var pUnderline = false
        var pStrike = false
        var pColor = "#111827"
        var pSize = 14f

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(":")
            when (eventType) {
                XmlPullParser.START_TAG -> when (tag) {
                    "tbl" -> {
                        inTable = true
                        currentRows = mutableListOf()
                    }
                    "tr" -> if (inTable) currentRow = mutableListOf()
                    "p" -> if (!inTable) {
                        inParagraph = true
                        pText = StringBuilder()
                        pStyle = ParagraphStyleKind.NORMAL
                        pAlign = TextAlignMode.LEFT
                        pBold = false
                        pItalic = false
                        pUnderline = false
                        pStrike = false
                        pColor = "#111827"
                        pSize = 14f
                    } else {
                        pText = StringBuilder()
                    }
                    "pStyle" -> {
                        val v = parser.getAttributeValue(null, "w:val") ?: parser.getAttributeValue(null, "val")
                        pStyle = when {
                            v?.contains("1") == true -> ParagraphStyleKind.HEADING_1
                            v?.contains("2") == true -> ParagraphStyleKind.HEADING_2
                            v?.contains("3") == true -> ParagraphStyleKind.HEADING_3
                            v?.contains("Quote", true) == true -> ParagraphStyleKind.QUOTE
                            else -> ParagraphStyleKind.NORMAL
                        }
                        pSize = pStyle.defaultSizeSp
                    }
                    "jc" -> {
                        val v = parser.getAttributeValue(null, "w:val") ?: parser.getAttributeValue(null, "val")
                        pAlign = when (v) {
                            "center" -> TextAlignMode.CENTER
                            "right" -> TextAlignMode.RIGHT
                            "both" -> TextAlignMode.JUSTIFY
                            else -> TextAlignMode.LEFT
                        }
                    }
                    "b" -> pBold = true
                    "i" -> pItalic = true
                    "u" -> pUnderline = true
                    "strike" -> pStrike = true
                    "color" -> {
                        val v = parser.getAttributeValue(null, "w:val") ?: parser.getAttributeValue(null, "val")
                        if (!v.isNullOrBlank() && v != "auto" && v.length == 6) pColor = "#$v"
                    }
                    "sz" -> {
                        val v = (parser.getAttributeValue(null, "w:val") ?: parser.getAttributeValue(null, "val"))?.toFloatOrNull()
                        if (v != null) pSize = (v / 2f).coerceIn(10f, 32f)
                    }
                    "t" -> pText.append(parser.nextText())
                    "br" -> pText.append("\n")
                }
                XmlPullParser.END_TAG -> when (tag) {
                    "tc" -> if (inTable) currentRow.add(pText.toString().trim())
                    "tr" -> if (inTable) currentRows.add(currentRow)
                    "tbl" -> {
                        inTable = false
                        if (currentRows.isNotEmpty()) {
                            result.add(DocBlock(isTable = true, tableRows = currentRows))
                        }
                    }
                    "p" -> if (!inTable && inParagraph) {
                        inParagraph = false
                        val raw = pText.toString()
                        val isBullet = raw.startsWith("• ")
                        result.add(
                            DocBlock(
                                text = if (isBullet) raw.removePrefix("• ") else raw,
                                style = pStyle,
                                align = pAlign,
                                listKind = if (isBullet) ListKind.BULLET else ListKind.NONE,
                                bold = pBold,
                                italic = pItalic,
                                underline = pUnderline,
                                strikethrough = pStrike,
                                fontSizeSp = pSize,
                                textColorHex = pColor,
                            )
                        )
                    }
                }
            }
            eventType = parser.next()
        }
        return result
    }

    private fun writeZipEntry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun escapeXml(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private const val CONTENT_TYPES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""

    private const val ROOT_RELS_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

    private const val STYLES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:rPr><w:b/><w:sz w:val="44"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:rPr><w:b/><w:sz w:val="36"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:rPr><w:b/><w:sz w:val="30"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:rPr><w:i/></w:rPr></w:style>
</w:styles>"""
}

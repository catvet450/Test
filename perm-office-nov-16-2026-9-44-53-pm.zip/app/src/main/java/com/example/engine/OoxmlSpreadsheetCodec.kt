package com.example.engine

import android.util.Xml
import com.example.model.CellData
import com.example.model.SheetModel
import com.example.model.WorkbookModel
import com.example.model.cellKey
import com.example.model.cellRefName
import com.example.model.parseCellKey
import com.example.model.parseCellRef
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object OoxmlSpreadsheetCodec {

    fun exportXlsx(workbook: WorkbookModel, output: OutputStream) {
        ZipOutputStream(output).use { zip ->
            writeZipEntry(zip, "[Content_Types].xml", buildContentTypes(workbook.sheets.size))
            writeZipEntry(zip, "_rels/.rels", ROOT_RELS_XML)
            writeZipEntry(zip, "xl/workbook.xml", buildWorkbookXml(workbook))
            writeZipEntry(zip, "xl/_rels/workbook.xml.rels", buildWorkbookRels(workbook.sheets.size))
            writeZipEntry(zip, "xl/styles.xml", MINIMAL_STYLES_XML)
            workbook.sheets.forEachIndexed { idx, sheet ->
                writeZipEntry(zip, "xl/worksheets/sheet${idx + 1}.xml", buildSheetXml(sheet))
            }
        }
    }

    fun importXlsx(input: InputStream): WorkbookModel {
        val entries = mutableMapOf<String, ByteArray>()
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                entries[entry.name] = zip.readBytes()
                entry = zip.nextEntry
            }
        }
        val sharedStrings = entries["xl/sharedStrings.xml"]?.let(::parseSharedStrings) ?: emptyList()
        val sheetNames = entries["xl/workbook.xml"]?.let(::parseSheetNames) ?: listOf("Лист 1")
        val sheetFiles = entries.keys.filter { it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml") }
            .sortedBy { it.removePrefix("xl/worksheets/sheet").removeSuffix(".xml").toIntOrNull() ?: 99 }

        val sheets = sheetFiles.mapIndexed { idx, path ->
            val name = sheetNames.getOrElse(idx) { "Лист ${idx + 1}" }
            val cells = parseSheetXml(entries[path]!!, sharedStrings)
            SheetModel(name = name, cells = cells)
        }.ifEmpty { listOf(SheetModel(name = "Лист 1")) }

        return FormulaEngine.recalculateWorkbook(WorkbookModel(sheets = sheets))
    }

    private fun buildSheetXml(sheet: SheetModel): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")

        val byRow = sheet.cells.entries
            .mapNotNull { (k, v) -> parseCellKey(k)?.let { Triple(it.first, it.second, v) } }
            .filter { it.third.rawInput.isNotBlank() }
            .groupBy { it.first }
            .toSortedMap()

        for ((rowIdx, rowCells) in byRow) {
            val rowNum = rowIdx + 1
            sb.append("""<row r="$rowNum">""")
            for ((r, c, cell) in rowCells.sortedBy { it.second }) {
                val ref = cellRefName(r, c)
                val raw = cell.rawInput.trim()
                val styleIdx = if (cell.bold) 1 else 0
                if (raw.startsWith("=")) {
                    val numVal = cell.evaluatedValue.replace(" ", "").replace("₽", "").replace(",", ".").toDoubleOrNull()
                    sb.append("""<c r="$ref" s="$styleIdx"><f>${escapeXml(raw.substring(1))}</f>""")
                    if (numVal != null) sb.append("<v>$numVal</v>")
                    sb.append("</c>")
                } else {
                    val num = raw.replace(" ", "").replace(",", ".").toDoubleOrNull()
                    if (num != null) {
                        sb.append("""<c r="$ref" s="$styleIdx"><v>$num</v></c>""")
                    } else {
                        sb.append("""<c r="$ref" t="inlineStr" s="$styleIdx"><is><t>${escapeXml(raw)}</t></is></c>""")
                    }
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        return sb.toString()
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val list = mutableListOf<String>()
        val parser = Xml.newPullParser()
        parser.setInput(bytes.inputStream(), "UTF-8")
        var current = StringBuilder()
        var inSi = false
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(":")
            when (event) {
                XmlPullParser.START_TAG -> when (tag) {
                    "si" -> { inSi = true; current = StringBuilder() }
                    "t" -> if (inSi) current.append(parser.nextText())
                }
                XmlPullParser.END_TAG -> if (tag == "si") {
                    inSi = false
                    list.add(current.toString())
                }
            }
            event = parser.next()
        }
        return list
    }

    private fun parseSheetNames(bytes: ByteArray): List<String> {
        val names = mutableListOf<String>()
        val parser = Xml.newPullParser()
        parser.setInput(bytes.inputStream(), "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name?.substringAfter(":") == "sheet") {
                parser.getAttributeValue(null, "name")?.let { names.add(it) }
            }
            event = parser.next()
        }
        return names
    }

    private fun parseSheetXml(bytes: ByteArray, sharedStrings: List<String>): Map<String, CellData> {
        val cells = mutableMapOf<String, CellData>()
        val parser = Xml.newPullParser()
        parser.setInput(bytes.inputStream(), "UTF-8")

        var currentRef: String? = null
        var currentType: String? = null
        var formula: String? = null
        var value: String? = null

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(":")
            when (event) {
                XmlPullParser.START_TAG -> when (tag) {
                    "c" -> {
                        currentRef = parser.getAttributeValue(null, "r")
                        currentType = parser.getAttributeValue(null, "t")
                        formula = null
                        value = null
                    }
                    "f" -> formula = parser.nextText()
                    "v", "t" -> value = parser.nextText()
                }
                XmlPullParser.END_TAG -> if (tag == "c" && currentRef != null) {
                    val rc = parseCellRef(currentRef!!)
                    if (rc != null) {
                        val rawInput = when {
                            !formula.isNullOrBlank() -> "=$formula"
                            currentType == "s" -> {
                                val idx = value?.toIntOrNull()
                                if (idx != null && idx in sharedStrings.indices) sharedStrings[idx] else value.orEmpty()
                            }
                            else -> value.orEmpty()
                        }
                        if (rawInput.isNotBlank()) {
                            cells[cellKey(rc.first, rc.second)] = CellData(rawInput = rawInput)
                        }
                    }
                    currentRef = null
                }
            }
            event = parser.next()
        }
        return cells
    }

    private fun buildContentTypes(sheetCount: Int): String {
        val overrides = (1..sheetCount).joinToString("") {
            """<Override PartName="/xl/worksheets/sheet$it.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>"""
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  $overrides
</Types>"""
    }

    private fun buildWorkbookXml(workbook: WorkbookModel): String {
        val sheetsXml = workbook.sheets.mapIndexed { idx, s ->
            """<sheet name="${escapeXml(s.name.take(31))}" sheetId="${idx + 1}" r:id="rId${idx + 1}"/>"""
        }.joinToString("")
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>$sheetsXml</sheets>
</workbook>"""
    }

    private fun buildWorkbookRels(sheetCount: Int): String {
        val sheetRels = (1..sheetCount).joinToString("") {
            """<Relationship Id="rId$it" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet$it.xml"/>"""
        }
        val styleId = sheetCount + 1
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  $sheetRels
  <Relationship Id="rId$styleId" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""
    }

    private fun writeZipEntry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun escapeXml(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private const val ROOT_RELS_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

    private const val MINIMAL_STYLES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2"><font><sz val="11"/><name val="Sans"/></font><font><b/><sz val="11"/><name val="Sans"/></font></fonts>
  <fills count="1"><fill><patternFill patternType="none"/></fill></fills>
  <borders count="1"><border/></borders>
  <cellXfs count="2"><xf fontId="0" fillId="0" borderId="0"/><xf fontId="1" fillId="0" borderId="0" applyFont="1"/></cellXfs>
</styleSheet>"""
}

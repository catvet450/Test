package com.example.engine

import android.util.Xml
import com.example.model.PresentationModel
import com.example.model.SlideElement
import com.example.model.SlideElementKind
import com.example.model.SlideModel
import com.example.model.SlideThemePreset
import com.example.model.TextAlignMode
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object OoxmlPresentationCodec {

    private const val SLIDE_WIDTH_EMU = 9144000L // 10 inches (16:9)
    private const val SLIDE_HEIGHT_EMU = 5143500L // 5.625 inches (16:9)

    fun exportPptx(presentation: PresentationModel, output: OutputStream) {
        val slides = presentation.slides.ifEmpty { listOf(SlideModel()) }
        ZipOutputStream(output).use { zip ->
            writeZipEntry(zip, "[Content_Types].xml", buildContentTypes(slides.size))
            writeZipEntry(zip, "_rels/.rels", ROOT_RELS_XML)
            writeZipEntry(zip, "ppt/presentation.xml", buildPresentationXml(slides.size))
            writeZipEntry(zip, "ppt/_rels/presentation.xml.rels", buildPresentationRels(slides.size))
            slides.forEachIndexed { idx, slide ->
                writeZipEntry(zip, "ppt/slides/slide${idx + 1}.xml", buildSlideXml(slide))
            }
        }
    }

    fun importPptx(input: InputStream): PresentationModel {
        val entries = mutableMapOf<String, ByteArray>()
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                entries[entry.name] = zip.readBytes()
                entry = zip.nextEntry
            }
        }
        val slidePaths = entries.keys
            .filter { it.startsWith("ppt/slides/slide") && it.endsWith(".xml") }
            .sortedBy { it.removePrefix("ppt/slides/slide").removeSuffix(".xml").toIntOrNull() ?: 99 }

        val slides = slidePaths.mapIndexed { idx, path ->
            parseSlideXml(entries[path]!!, idx + 1)
        }.ifEmpty { listOf(SlideModel(title = "Слайд 1")) }

        return PresentationModel(
            theme = SlideThemePreset.CLASSIC_LIGHT,
            slides = slides,
        )
    }

    private fun buildSlideXml(slide: SlideModel): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">""")
        sb.append("<p:cSld>")
        val bgHex = slide.bgColorHex.removePrefix("#").take(6).ifEmpty { "FFFFFF" }
        sb.append("""<p:bg><p:bgPr><a:solidFill><a:srgbClr val="$bgHex"/></a:solidFill></p:bgPr></p:bg>""")
        sb.append("<p:spTree><p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>")

        slide.elements.forEachIndexed { idx, el ->
            val x = (el.xFraction * SLIDE_WIDTH_EMU).toLong()
            val y = (el.yFraction * SLIDE_HEIGHT_EMU).toLong()
            val cx = (el.widthFraction * SLIDE_WIDTH_EMU).toLong().coerceAtLeast(100000L)
            val cy = (el.heightFraction * SLIDE_HEIGHT_EMU).toLong().coerceAtLeast(100000L)
            val id = idx + 2

            if (el.kind == SlideElementKind.TABLE && el.tableRows.isNotEmpty()) {
                sb.append("""<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="$id" name="Table $id"/><p:cNvGraphicFramePr/><p:nvPr/></p:nvGraphicFramePr>""")
                sb.append("""<p:xfrm><a:off x="$x" y="$y"/><a:ext cx="$cx" cy="$cy"/></p:xfrm>""")
                sb.append("""<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table"><a:tbl>""")
                val cols = el.tableRows.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
                sb.append("<a:tblGrid>")
                repeat(cols) { sb.append("""<a:gridCol w="${cx / cols}"/>""") }
                sb.append("</a:tblGrid>")
                for (row in el.tableRows) {
                    sb.append("""<a:tr h="${cy / el.tableRows.size.coerceAtLeast(1)}">""")
                    for (c in 0 until cols) {
                        val txt = escapeXml(row.getOrElse(c) { "" })
                        sb.append("""<a:tc><a:txBody><a:bodyPr/><a:p><a:r><a:t>$txt</a:t></a:r></a:p></a:txBody></a:tc>""")
                    }
                    sb.append("</a:tr>")
                }
                sb.append("</a:tbl></a:graphicData></a:graphic></p:graphicFrame>")
            } else {
                val prstGeom = when (el.kind) {
                    SlideElementKind.CIRCLE -> "ellipse"
                    SlideElementKind.ARROW -> "rightArrow"
                    else -> "rect"
                }
                sb.append("""<p:sp><p:nvSpPr><p:cNvPr id="$id" name="Shape $id"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>""")
                sb.append("<p:spPr>")
                sb.append("""<a:xfrm><a:off x="$x" y="$y"/><a:ext cx="$cx" cy="$cy"/></a:xfrm>""")
                sb.append("""<a:prstGeom prst="$prstGeom"><a:avLst/></a:prstGeom>""")
                val fill = el.fillColorHex?.removePrefix("#")?.take(6)
                if (fill != null && fill.length == 6) {
                    sb.append("""<a:solidFill><a:srgbClr val="$fill"/></a:solidFill>""")
                } else {
                    sb.append("<a:noFill/>")
                }
                sb.append("</p:spPr>")

                sb.append("<p:txBody><a:bodyPr/><a:lstStyle/>")
                val lines = el.text.ifEmpty { " " }.split("\n")
                val algn = when (el.align) {
                    TextAlignMode.CENTER -> "ctr"
                    TextAlignMode.RIGHT -> "r"
                    else -> "l"
                }
                val sz = (el.fontSizeSp * 100).toInt().coerceIn(1000, 6400)
                val color = el.textColorHex.removePrefix("#").take(6).ifEmpty { "111827" }
                for (line in lines) {
                    sb.append("""<a:p><a:pPr algn="$algn"/><a:r>""")
                    sb.append("""<a:rPr lang="ru-RU" sz="$sz" b="${if (el.bold) 1 else 0}" i="${if (el.italic) 1 else 0}"><a:solidFill><a:srgbClr val="$color"/></a:solidFill></a:rPr>""")
                    sb.append("""<a:t>${escapeXml(line)}</a:t></a:r></a:p>""")
                }
                sb.append("</p:txBody></p:sp>")
            }
        }

        sb.append("</p:spTree></p:cSld></p:sld>")
        return sb.toString()
    }

    private fun parseSlideXml(bytes: ByteArray, index: Int): SlideModel {
        val elements = mutableListOf<SlideElement>()
        val parser = Xml.newPullParser()
        parser.setInput(bytes.inputStream(), "UTF-8")

        var bgHex = "#FFFFFF"
        var inBg = false
        var inSp = false
        var kind = SlideElementKind.TEXT
        var xFrac = 0.1f
        var yFrac = 0.15f
        var wFrac = 0.8f
        var hFrac = 0.25f
        var fillHex: String? = null
        var textColor = "#111827"
        var textBuilder = StringBuilder()
        var fontSize = 18f
        var bold = false
        var italic = false

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            val tag = parser.name?.substringAfter(":")
            when (event) {
                XmlPullParser.START_TAG -> when (tag) {
                    "bg" -> inBg = true
                    "sp" -> {
                        inSp = true
                        kind = SlideElementKind.TEXT
                        xFrac = 0.1f; yFrac = 0.15f; wFrac = 0.8f; hFrac = 0.25f
                        fillHex = null; textColor = "#111827"
                        textBuilder = StringBuilder(); fontSize = 18f; bold = false; italic = false
                    }
                    "off" -> if (inSp) {
                        val x = parser.getAttributeValue(null, "x")?.toFloatOrNull() ?: 0f
                        val y = parser.getAttributeValue(null, "y")?.toFloatOrNull() ?: 0f
                        xFrac = (x / SLIDE_WIDTH_EMU).coerceIn(0f, 0.9f)
                        yFrac = (y / SLIDE_HEIGHT_EMU).coerceIn(0f, 0.9f)
                    }
                    "ext" -> if (inSp) {
                        val cx = parser.getAttributeValue(null, "cx")?.toFloatOrNull() ?: 0f
                        val cy = parser.getAttributeValue(null, "cy")?.toFloatOrNull() ?: 0f
                        if (cx > 0) wFrac = (cx / SLIDE_WIDTH_EMU).coerceIn(0.05f, 1f)
                        if (cy > 0) hFrac = (cy / SLIDE_HEIGHT_EMU).coerceIn(0.05f, 1f)
                    }
                    "prstGeom" -> if (inSp) {
                        kind = when (parser.getAttributeValue(null, "prst")) {
                            "ellipse" -> SlideElementKind.CIRCLE
                            "rightArrow" -> SlideElementKind.ARROW
                            else -> SlideElementKind.TEXT
                        }
                    }
                    "srgbClr" -> {
                        val v = parser.getAttributeValue(null, "val")
                        if (!v.isNullOrBlank() && v.length == 6) {
                            if (inBg) bgHex = "#$v"
                            else if (inSp && textBuilder.isEmpty()) fillHex = "#$v"
                            else if (inSp) textColor = "#$v"
                        }
                    }
                    "rPr" -> if (inSp) {
                        val sz = parser.getAttributeValue(null, "sz")?.toFloatOrNull()
                        if (sz != null) fontSize = (sz / 100f).coerceIn(10f, 44f)
                        bold = parser.getAttributeValue(null, "b") == "1"
                        italic = parser.getAttributeValue(null, "i") == "1"
                    }
                    "t" -> if (inSp) {
                        if (textBuilder.isNotEmpty()) textBuilder.append("\n")
                        textBuilder.append(parser.nextText())
                    }
                }
                XmlPullParser.END_TAG -> when (tag) {
                    "bg" -> inBg = false
                    "sp" -> {
                        inSp = false
                        val finalKind = if (kind == SlideElementKind.TEXT && fillHex != null && textBuilder.isBlank()) {
                            SlideElementKind.RECTANGLE
                        } else kind
                        elements.add(
                            SlideElement(
                                kind = finalKind,
                                xFraction = xFrac,
                                yFraction = yFrac,
                                widthFraction = wFrac,
                                heightFraction = hFrac,
                                text = textBuilder.toString().trim(),
                                fontSizeSp = fontSize,
                                bold = bold,
                                italic = italic,
                                fillColorHex = fillHex,
                                textColorHex = textColor,
                            )
                        )
                    }
                }
            }
            event = parser.next()
        }

        return SlideModel(title = "Слайд $index", bgColorHex = bgHex, elements = elements)
    }

    private fun buildContentTypes(slideCount: Int): String {
        val overrides = (1..slideCount).joinToString("") {
            """<Override PartName="/ppt/slides/slide$it.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>"""
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>
  $overrides
</Types>"""
    }

    private fun buildPresentationXml(slideCount: Int): String {
        val sldIds = (1..slideCount).joinToString("") {
            """<p:sldId id="${255 + it}" r:id="rId$it"/>"""
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <p:sldIdLst>$sldIds</p:sldIdLst>
  <p:sldSz cx="$SLIDE_WIDTH_EMU" cy="$SLIDE_HEIGHT_EMU"/>
  <p:notesSz cx="$SLIDE_HEIGHT_EMU" cy="$SLIDE_WIDTH_EMU"/>
</p:presentation>"""
    }

    private fun buildPresentationRels(slideCount: Int): String {
        val rels = (1..slideCount).joinToString("") {
            """<Relationship Id="rId$it" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide$it.xml"/>"""
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">$rels</Relationships>"""
    }

    private fun writeZipEntry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun escapeXml(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private const val ROOT_RELS_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>
</Relationships>"""
}

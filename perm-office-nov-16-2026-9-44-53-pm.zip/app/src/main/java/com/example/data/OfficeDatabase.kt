package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [OfficeDocumentEntity::class], version = 1, exportSchema = false)
abstract class OfficeDatabase : RoomDatabase() {
    abstract fun documentDao(): OfficeDocumentDao

    companion object {
        @Volatile
        private var INSTANCE: OfficeDatabase? = null

        fun getInstance(context: Context): OfficeDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    OfficeDatabase::class.java,
                    "perm_office.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}

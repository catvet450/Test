package com.example.data

import android.content.Context
import com.example.engine.FormulaEngine
import com.example.model.DocumentType
import com.example.model.PresentationModel
import com.example.model.SampleTemplates
import com.example.model.WordDocumentModel
import com.example.model.WorkbookModel
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class OfficeRepository(private val context: Context) {
    private val dao = OfficeDatabase.getInstance(context).documentDao()

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val wordAdapter = moshi.adapter(WordDocumentModel::class.java)
    private val workbookAdapter = moshi.adapter(WorkbookModel::class.java)
    private val presentationAdapter = moshi.adapter(PresentationModel::class.java)

    private val docsDir: File by lazy {
        File(context.filesDir, "office_docs").apply { mkdirs() }
    }

    val allDocuments: Flow<List<OfficeDocumentEntity>> = dao.observeAllDocuments()

    suspend fun ensureStarterSamples() = withContext(Dispatchers.IO) {
        if (dao.countDocuments() > 0) return@withContext
        createFromTemplate(
            title = "Квартальный отчёт",
            type = DocumentType.DOCUMENT,
            templateId = "doc_report",
            pinned = true,
        )
        createFromTemplate(
            title = "Бюджет проекта 2026",
            type = DocumentType.SPREADSHEET,
            templateId = "sheet_budget",
            pinned = true,
        )
        createFromTemplate(
            title = "Стратегия Perm Office",
            type = DocumentType.PRESENTATION,
            templateId = "slide_pitch",
            pinned = false,
        )
    }

    suspend fun createFromTemplate(
        title: String,
        type: DocumentType,
        templateId: String,
        pinned: Boolean = false,
    ): String = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val snippet = when (type) {
            DocumentType.DOCUMENT -> {
                val model = SampleTemplates.createDocumentByTemplate(templateId)
                writeJson(id, wordAdapter.toJson(model))
                extractDocSnippet(model)
            }
            DocumentType.SPREADSHEET -> {
                val raw = SampleTemplates.createWorkbookByTemplate(templateId)
                val evaluated = FormulaEngine.recalculateWorkbook(raw)
                writeJson(id, workbookAdapter.toJson(evaluated))
                extractWorkbookSnippet(evaluated)
            }
            DocumentType.PRESENTATION -> {
                val model = SampleTemplates.createPresentationByTemplate(templateId)
                writeJson(id, presentationAdapter.toJson(model))
                extractPresentationSnippet(model)
            }
        }
        dao.upsert(
            OfficeDocumentEntity(
                id = id,
                title = title,
                type = type.name,
                previewSnippet = snippet,
                isPinned = pinned,
                createdAt = now,
                updatedAt = now,
            )
        )
        id
    }

    suspend fun saveImportedDocument(title: String, model: WordDocumentModel): String =
        withContext(Dispatchers.IO) {
            val id = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            writeJson(id, wordAdapter.toJson(model))
            dao.upsert(
                OfficeDocumentEntity(
                    id = id,
                    title = title,
                    type = DocumentType.DOCUMENT.name,
                    previewSnippet = extractDocSnippet(model),
                    createdAt = now,
                    updatedAt = now,
                )
            )
            id
        }

    suspend fun saveImportedWorkbook(title: String, model: WorkbookModel): String =
        withContext(Dispatchers.IO) {
            val id = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            val recalculated = FormulaEngine.recalculateWorkbook(model)
            writeJson(id, workbookAdapter.toJson(recalculated))
            dao.upsert(
                OfficeDocumentEntity(
                    id = id,
                    title = title,
                    type = DocumentType.SPREADSHEET.name,
                    previewSnippet = extractWorkbookSnippet(recalculated),
                    createdAt = now,
                    updatedAt = now,
                )
            )
            id
        }

    suspend fun saveImportedPresentation(title: String, model: PresentationModel): String =
        withContext(Dispatchers.IO) {
            val id = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            writeJson(id, presentationAdapter.toJson(model))
            dao.upsert(
                OfficeDocumentEntity(
                    id = id,
                    title = title,
                    type = DocumentType.PRESENTATION.name,
                    previewSnippet = extractPresentationSnippet(model),
                    createdAt = now,
                    updatedAt = now,
                )
            )
            id
        }

    suspend fun getEntity(id: String): OfficeDocumentEntity? = withContext(Dispatchers.IO) {
        dao.getById(id)
    }

    suspend fun loadWordDocument(id: String): WordDocumentModel = withContext(Dispatchers.IO) {
        val file = fileFor(id)
        if (!file.exists()) return@withContext SampleTemplates.createDocumentByTemplate("doc_blank")
        wordAdapter.fromJson(file.readText()) ?: SampleTemplates.createDocumentByTemplate("doc_blank")
    }

    suspend fun saveWordDocument(id: String, title: String, model: WordDocumentModel) =
        withContext(Dispatchers.IO) {
            val existing = dao.getById(id)
            val now = System.currentTimeMillis()
            writeJson(id, wordAdapter.toJson(model))
            dao.upsert(
                OfficeDocumentEntity(
                    id = id,
                    title = title,
                    type = DocumentType.DOCUMENT.name,
                    previewSnippet = extractDocSnippet(model),
                    isPinned = existing?.isPinned ?: false,
                    createdAt = existing?.createdAt ?: now,
                    updatedAt = now,
                )
            )
        }

    suspend fun loadWorkbook(id: String): WorkbookModel = withContext(Dispatchers.IO) {
        val file = fileFor(id)
        if (!file.exists()) return@withContext SampleTemplates.createWorkbookByTemplate("sheet_blank")
        val loaded = workbookAdapter.fromJson(file.readText())
            ?: SampleTemplates.createWorkbookByTemplate("sheet_blank")
        FormulaEngine.recalculateWorkbook(loaded)
    }

    suspend fun saveWorkbook(id: String, title: String, model: WorkbookModel) =
        withContext(Dispatchers.IO) {
            val existing = dao.getById(id)
            val now = System.currentTimeMillis()
            writeJson(id, workbookAdapter.toJson(model))
            dao.upsert(
                OfficeDocumentEntity(
                    id = id,
                    title = title,
                    type = DocumentType.SPREADSHEET.name,
                    previewSnippet = extractWorkbookSnippet(model),
                    isPinned = existing?.isPinned ?: false,
                    createdAt = existing?.createdAt ?: now,
                    updatedAt = now,
                )
            )
        }

    suspend fun loadPresentation(id: String): PresentationModel = withContext(Dispatchers.IO) {
        val file = fileFor(id)
        if (!file.exists()) return@withContext SampleTemplates.createPresentationByTemplate("slide_blank")
        presentationAdapter.fromJson(file.readText())
            ?: SampleTemplates.createPresentationByTemplate("slide_blank")
    }

    suspend fun savePresentation(id: String, title: String, model: PresentationModel) =
        withContext(Dispatchers.IO) {
            val existing = dao.getById(id)
            val now = System.currentTimeMillis()
            writeJson(id, presentationAdapter.toJson(model))
            dao.upsert(
                OfficeDocumentEntity(
                    id = id,
                    title = title,
                    type = DocumentType.PRESENTATION.name,
                    previewSnippet = extractPresentationSnippet(model),
                    isPinned = existing?.isPinned ?: false,
                    createdAt = existing?.createdAt ?: now,
                    updatedAt = now,
                )
            )
        }

    suspend fun togglePin(entity: OfficeDocumentEntity) = withContext(Dispatchers.IO) {
        dao.setPinned(entity.id, !entity.isPinned)
    }

    suspend fun renameDocument(id: String, newTitle: String) = withContext(Dispatchers.IO) {
        if (newTitle.isNotBlank()) {
            dao.rename(id, newTitle.trim())
        }
    }

    suspend fun duplicateDocument(entity: OfficeDocumentEntity): String = withContext(Dispatchers.IO) {
        val newId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val srcFile = fileFor(entity.id)
        if (srcFile.exists()) {
            srcFile.copyTo(fileFor(newId), overwrite = true)
        }
        dao.upsert(
            entity.copy(
                id = newId,
                title = "${entity.title} (копия)",
                isPinned = false,
                createdAt = now,
                updatedAt = now,
            )
        )
        newId
    }

    suspend fun deleteDocument(id: String) = withContext(Dispatchers.IO) {
        dao.deleteById(id)
        fileFor(id).delete()
    }

    private fun fileFor(id: String): File = File(docsDir, "$id.json")

    private fun writeJson(id: String, content: String) {
        fileFor(id).writeText(content)
    }

    private fun extractDocSnippet(model: WordDocumentModel): String {
        val firstText = model.blocks.firstOrNull { !it.isTable && it.text.isNotBlank() }?.text
        val words = model.blocks.filter { !it.isTable }
            .sumOf { it.text.trim().split(Regex("\\s+")).count { w -> w.isNotBlank() } }
        return if (firstText != null) {
            "${firstText.take(64)} • $words сл."
        } else {
            "Документ • ${model.blocks.size} блок."
        }
    }

    private fun extractWorkbookSnippet(model: WorkbookModel): String {
        val sheetCount = model.sheets.size
        val filled = model.sheets.sumOf { s -> s.cells.count { it.value.rawInput.isNotBlank() } }
        return "Листов: $sheetCount • Заполнено ячеек: $filled"
    }

    private fun extractPresentationSnippet(model: PresentationModel): String {
        return "Слайдов: ${model.slides.size} • ${model.theme.labelRu}"
    }
}

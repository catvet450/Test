package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface OfficeDocumentDao {
    @Query("SELECT * FROM office_documents ORDER BY isPinned DESC, updatedAt DESC")
    fun observeAllDocuments(): Flow<List<OfficeDocumentEntity>>

    @Query("SELECT * FROM office_documents WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): OfficeDocumentEntity?

    @Query("SELECT COUNT(*) FROM office_documents")
    suspend fun countDocuments(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: OfficeDocumentEntity)

    @Query("UPDATE office_documents SET isPinned = :pinned WHERE id = :id")
    suspend fun setPinned(id: String, pinned: Boolean)

    @Query("UPDATE office_documents SET title = :title, updatedAt = :updatedAt WHERE id = :id")
    suspend fun rename(id: String, title: String, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM office_documents WHERE id = :id")
    suspend fun deleteById(id: String)
}

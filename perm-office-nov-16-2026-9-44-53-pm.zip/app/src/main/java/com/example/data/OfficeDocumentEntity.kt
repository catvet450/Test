package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "office_documents")
data class OfficeDocumentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val type: String, // DOCUMENT, SPREADSHEET, PRESENTATION
    val previewSnippet: String,
    val isPinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

package com.example.model

import java.util.UUID

enum class DocumentType(val labelRu: String, val extension: String) {
    DOCUMENT("Документ", "docx"),
    SPREADSHEET("Таблица", "xlsx"),
    PRESENTATION("Презентация", "pptx"),
}

enum class TextAlignMode { LEFT, CENTER, RIGHT, JUSTIFY }

// ==================== DOCUMENT (WRITER) MODELS ====================

enum class ParagraphStyleKind(val labelRu: String, val defaultSizeSp: Float) {
    NORMAL("Обычный", 14f),
    HEADING_1("Заголовок 1", 24f),
    HEADING_2("Заголовок 2", 19f),
    HEADING_3("Заголовок 3", 16f),
    QUOTE("Цитата", 14f),
}

enum class ListKind { NONE, BULLET, NUMBERED }

enum class PageOrientation(val labelRu: String) {
    PORTRAIT("Книжная"),
    LANDSCAPE("Альбомная"),
}

enum class PageMarginPreset(val labelRu: String, val dpPadding: Int, val ptMargin: Int) {
    NARROW("Узкие", 16, 28),
    NORMAL("Обычные", 28, 54),
    WIDE("Широкие", 42, 76),
}

enum class DocFontKind(val labelRu: String) {
    SANS("Sans"),
    SERIF("Serif"),
    MONO("Mono"),
}

data class DocPageSettings(
    val orientation: PageOrientation = PageOrientation.PORTRAIT,
    val margins: PageMarginPreset = PageMarginPreset.NORMAL,
    val lineSpacingMultiplier: Float = 1.35f,
    val showPageNumbers: Boolean = true,
)

data class DocBlock(
    val id: String = UUID.randomUUID().toString(),
    val isTable: Boolean = false,
    val text: String = "",
    val style: ParagraphStyleKind = ParagraphStyleKind.NORMAL,
    val align: TextAlignMode = TextAlignMode.LEFT,
    val listKind: ListKind = ListKind.NONE,
    val indentLevel: Int = 0,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val strikethrough: Boolean = false,
    val fontSizeSp: Float = 14f,
    val fontKind: DocFontKind = DocFontKind.SANS,
    val textColorHex: String = "#111827",
    val highlightColorHex: String? = null,
    val tableRows: List<List<String>> = emptyList(),
)

data class WordDocumentModel(
    val pageSettings: DocPageSettings = DocPageSettings(),
    val blocks: List<DocBlock> = listOf(DocBlock()),
)

// ==================== SPREADSHEET (CALC) MODELS ====================

enum class CellNumberFormat(val labelRu: String) {
    GENERAL("Общий"),
    CURRENCY_RUB("Рубли ₽"),
    CURRENCY_USD("Доллары $"),
    PERCENT("Проценты %"),
    INTEGER("Целое"),
    DECIMAL_2("0.00"),
}

data class CellData(
    val rawInput: String = "",
    val evaluatedValue: String = "",
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val align: TextAlignMode = TextAlignMode.LEFT,
    val bgColorHex: String? = null,
    val textColorHex: String = "#111827",
    val numberFormat: CellNumberFormat = CellNumberFormat.GENERAL,
    val hasBorder: Boolean = true,
)

enum class ChartKind(val labelRu: String) {
    COLUMN("Столбчатая"),
    LINE("Линейная"),
    PIE("Круговая"),
}

data class ChartSpec(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Диаграмма",
    val kind: ChartKind = ChartKind.COLUMN,
    val labelRange: String = "A2:A5",
    val valueRange: String = "B2:B5",
)

data class SheetModel(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Лист 1",
    val rowCount: Int = 50,
    val colCount: Int = 20,
    val cells: Map<String, CellData> = emptyMap(), // key: "R,C" e.g. "0,0" for A1
    val columnWidthsDp: Map<Int, Float> = emptyMap(),
    val charts: List<ChartSpec> = emptyList(),
)

data class WorkbookModel(
    val activeSheetIndex: Int = 0,
    val sheets: List<SheetModel> = listOf(SheetModel()),
)

// ==================== PRESENTATION (SLIDES) MODELS ====================

enum class SlideElementKind { TEXT, RECTANGLE, CIRCLE, ARROW, TABLE }

enum class SlideLayoutKind(val labelRu: String) {
    TITLE("Титульный"),
    TITLE_AND_BODY("Заголовок и текст"),
    TWO_COLUMNS("Два столбца"),
    BLANK("Пустой"),
}

enum class SlideTransitionKind(val labelRu: String) {
    NONE("Без перехода"),
    FADE("Плавное появление"),
    SLIDE("Сдвиг"),
}

enum class SlideThemePreset(
    val labelRu: String,
    val bgHex: String,
    val titleHex: String,
    val bodyHex: String,
    val accentHex: String,
) {
    CLASSIC_LIGHT("Светлая классика", "#FFFFFF", "#1E3A5F", "#374151", "#2563EB"),
    SAPPHIRE_DARK("Сапфир ночь", "#0F1E36", "#F8FAFC", "#CBD5E1", "#60A5FA"),
    EMERALD_CLEAN("Изумрудный бриз", "#ECFDF5", "#064E3B", "#1F2937", "#059669"),
    AMBER_WARM("Тёплый графит", "#1F242D", "#FEF3C7", "#E5E7EB", "#F59E0B"),
}

data class SlideElement(
    val id: String = UUID.randomUUID().toString(),
    val kind: SlideElementKind = SlideElementKind.TEXT,
    val xFraction: Float = 0.1f,
    val yFraction: Float = 0.15f,
    val widthFraction: Float = 0.8f,
    val heightFraction: Float = 0.25f,
    val text: String = "",
    val fontSizeSp: Float = 18f,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val align: TextAlignMode = TextAlignMode.LEFT,
    val fillColorHex: String? = null,
    val textColorHex: String = "#111827",
    val tableRows: List<List<String>> = emptyList(),
)

data class SlideModel(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Слайд",
    val bgColorHex: String = "#FFFFFF",
    val transition: SlideTransitionKind = SlideTransitionKind.FADE,
    val elements: List<SlideElement> = emptyList(),
)

data class PresentationModel(
    val theme: SlideThemePreset = SlideThemePreset.CLASSIC_LIGHT,
    val slides: List<SlideModel> = emptyList(),
)

// ==================== HELPER EXTENSIONS ====================

fun colIndexToName(col: Int): String {
    var index = col
    val sb = StringBuilder()
    while (index >= 0) {
        sb.insert(0, ('A' + (index % 26)))
        index = (index / 26) - 1
    }
    return sb.toString()
}

fun colNameToIndex(name: String): Int {
    var result = 0
    for (ch in name.uppercase()) {
        if (ch !in 'A'..'Z') return -1
        result = result * 26 + (ch - 'A' + 1)
    }
    return result - 1
}

fun cellKey(row: Int, col: Int): String = "$row,$col"

fun parseCellKey(key: String): Pair<Int, Int>? {
    val parts = key.split(",")
    if (parts.size != 2) return null
    val r = parts[0].toIntOrNull() ?: return null
    val c = parts[1].toIntOrNull() ?: return null
    return r to c
}

fun cellRefName(row: Int, col: Int): String = "${colIndexToName(col)}${row + 1}"

fun parseCellRef(ref: String): Pair<Int, Int>? {
    val trimmed = ref.trim().uppercase().replace("$", "")
    val match = Regex("^([A-Z]+)([1-9][0-9]*)$").matchEntire(trimmed) ?: return null
    val col = colNameToIndex(match.groupValues[1])
    val row = match.groupValues[2].toIntOrNull()?.minus(1) ?: return null
    if (col < 0 || row < 0) return null
    return row to col
}

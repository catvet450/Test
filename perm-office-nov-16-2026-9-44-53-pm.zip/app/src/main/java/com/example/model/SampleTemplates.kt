package com.example.model

data class OfficeTemplateItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val type: DocumentType,
)

object SampleTemplates {
    val templates = listOf(
        OfficeTemplateItem(
            id = "doc_blank",
            title = "Пустой документ",
            subtitle = "Чистый лист A4 с базовыми стилями",
            type = DocumentType.DOCUMENT,
        ),
        OfficeTemplateItem(
            id = "doc_report",
            title = "Отчёт по проекту",
            subtitle = "Заголовки, список задач и таблица KPI",
            type = DocumentType.DOCUMENT,
        ),
        OfficeTemplateItem(
            id = "doc_letter",
            title = "Деловое письмо",
            subtitle = "Официальное оформление с реквизитами",
            type = DocumentType.DOCUMENT,
        ),
        OfficeTemplateItem(
            id = "sheet_blank",
            title = "Пустая таблица",
            subtitle = "Сетка A–T с движком формул",
            type = DocumentType.SPREADSHEET,
        ),
        OfficeTemplateItem(
            id = "sheet_budget",
            title = "Бюджет проекта",
            subtitle = "Формулы SUM/AVERAGE/IF и диаграмма",
            type = DocumentType.SPREADSHEET,
        ),
        OfficeTemplateItem(
            id = "sheet_sales",
            title = "План продаж",
            subtitle = "Сравнение кварталов с графиком",
            type = DocumentType.SPREADSHEET,
        ),
        OfficeTemplateItem(
            id = "slide_blank",
            title = "Пустая презентация",
            subtitle = "Широкоформатный слайд 16:9",
            type = DocumentType.PRESENTATION,
        ),
        OfficeTemplateItem(
            id = "slide_pitch",
            title = "Питч-дек (4 слайда)",
            subtitle = "Титул, тезисы, сравнение, итог",
            type = DocumentType.PRESENTATION,
        ),
    )

    fun createDocumentByTemplate(templateId: String): WordDocumentModel = when (templateId) {
        "doc_report" -> WordDocumentModel(
            blocks = listOf(
                DocBlock(
                    text = "Квартальный отчёт по развитию продукта",
                    style = ParagraphStyleKind.HEADING_1,
                    bold = true,
                    fontSizeSp = 24f,
                    textColorHex = "#1E3A5F",
                ),
                DocBlock(
                    text = "Подготовлено в Perm Office • Автономная редакция",
                    style = ParagraphStyleKind.NORMAL,
                    italic = true,
                    fontSizeSp = 12f,
                    textColorHex = "#6B7280",
                ),
                DocBlock(
                    text = "1. Ключевые итоги",
                    style = ParagraphStyleKind.HEADING_2,
                    bold = true,
                    fontSizeSp = 18f,
                    textColorHex = "#2563EB",
                ),
                DocBlock(
                    text = "Команда успешно завершила оптимизацию рабочего процесса и сократила издержки на 18% без потери качества.",
                    style = ParagraphStyleKind.NORMAL,
                    fontSizeSp = 14f,
                ),
                DocBlock(
                    text = "Запущен автономный мобильный клиент для работы без сети",
                    listKind = ListKind.BULLET,
                    fontSizeSp = 14f,
                ),
                DocBlock(
                    text = "Реализована полная совместимость с форматами DOCX, XLSX, PPTX и PDF",
                    listKind = ListKind.BULLET,
                    fontSizeSp = 14f,
                ),
                DocBlock(
                    text = "2. Показатели эффективности",
                    style = ParagraphStyleKind.HEADING_2,
                    bold = true,
                    fontSizeSp = 18f,
                    textColorHex = "#2563EB",
                ),
                DocBlock(
                    isTable = true,
                    tableRows = listOf(
                        listOf("Показатель", "План", "Факт", "Выполнение"),
                        listOf("Скорость отчётов", "12 дн.", "9 дн.", "125%"),
                        listOf("Экономия бюджета", "150 000 ₽", "178 000 ₽", "119%"),
                        listOf("Готовность релиза", "95%", "100%", "105%"),
                    ),
                ),
                DocBlock(
                    text = "«Простые и надёжные инструменты экономят часы каждый день.»",
                    style = ParagraphStyleKind.QUOTE,
                    italic = true,
                    fontKind = DocFontKind.SERIF,
                    fontSizeSp = 14f,
                    textColorHex = "#374151",
                ),
            ),
        )
        "doc_letter" -> WordDocumentModel(
            blocks = listOf(
                DocBlock(
                    text = "ООО «Пермские Решения»",
                    style = ParagraphStyleKind.HEADING_2,
                    bold = true,
                    align = TextAlignMode.RIGHT,
                    fontSizeSp = 16f,
                    textColorHex = "#1E3A5F",
                ),
                DocBlock(
                    text = "Исх. № 48/2026 от 16.11.2026",
                    align = TextAlignMode.RIGHT,
                    fontSizeSp = 12f,
                    textColorHex = "#6B7280",
                ),
                DocBlock(
                    text = "Коммерческое предложение",
                    style = ParagraphStyleKind.HEADING_1,
                    bold = true,
                    align = TextAlignMode.CENTER,
                    fontSizeSp = 22f,
                ),
                DocBlock(
                    text = "Уважаемые партнёры!",
                    bold = true,
                    fontSizeSp = 14f,
                ),
                DocBlock(
                    text = "Направляем вам обновлённые условия сотрудничества на следующий квартал. Все расчёты и спецификации приложены в пакете документов.",
                    align = TextAlignMode.JUSTIFY,
                    fontSizeSp = 14f,
                    fontKind = DocFontKind.SERIF,
                ),
                DocBlock(
                    text = "С уважением,\nРуководитель проектного офиса",
                    fontSizeSp = 14f,
                ),
            ),
        )
        else -> WordDocumentModel(
            blocks = listOf(
                DocBlock(
                    text = "Новый документ",
                    style = ParagraphStyleKind.HEADING_1,
                    bold = true,
                    fontSizeSp = 22f,
                ),
                DocBlock(
                    text = "Начните печатать текст здесь. Используйте ленту инструментов сверху для выбора стиля заголовка, шрифта, цвета, списков и вставки таблиц.",
                    style = ParagraphStyleKind.NORMAL,
                    fontSizeSp = 14f,
                ),
            ),
        )
    }

    fun createWorkbookByTemplate(templateId: String): WorkbookModel = when (templateId) {
        "sheet_budget" -> {
            val cells = mutableMapOf<String, CellData>()
            fun header(r: Int, c: Int, text: String) {
                cells[cellKey(r, c)] = CellData(
                    rawInput = text,
                    evaluatedValue = text,
                    bold = true,
                    bgColorHex = "#1E3A5F",
                    textColorHex = "#FFFFFF",
                    align = TextAlignMode.CENTER,
                )
            }
            header(0, 0, "Категория")
            header(0, 1, "План")
            header(0, 2, "Факт")
            header(0, 3, "Остаток")
            header(0, 4, "Статус")

            val rows = listOf(
                Triple("Разработка", "120000", "112000"),
                Triple("Дизайн", "45000", "42500"),
                Triple("Тестирование", "35000", "38000"),
                Triple("Инфраструктура", "28000", "24000"),
            )
            rows.forEachIndexed { idx, (name, plan, fact) ->
                val r = idx + 1
                val rowNum = r + 1
                cells[cellKey(r, 0)] = CellData(rawInput = name, evaluatedValue = name)
                cells[cellKey(r, 1)] = CellData(
                    rawInput = plan,
                    align = TextAlignMode.RIGHT,
                    numberFormat = CellNumberFormat.CURRENCY_RUB,
                )
                cells[cellKey(r, 2)] = CellData(
                    rawInput = fact,
                    align = TextAlignMode.RIGHT,
                    numberFormat = CellNumberFormat.CURRENCY_RUB,
                )
                cells[cellKey(r, 3)] = CellData(
                    rawInput = "=B$rowNum-C$rowNum",
                    align = TextAlignMode.RIGHT,
                    numberFormat = CellNumberFormat.CURRENCY_RUB,
                )
                cells[cellKey(r, 4)] = CellData(
                    rawInput = "=IF(D$rowNum>=0,\"В норме\",\"Перерасход\")",
                    align = TextAlignMode.CENTER,
                )
            }
            cells[cellKey(5, 0)] = CellData(
                rawInput = "ИТОГО",
                bold = true,
                bgColorHex = "#D1FAE5",
            )
            cells[cellKey(5, 1)] = CellData(
                rawInput = "=SUM(B2:B5)",
                bold = true,
                bgColorHex = "#D1FAE5",
                align = TextAlignMode.RIGHT,
                numberFormat = CellNumberFormat.CURRENCY_RUB,
            )
            cells[cellKey(5, 2)] = CellData(
                rawInput = "=SUM(C2:C5)",
                bold = true,
                bgColorHex = "#D1FAE5",
                align = TextAlignMode.RIGHT,
                numberFormat = CellNumberFormat.CURRENCY_RUB,
            )
            cells[cellKey(5, 3)] = CellData(
                rawInput = "=SUM(D2:D5)",
                bold = true,
                bgColorHex = "#D1FAE5",
                align = TextAlignMode.RIGHT,
                numberFormat = CellNumberFormat.CURRENCY_RUB,
            )
            cells[cellKey(6, 0)] = CellData(rawInput = "Средний факт", italic = true)
            cells[cellKey(6, 2)] = CellData(
                rawInput = "=AVERAGE(C2:C5)",
                italic = true,
                align = TextAlignMode.RIGHT,
                numberFormat = CellNumberFormat.CURRENCY_RUB,
            )

            WorkbookModel(
                sheets = listOf(
                    SheetModel(
                        name = "Бюджет",
                        cells = cells,
                        charts = listOf(
                            ChartSpec(
                                title = "Фактические расходы по статьям",
                                kind = ChartKind.COLUMN,
                                labelRange = "A2:A5",
                                valueRange = "C2:C5",
                            )
                        ),
                    ),
                    SheetModel(name = "Заметки"),
                )
            )
        }
        "sheet_sales" -> {
            val cells = mutableMapOf<String, CellData>()
            listOf("Квартал", "Выручка", "Цель").forEachIndexed { c, t ->
                cells[cellKey(0, c)] = CellData(
                    rawInput = t,
                    bold = true,
                    bgColorHex = "#059669",
                    textColorHex = "#FFFFFF",
                    align = TextAlignMode.CENTER,
                )
            }
            val data = listOf(
                Triple("Q1", "410000", "400000"),
                Triple("Q2", "495000", "450000"),
                Triple("Q3", "530000", "500000"),
                Triple("Q4", "640000", "580000"),
            )
            data.forEachIndexed { idx, (q, rev, target) ->
                val r = idx + 1
                cells[cellKey(r, 0)] = CellData(rawInput = q, align = TextAlignMode.CENTER)
                cells[cellKey(r, 1)] = CellData(
                    rawInput = rev,
                    align = TextAlignMode.RIGHT,
                    numberFormat = CellNumberFormat.CURRENCY_RUB,
                )
                cells[cellKey(r, 2)] = CellData(
                    rawInput = target,
                    align = TextAlignMode.RIGHT,
                    numberFormat = CellNumberFormat.CURRENCY_RUB,
                )
            }
            cells[cellKey(5, 0)] = CellData(rawInput = "Максимум", bold = true)
            cells[cellKey(5, 1)] = CellData(
                rawInput = "=MAX(B2:B5)",
                bold = true,
                align = TextAlignMode.RIGHT,
                numberFormat = CellNumberFormat.CURRENCY_RUB,
            )
            WorkbookModel(
                sheets = listOf(
                    SheetModel(
                        name = "Продажи",
                        cells = cells,
                        charts = listOf(
                            ChartSpec(
                                title = "Динамика выручки по кварталам",
                                kind = ChartKind.LINE,
                                labelRange = "A2:A5",
                                valueRange = "B2:B5",
                            )
                        ),
                    )
                )
            )
        }
        else -> WorkbookModel(
            sheets = listOf(SheetModel(name = "Лист 1"))
        )
    }

    fun createPresentationByTemplate(templateId: String): PresentationModel = when (templateId) {
        "slide_pitch" -> PresentationModel(
            theme = SlideThemePreset.SAPPHIRE_DARK,
            slides = listOf(
                SlideModel(
                    title = "Титульный слайд",
                    bgColorHex = "#0F1E36",
                    transition = SlideTransitionKind.FADE,
                    elements = listOf(
                        SlideElement(
                            kind = SlideElementKind.RECTANGLE,
                            xFraction = 0.06f,
                            yFraction = 0.16f,
                            widthFraction = 0.015f,
                            heightFraction = 0.62f,
                            fillColorHex = "#60A5FA",
                        ),
                        SlideElement(
                            kind = SlideElementKind.TEXT,
                            xFraction = 0.10f,
                            yFraction = 0.24f,
                            widthFraction = 0.82f,
                            heightFraction = 0.24f,
                            text = "Стратегия мобильной продуктивности",
                            fontSizeSp = 26f,
                            bold = true,
                            textColorHex = "#F8FAFC",
                        ),
                        SlideElement(
                            kind = SlideElementKind.TEXT,
                            xFraction = 0.10f,
                            yFraction = 0.52f,
                            widthFraction = 0.78f,
                            heightFraction = 0.18f,
                            text = "Автономная работа с документами, таблицами и отчётами на любом экране • Perm Office 2026",
                            fontSizeSp = 15f,
                            textColorHex = "#CBD5E1",
                        ),
                    ),
                ),
                SlideModel(
                    title = "Ключевые возможности",
                    bgColorHex = "#0F1E36",
                    transition = SlideTransitionKind.SLIDE,
                    elements = listOf(
                        SlideElement(
                            kind = SlideElementKind.TEXT,
                            xFraction = 0.06f,
                            yFraction = 0.08f,
                            widthFraction = 0.88f,
                            heightFraction = 0.14f,
                            text = "Три редактора в одном пакете",
                            fontSizeSp = 21f,
                            bold = true,
                            textColorHex = "#F8FAFC",
                        ),
                        SlideElement(
                            kind = SlideElementKind.RECTANGLE,
                            xFraction = 0.06f,
                            yFraction = 0.28f,
                            widthFraction = 0.27f,
                            heightFraction = 0.54f,
                            fillColorHex = "#1E3A8A",
                            text = "Документы\n\nСтили, таблицы,\nсписки и PDF",
                            fontSizeSp = 13f,
                            textColorHex = "#DBEAFE",
                            align = TextAlignMode.CENTER,
                        ),
                        SlideElement(
                            kind = SlideElementKind.RECTANGLE,
                            xFraction = 0.365f,
                            yFraction = 0.28f,
                            widthFraction = 0.27f,
                            heightFraction = 0.54f,
                            fillColorHex = "#065F46",
                            text = "Таблицы\n\nФормулы SUM/IF,\nдиаграммы XLSX",
                            fontSizeSp = 13f,
                            textColorHex = "#D1FAE5",
                            align = TextAlignMode.CENTER,
                        ),
                        SlideElement(
                            kind = SlideElementKind.RECTANGLE,
                            xFraction = 0.67f,
                            yFraction = 0.28f,
                            widthFraction = 0.27f,
                            heightFraction = 0.54f,
                            fillColorHex = "#92400E",
                            text = "Презентации\n\nФигуры, темы и\nлазерная указка",
                            fontSizeSp = 13f,
                            textColorHex = "#FEF3C7",
                            align = TextAlignMode.CENTER,
                        ),
                    ),
                ),
                SlideModel(
                    title = "Метрики",
                    bgColorHex = "#0F1E36",
                    transition = SlideTransitionKind.FADE,
                    elements = listOf(
                        SlideElement(
                            kind = SlideElementKind.TEXT,
                            xFraction = 0.06f,
                            yFraction = 0.08f,
                            widthFraction = 0.88f,
                            heightFraction = 0.14f,
                            text = "Сравнение формата работы",
                            fontSizeSp = 21f,
                            bold = true,
                            textColorHex = "#F8FAFC",
                        ),
                        SlideElement(
                            kind = SlideElementKind.TABLE,
                            xFraction = 0.06f,
                            yFraction = 0.28f,
                            widthFraction = 0.88f,
                            heightFraction = 0.54f,
                            textColorHex = "#111827",
                            fillColorHex = "#F8FAFC",
                            tableRows = listOf(
                                listOf("Критерий", "Офлайн-пакет", "Облако"),
                                listOf("Работа без сети", "100% доступно", "Ограничено"),
                                listOf("Экспорт PDF/OOXML", "Мгновенно", "Требует сеть"),
                                listOf("Контроль данных", "На устройстве", "На сервере"),
                            ),
                        ),
                    ),
                ),
                SlideModel(
                    title = "Спасибо",
                    bgColorHex = "#0F1E36",
                    transition = SlideTransitionKind.FADE,
                    elements = listOf(
                        SlideElement(
                            kind = SlideElementKind.CIRCLE,
                            xFraction = 0.40f,
                            yFraction = 0.16f,
                            widthFraction = 0.20f,
                            heightFraction = 0.34f,
                            fillColorHex = "#2563EB",
                            text = "✓",
                            fontSizeSp = 26f,
                            bold = true,
                            textColorHex = "#FFFFFF",
                            align = TextAlignMode.CENTER,
                        ),
                        SlideElement(
                            kind = SlideElementKind.TEXT,
                            xFraction = 0.12f,
                            yFraction = 0.56f,
                            widthFraction = 0.76f,
                            heightFraction = 0.20f,
                            text = "Благодарим за внимание!",
                            fontSizeSp = 24f,
                            bold = true,
                            align = TextAlignMode.CENTER,
                            textColorHex = "#F8FAFC",
                        ),
                    ),
                ),
            ),
        )
        else -> PresentationModel(
            theme = SlideThemePreset.CLASSIC_LIGHT,
            slides = listOf(
                createSlideFromLayout(SlideLayoutKind.TITLE, SlideThemePreset.CLASSIC_LIGHT),
            ),
        )
    }

    fun createSlideFromLayout(layout: SlideLayoutKind, theme: SlideThemePreset): SlideModel {
        val elements = when (layout) {
            SlideLayoutKind.TITLE -> listOf(
                SlideElement(
                    kind = SlideElementKind.TEXT,
                    xFraction = 0.08f,
                    yFraction = 0.28f,
                    widthFraction = 0.84f,
                    heightFraction = 0.22f,
                    text = "Заголовок презентации",
                    fontSizeSp = 26f,
                    bold = true,
                    align = TextAlignMode.CENTER,
                    textColorHex = theme.titleHex,
                ),
                SlideElement(
                    kind = SlideElementKind.TEXT,
                    xFraction = 0.14f,
                    yFraction = 0.54f,
                    widthFraction = 0.72f,
                    heightFraction = 0.16f,
                    text = "Подзаголовок или имя докладчика",
                    fontSizeSp = 15f,
                    align = TextAlignMode.CENTER,
                    textColorHex = theme.bodyHex,
                ),
            )
            SlideLayoutKind.TITLE_AND_BODY -> listOf(
                SlideElement(
                    kind = SlideElementKind.TEXT,
                    xFraction = 0.06f,
                    yFraction = 0.08f,
                    widthFraction = 0.88f,
                    heightFraction = 0.16f,
                    text = "Заголовок слайда",
                    fontSizeSp = 21f,
                    bold = true,
                    textColorHex = theme.titleHex,
                ),
                SlideElement(
                    kind = SlideElementKind.TEXT,
                    xFraction = 0.06f,
                    yFraction = 0.28f,
                    widthFraction = 0.88f,
                    heightFraction = 0.58f,
                    text = "• Основная мысль первого пункта\n• Поддерживающий аргумент\n• Итоговый вывод",
                    fontSizeSp = 15f,
                    textColorHex = theme.bodyHex,
                ),
            )
            SlideLayoutKind.TWO_COLUMNS -> listOf(
                SlideElement(
                    kind = SlideElementKind.TEXT,
                    xFraction = 0.06f,
                    yFraction = 0.08f,
                    widthFraction = 0.88f,
                    heightFraction = 0.15f,
                    text = "Сравнение вариантов",
                    fontSizeSp = 20f,
                    bold = true,
                    textColorHex = theme.titleHex,
                ),
                SlideElement(
                    kind = SlideElementKind.TEXT,
                    xFraction = 0.06f,
                    yFraction = 0.28f,
                    widthFraction = 0.42f,
                    heightFraction = 0.58f,
                    text = "Столбец 1\n\nДобавьте текст или факты для левой стороны.",
                    fontSizeSp = 14f,
                    textColorHex = theme.bodyHex,
                ),
                SlideElement(
                    kind = SlideElementKind.TEXT,
                    xFraction = 0.52f,
                    yFraction = 0.28f,
                    widthFraction = 0.42f,
                    heightFraction = 0.58f,
                    text = "Столбец 2\n\nДобавьте текст или факты для правой стороны.",
                    fontSizeSp = 14f,
                    textColorHex = theme.bodyHex,
                ),
            )
            SlideLayoutKind.BLANK -> emptyList()
        }
        return SlideModel(
            title = layout.labelRu,
            bgColorHex = theme.bgHex,
            elements = elements,
        )
    }
}

package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.model.DocumentType
import com.example.ui.document.DocumentEditorScreen
import com.example.ui.hub.HubScreen
import com.example.ui.presentation.PresentationEditorScreen
import com.example.ui.spreadsheet.SpreadsheetEditorScreen
import com.example.ui.theme.PermOfficeTheme

object OfficeRoutes {
    const val HUB = "hub"
    const val DOCUMENT = "document/{docId}"
    const val SPREADSHEET = "spreadsheet/{docId}"
    const val PRESENTATION = "presentation/{docId}"

    fun forDocument(id: String, type: DocumentType): String = when (type) {
        DocumentType.DOCUMENT -> "document/$id"
        DocumentType.SPREADSHEET -> "spreadsheet/$id"
        DocumentType.PRESENTATION -> "presentation/$id"
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PermOfficeTheme {
                val navController = rememberNavController()
                NavHost(
                    navController = navController,
                    startDestination = OfficeRoutes.HUB,
                ) {
                    composable(OfficeRoutes.HUB) {
                        HubScreen(
                            onOpenDocument = { docId, type ->
                                navController.navigate(OfficeRoutes.forDocument(docId, type))
                            },
                        )
                    }
                    composable(
                        route = OfficeRoutes.DOCUMENT,
                        arguments = listOf(navArgument("docId") { type = NavType.StringType }),
                    ) { backStackEntry ->
                        val docId = backStackEntry.arguments?.getString("docId").orEmpty()
                        DocumentEditorScreen(
                            docId = docId,
                            onBack = { navController.popBackStack() },
                        )
                    }
                    composable(
                        route = OfficeRoutes.SPREADSHEET,
                        arguments = listOf(navArgument("docId") { type = NavType.StringType }),
                    ) { backStackEntry ->
                        val docId = backStackEntry.arguments?.getString("docId").orEmpty()
                        SpreadsheetEditorScreen(
                            docId = docId,
                            onBack = { navController.popBackStack() },
                        )
                    }
                    composable(
                        route = OfficeRoutes.PRESENTATION,
                        arguments = listOf(navArgument("docId") { type = NavType.StringType }),
                    ) { backStackEntry ->
                        val docId = backStackEntry.arguments?.getString("docId").orEmpty()
                        PresentationEditorScreen(
                            docId = docId,
                            onBack = { navController.popBackStack() },
                        )
                    }
                }
            }
        }
    }
}

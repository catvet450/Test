package com.example

import com.example.engine.FormulaEngine
import com.example.engine.OoxmlDocumentCodec
import com.example.engine.OoxmlPresentationCodec
import com.example.engine.OoxmlSpreadsheetCodec
import com.example.model.CellData
import com.example.model.CellNumberFormat
import com.example.model.SampleTemplates
import com.example.model.SheetModel
import com.example.model.WorkbookModel
import com.example.model.cellKey
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class OfficeEnginesTest {

    @Test
    fun `formula engine evaluates sum average if and detects cycles`() {
        val cells = mapOf(
            cellKey(0, 0) to CellData(rawInput = "10"),
            cellKey(1, 0) to CellData(rawInput = "20"),
            cellKey(2, 0) to CellData(rawInput = "30"),
            cellKey(3, 0) to CellData(rawInput = "=SUM(A1:A3)"),
            cellKey(4, 0) to CellData(rawInput = "=AVERAGE(A1:A3)"),
            cellKey(5, 0) to CellData(rawInput = "=IF(A4>50,\"OK\",\"LOW\")"),
            cellKey(6, 0) to CellData(rawInput = "=A8+1"),
            cellKey(7, 0) to CellData(rawInput = "=A7+1"),
            cellKey(8, 0) to CellData(rawInput = "1200", numberFormat = CellNumberFormat.CURRENCY_RUB),
        )
        val sheet = FormulaEngine.recalculateSheet(SheetModel(cells = cells))
        assertEquals("60", sheet.cells[cellKey(3, 0)]?.evaluatedValue)
        assertEquals("20", sheet.cells[cellKey(4, 0)]?.evaluatedValue)
        assertEquals("OK", sheet.cells[cellKey(5, 0)]?.evaluatedValue)
        assertEquals("#CYCLE!", sheet.cells[cellKey(6, 0)]?.evaluatedValue)
        assertTrue(sheet.cells[cellKey(8, 0)]?.evaluatedValue?.contains("₽") == true)
    }

    @Test
    fun `docx roundtrip preserves paragraphs and tables`() {
        val original = SampleTemplates.createDocumentByTemplate("doc_report")
        val out = ByteArrayOutputStream()
        OoxmlDocumentCodec.exportDocx(original, out)
        val imported = OoxmlDocumentCodec.importDocx(ByteArrayInputStream(out.toByteArray()))
        assertTrue(imported.blocks.any { it.text.contains("Квартальный отчёт") })
        assertTrue(imported.blocks.any { it.isTable && it.tableRows.size == 4 })
    }

    @Test
    fun `xlsx roundtrip preserves formulas and sheets`() {
        val wb = FormulaEngine.recalculateWorkbook(SampleTemplates.createWorkbookByTemplate("sheet_budget"))
        val out = ByteArrayOutputStream()
        OoxmlSpreadsheetCodec.exportXlsx(wb, out)
        val imported = OoxmlSpreadsheetCodec.importXlsx(ByteArrayInputStream(out.toByteArray()))
        assertEquals(2, imported.sheets.size)
        val sumCell = imported.sheets[0].cells[cellKey(5, 1)]
        assertEquals("=SUM(B2:B5)", sumCell?.rawInput)
        assertEquals("228 000", sumCell?.evaluatedValue?.replace('\u00A0', ' '))
    }

    @Test
    fun `pptx roundtrip preserves slides and elements`() {
        val pres = SampleTemplates.createPresentationByTemplate("slide_pitch")
        val out = ByteArrayOutputStream()
        OoxmlPresentationCodec.exportPptx(pres, out)
        val imported = OoxmlPresentationCodec.importPptx(ByteArrayInputStream(out.toByteArray()))
        assertEquals(4, imported.slides.size)
        assertTrue(imported.slides[0].elements.any { it.text.contains("Стратегия") })
    }
}
